﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Common.Cache
{
    public static class UserLoginCache
    {
        public static int staff_id { get; set; }
        public static string first_name { get; set; }
        public static string Last_name { get; set; }
        public static string Email { get; set; }
        public static int Store { get; set; }
        public static int peli_id { get; set; }
        public static string peli_nombre{ get; set; }
        public static string peli_dis { get; set; }
        public static decimal precio { get; set; }
        public static int clia_id { get; set; }
        public static string clia_nombre { get; set; }
        public static string clia_apellido { get; set; }
        public static string clia_email { get; set; }
        public static int rental_id { get; set; }

    }
}
