﻿using Microsoft.VisualBasic.ApplicationServices;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DvDs
{
    public partial class Crear : Form
    {
        public Crear()
        {
            InitializeComponent();
        }

        private void tabCli_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void btCli_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los datos de los TextBox.
                string idCliente = txbidcli.Text;
                string nombreCliente = txbNombreCli.Text;
                string apellidosCliente = txbApellidosCli.Text;
                string tiendaCliente = txbTiendaCli.Text;
                string emailCliente = txbEmailCli.Text;
                string direccionCliente = txbDireccionCli.Text;

                // Validar que los datos requeridos no estén vacíos.
                if (string.IsNullOrEmpty(idCliente) || string.IsNullOrEmpty(nombreCliente) || string.IsNullOrEmpty(apellidosCliente))
                {
                    MessageBox.Show("Por favor, complete todos los campos obligatorios.");
                    return;
                }

                // Validar si ya existe un cliente con la misma información en la base de datos.
                if (ClienteExistente(idCliente, nombreCliente, apellidosCliente))
                {
                    MessageBox.Show("Ya existe un cliente con la misma información en la base de datos.");
                    return;
                }

                // Resto del código para la creación del cliente y lógica adicional.
                // Aquí puedes implementar la lógica para guardar el cliente en la base de datos.

                // Ejemplo: Imprimir los datos (puedes reemplazar esto con la lógica real).
                string mensaje = $"ID Cliente: {idCliente}\nNombre: {nombreCliente} {apellidosCliente}\nTienda: {tiendaCliente}\nEmail: {emailCliente}\nDirección: {direccionCliente}";

                MessageBox.Show(mensaje, "Cliente Creado Exitosamente", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Puedes agregar la lógica adicional necesaria después de la creación del cliente.

                // Limpiar los TextBox después de la creación.
                LimpiarTextBoxClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para verificar si ya existe un cliente con la misma información en la base de datos.
        private bool ClienteExistente(string idCliente, string nombreCliente, string apellidosCliente)
        {
            string connectionString = "Server = 127.0.0.1; User Id = postgres; Password = 12345678; Database = DvdRenta";

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                using (NpgsqlCommand command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = System.Data.CommandType.Text;
                    command.CommandText = "SELECT COUNT(*) FROM public.customer WHERE customer_id = @IdCliente AND first_name = @NombreCliente AND last_name = @ApellidosCliente";

                    command.Parameters.Add(new NpgsqlParameter("@IdCliente", NpgsqlDbType.Varchar) { Value = idCliente });
                    command.Parameters.Add(new NpgsqlParameter("@NombreCliente", NpgsqlDbType.Varchar) { Value = nombreCliente });
                    command.Parameters.Add(new NpgsqlParameter("@ApellidosCliente", NpgsqlDbType.Varchar) { Value = apellidosCliente });

                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0; // Devuelve true si ya existe al menos un cliente con la misma información.
                }
            }
        }

        // Método para limpiar los TextBox de información del cliente.
        private void LimpiarTextBoxClientes()
        {
            txbidcli.Text = string.Empty;
            txbNombreCli.Text = string.Empty;
            txbApellidosCli.Text = string.Empty;
            txbTiendaCli.Text = string.Empty;
            txbEmailCli.Text = string.Empty;
            txbDireccionCli.Text = string.Empty;
        }


        private void btAceptarStaff_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los datos de los TextBox para el staff.
                string idStaff = txbidStaff.Text;
                string nombreStaff = txbNombreStaff.Text;
                string apellidoStaff = txbApellidoStaff.Text;
                string tiendaStaff = txbTiendaStaff.Text;
                string emailStaff = txtEmailStaff.Text;
                string direccionStaff = txbDireccionStaff.Text;
                string contrasenaStaff = txbPassStaff.Text;

                // Validar que los datos requeridos no estén vacíos.
                if (string.IsNullOrEmpty(idStaff) || string.IsNullOrEmpty(nombreStaff) || string.IsNullOrEmpty(apellidoStaff) || string.IsNullOrEmpty(contrasenaStaff))
                {
                    MessageBox.Show("Por favor, complete todos los campos obligatorios.");
                    return;
                }

                // Validar si ya existe un staff con la misma información en la base de datos.
                if (StaffExistente(idStaff, nombreStaff, apellidoStaff))
                {
                    MessageBox.Show("Ya existe un staff con la misma información en la base de datos.");
                    return;
                }

                // Resto del código para la creación del staff y lógica adicional.
                // Aquí puedes implementar la lógica para guardar el staff en la base de datos.

                // Ejemplo: Imprimir los datos (puedes reemplazar esto con la lógica real).
                string mensaje = $"ID Staff: {idStaff}\nNombre: {nombreStaff} {apellidoStaff}\nTienda: {tiendaStaff}\nEmail: {emailStaff}\nDirección: {direccionStaff}\nContraseña: {contrasenaStaff}";

                MessageBox.Show(mensaje, "Staff Creado Exitosamente", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Puedes agregar la lógica adicional necesaria después de la creación del staff.

                // Limpiar los TextBox después de la creación.
                LimpiarTextBoxStaff();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método para verificar si ya existe un staff con la misma información en la base de datos.
        private bool StaffExistente(string idStaff, string nombreStaff, string apellidoStaff)
        {
            string connectionString = "Server=127.0.0.1;User Id=postgres;Password=12345678;Database=DvdRenta";

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                using (NpgsqlCommand command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = System.Data.CommandType.Text;
                    command.CommandText = "SELECT COUNT(*) FROM public.staff WHERE staff_id = @IdStaff AND first_name = @NombreStaff AND last_name = @ApellidoStaff";

                    command.Parameters.Add(new NpgsqlParameter("@IdStaff", NpgsqlDbType.Varchar) { Value = idStaff });
                    command.Parameters.Add(new NpgsqlParameter("@NombreStaff", NpgsqlDbType.Varchar) { Value = nombreStaff });
                    command.Parameters.Add(new NpgsqlParameter("@ApellidoStaff", NpgsqlDbType.Varchar) { Value = apellidoStaff });

                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0; // Devuelve true si ya existe al menos un staff con la misma información.
                }
            }
        }

        // Método para limpiar los TextBox de información del staff.
        private void LimpiarTextBoxStaff()
        {
            txbidStaff.Text = string.Empty;
            txbNombreStaff.Text = string.Empty;
            txbApellidoStaff.Text = string.Empty;
            txbTiendaStaff.Text = string.Empty;
            txtEmailStaff.Text = string.Empty;
            txbDireccionStaff.Text = string.Empty;
            txbPassStaff.Text = string.Empty;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form1 log = new Form1();
            log.Show();
            this.Hide();
        }
    }
}
