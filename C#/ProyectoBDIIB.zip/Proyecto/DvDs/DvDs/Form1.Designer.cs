﻿namespace DvDs
{
    partial    class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btnAcceder = new Button();
            pictureBox1 = new PictureBox();
            btnSalir = new Button();
            label2 = new Label();
            panel1 = new Panel();
            lbErrorMessage = new Label();
            linkLabel1 = new LinkLabel();
            txbContraseniaSt = new TextBox();
            txbUsuarioStaff = new TextBox();
            label4 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnAcceder
            // 
            btnAcceder.BackColor = Color.FromArgb(144, 12, 63);
            btnAcceder.FlatAppearance.BorderSize = 0;
            btnAcceder.FlatAppearance.MouseOverBackColor = Color.FromArgb(128, 64, 64);
            btnAcceder.FlatStyle = FlatStyle.Flat;
            btnAcceder.Font = new Font("Perpetua Titling MT", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAcceder.ForeColor = SystemColors.ButtonHighlight;
            btnAcceder.Location = new Point(67, 332);
            btnAcceder.Name = "btnAcceder";
            btnAcceder.Size = new Size(307, 32);
            btnAcceder.TabIndex = 5;
            btnAcceder.Text = "Acceder";
            btnAcceder.UseVisualStyleBackColor = false;
            btnAcceder.Click += btnAcceder_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.Logo_OW;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(123, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(177, 97);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // btnSalir
            // 
            btnSalir.AutoSize = true;
            btnSalir.BackColor = Color.FromArgb(255, 128, 128);
            btnSalir.BackgroundImage = Properties.Resources.fondo1;
            btnSalir.BackgroundImageLayout = ImageLayout.None;
            btnSalir.Cursor = Cursors.Hand;
            btnSalir.FlatAppearance.BorderSize = 0;
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = Color.FromArgb(64, 0, 64);
            btnSalir.ImageAlign = ContentAlignment.BottomRight;
            btnSalir.Location = new Point(-3, 0);
            btnSalir.Margin = new Padding(0);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(519, 43);
            btnSalir.TabIndex = 3;
            btnSalir.Text = "X ";
            btnSalir.TextAlign = ContentAlignment.TopRight;
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Lucida Bright", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(67, 125);
            label2.Name = "label2";
            label2.Size = new Size(298, 33);
            label2.TabIndex = 4;
            label2.Text = "Inicio Sesión STAFF";
            label2.Click += Label2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 91, 23);
            panel1.Controls.Add(lbErrorMessage);
            panel1.Controls.Add(linkLabel1);
            panel1.Controls.Add(txbContraseniaSt);
            panel1.Controls.Add(txbUsuarioStaff);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(btnAcceder);
            panel1.Location = new Point(46, 28);
            panel1.Name = "panel1";
            panel1.Size = new Size(424, 437);
            panel1.TabIndex = 6;
            // 
            // lbErrorMessage
            // 
            lbErrorMessage.AutoSize = true;
            lbErrorMessage.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbErrorMessage.ForeColor = Color.CornflowerBlue;
            lbErrorMessage.ImageAlign = ContentAlignment.BottomLeft;
            lbErrorMessage.Location = new Point(48, 291);
            lbErrorMessage.Name = "lbErrorMessage";
            lbErrorMessage.Size = new Size(119, 20);
            lbErrorMessage.TabIndex = 12;
            lbErrorMessage.Text = "     ErrorMessage";
            lbErrorMessage.Visible = false;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.LinkColor = Color.FromArgb(64, 0, 64);
            linkLabel1.Location = new Point(165, 385);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(113, 15);
            linkLabel1.TabIndex = 11;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Crear nuevo usuario";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // txbContraseniaSt
            // 
            txbContraseniaSt.BackColor = Color.FromArgb(255, 91, 23);
            txbContraseniaSt.BorderStyle = BorderStyle.None;
            txbContraseniaSt.Font = new Font("Lucida Bright", 14.25F);
            txbContraseniaSt.ForeColor = Color.RosyBrown;
            txbContraseniaSt.Location = new Point(48, 235);
            txbContraseniaSt.Name = "txbContraseniaSt";
            txbContraseniaSt.Size = new Size(353, 23);
            txbContraseniaSt.TabIndex = 10;
            txbContraseniaSt.Text = "password";
            txbContraseniaSt.Enter += txbContraseniaSt_Enter;
            txbContraseniaSt.Leave += txbContraseniaSt_Leave;
            // 
            // txbUsuarioStaff
            // 
            txbUsuarioStaff.BackColor = Color.FromArgb(255, 91, 23);
            txbUsuarioStaff.BorderStyle = BorderStyle.None;
            txbUsuarioStaff.Font = new Font("Lucida Bright", 14.25F);
            txbUsuarioStaff.ForeColor = Color.RosyBrown;
            txbUsuarioStaff.Location = new Point(48, 185);
            txbUsuarioStaff.Name = "txbUsuarioStaff";
            txbUsuarioStaff.Size = new Size(353, 23);
            txbUsuarioStaff.TabIndex = 9;
            txbUsuarioStaff.Text = "user";
            txbUsuarioStaff.Enter += txbUsuarioStaff_Enter;
            txbUsuarioStaff.Leave += txbUsuarioStaff_Leave;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Perpetua Titling MT", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(38, 235);
            label4.Name = "label4";
            label4.Size = new Size(353, 26);
            label4.TabIndex = 8;
            label4.Text = "_______________________________";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Perpetua Titling MT", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(38, 185);
            label3.Name = "label3";
            label3.Size = new Size(353, 26);
            label3.TabIndex = 7;
            label3.Text = "_______________________________";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(84, 35, 59);
            BackgroundImage = Properties.Resources.fondo1;
            ClientSize = new Size(516, 505);
            Controls.Add(panel1);
            Controls.Add(btnSalir);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Opacity = 0.9D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox pictureBox1;
        private Button btnSalir;
        private Label label2;
        private Button btnAcceder;
        private Panel panel1;
        private TextBox txbUsuarioStaff;
        private Label label4;
        private Label label3;
        private TextBox txbContraseniaSt;
        private LinkLabel linkLabel1;
        private Label lbErrorMessage;
    }
}
