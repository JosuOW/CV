﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DvDs
{
    public partial class Menu : Form
    {
        Random random = new Random();
        public Menu()
        {
            InitializeComponent();
        }
        public void cambiarImagen()
        {
            int ImagenSeleccionada = random.Next(1, 4);
            pic1.Image = Image.FromFile("C:\\Users\\josus\\source\\repos\\DvDs\\DvDs\\imagenes\\Peliculas\\" + ImagenSeleccionada + ".jpg");
        }


        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cambiarImagen();
        }

        private void btlogOut_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Desea cerrar sesión?", "Advertencia",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                this.Close();

            }
        }

        private void btnAlquiler_Click(object sender, EventArgs e)
        {
            Alquiler alquiler = new Alquiler();
            alquiler.Show();
            this.Hide();
        }

        private void btnDevolucion_Click(object sender, EventArgs e)
        {
            Devolver devolver = new Devolver();
            devolver.Show();
            this.Hide();
        }

        private void btnReporte_Click(object sender, EventArgs e)
        {
            Reporte reporte = new Reporte();
            reporte.Show();
            this.Hide();
        }
    }
}


