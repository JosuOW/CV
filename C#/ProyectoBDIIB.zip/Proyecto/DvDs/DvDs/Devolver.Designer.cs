﻿namespace DvDs
{
    partial class Devolver
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnDevolver = new Button();
            txbCLiDev = new TextBox();
            txbidrentaDev = new TextBox();
            label5 = new Label();
            label4 = new Label();
            dataGridView1 = new DataGridView();
            id_renta = new DataGridViewTextBoxColumn();
            Pelicula = new DataGridViewTextBoxColumn();
            FechaRenta = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            store = new DataGridViewTextBoxColumn();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            btnSalir = new Button();
            pictureBox1 = new PictureBox();
            btnRegresar = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(144, 12, 63);
            panel1.Controls.Add(btnDevolver);
            panel1.Controls.Add(txbCLiDev);
            panel1.Controls.Add(txbidrentaDev);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(26, 102);
            panel1.Name = "panel1";
            panel1.Size = new Size(612, 398);
            panel1.TabIndex = 0;
            // 
            // btnDevolver
            // 
            btnDevolver.BackColor = Color.FromArgb(255, 192, 128);
            btnDevolver.FlatAppearance.BorderSize = 0;
            btnDevolver.FlatAppearance.MouseOverBackColor = Color.FromArgb(128, 64, 64);
            btnDevolver.FlatStyle = FlatStyle.Flat;
            btnDevolver.Font = new Font("Perpetua Titling MT", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDevolver.ForeColor = SystemColors.ActiveCaptionText;
            btnDevolver.Location = new Point(141, 341);
            btnDevolver.Name = "btnDevolver";
            btnDevolver.Size = new Size(307, 32);
            btnDevolver.TabIndex = 19;
            btnDevolver.Text = "DEVOLVER";
            btnDevolver.UseVisualStyleBackColor = false;
            btnDevolver.Click += btnDevolver_Click;
            // 
            // txbCLiDev
            // 
            txbCLiDev.BackColor = Color.FromArgb(144, 12, 63);
            txbCLiDev.BorderStyle = BorderStyle.None;
            txbCLiDev.Font = new Font("Segoe UI Symbol", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbCLiDev.ForeColor = SystemColors.Info;
            txbCLiDev.Location = new Point(305, 95);
            txbCLiDev.Name = "txbCLiDev";
            txbCLiDev.Size = new Size(275, 28);
            txbCLiDev.TabIndex = 18;
            txbCLiDev.Enter += txbCLiDev_Enter;
            // 
            // txbidrentaDev
            // 
            txbidrentaDev.BackColor = Color.FromArgb(144, 12, 63);
            txbidrentaDev.BorderStyle = BorderStyle.None;
            txbidrentaDev.Font = new Font("Segoe UI Symbol", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbidrentaDev.ForeColor = SystemColors.Info;
            txbidrentaDev.Location = new Point(194, 294);
            txbidrentaDev.Name = "txbidrentaDev";
            txbidrentaDev.Size = new Size(275, 28);
            txbidrentaDev.TabIndex = 17;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Perpetua Titling MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(297, 95);
            label5.Name = "label5";
            label5.Size = new Size(308, 32);
            label5.TabIndex = 16;
            label5.Text = "_____________________";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Perpetua Titling MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(183, 294);
            label4.Name = "label4";
            label4.Size = new Size(308, 32);
            label4.TabIndex = 15;
            label4.Text = "_____________________";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.Plum;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { id_renta, Pelicula, FechaRenta, Precio, store });
            dataGridView1.Location = new Point(46, 130);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(544, 129);
            dataGridView1.TabIndex = 14;
            // 
            // id_renta
            // 
            id_renta.HeaderText = "Id-Renta";
            id_renta.Name = "id_renta";
            // 
            // Pelicula
            // 
            Pelicula.HeaderText = "Pelicula";
            Pelicula.Name = "Pelicula";
            // 
            // FechaRenta
            // 
            FechaRenta.HeaderText = "FechaRenta";
            FechaRenta.Name = "FechaRenta";
            // 
            // Precio
            // 
            Precio.HeaderText = "Precio";
            Precio.Name = "Precio";
            // 
            // store
            // 
            store.HeaderText = "Store";
            store.Name = "store";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Perpetua Titling MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(15, 294);
            label3.Name = "label3";
            label3.Size = new Size(162, 32);
            label3.TabIndex = 13;
            label3.Text = "ID RENTA:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Perpetua Titling MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(110, 82);
            label1.Name = "label1";
            label1.Size = new Size(181, 32);
            label1.TabIndex = 12;
            label1.Text = "ID CLIENTE:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Perpetua Titling MT", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(183, 18);
            label2.Name = "label2";
            label2.Size = new Size(229, 44);
            label2.TabIndex = 11;
            label2.Text = "DEVOLVER";
            // 
            // btnSalir
            // 
            btnSalir.AutoSize = true;
            btnSalir.BackColor = Color.FromArgb(144, 12, 63);
            btnSalir.BackgroundImageLayout = ImageLayout.None;
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = Color.OrangeRed;
            btnSalir.ImageAlign = ContentAlignment.BottomCenter;
            btnSalir.Location = new Point(623, -1);
            btnSalir.Margin = new Padding(0);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(58, 43);
            btnSalir.TabIndex = 9;
            btnSalir.Text = "X";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.Logo_OW;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(236, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(177, 97);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // btnRegresar
            // 
            btnRegresar.BackColor = Color.FromArgb(255, 91, 23);
            btnRegresar.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegresar.ForeColor = SystemColors.ButtonHighlight;
            btnRegresar.Location = new Point(495, 474);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(169, 48);
            btnRegresar.TabIndex = 20;
            btnRegresar.Text = "Menú";
            btnRegresar.UseVisualStyleBackColor = false;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // Devolver
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 91, 23);
            ClientSize = new Size(676, 534);
            Controls.Add(btnRegresar);
            Controls.Add(pictureBox1);
            Controls.Add(btnSalir);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Devolver";
            Opacity = 0.9D;
            Text = "Form2";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btnSalir;
        private PictureBox pictureBox1;
        private Label label2;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn id_renta;
        private DataGridViewTextBoxColumn Pelicula;
        private DataGridViewTextBoxColumn FechaRenta;
        private DataGridViewTextBoxColumn Precio;
        private DataGridViewTextBoxColumn store;
        private Label label3;
        private Label label1;
        private TextBox txbCLiDev;
        private TextBox txbidrentaDev;
        private Label label5;
        private Label label4;
        private Button btnDevolver;
        private Button btnRegresar;
    }
}