﻿namespace DvDs
{
    partial class Crear
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            tabCrear = new TabControl();
            tabCli = new TabPage();
            btCli = new Button();
            label15 = new Label();
            txbDireccionCli = new TextBox();
            label12 = new Label();
            label13 = new Label();
            txbEmailCli = new TextBox();
            label10 = new Label();
            label11 = new Label();
            txbTiendaCli = new TextBox();
            label8 = new Label();
            label9 = new Label();
            txbApellidosCli = new TextBox();
            label6 = new Label();
            label7 = new Label();
            txbNombreCli = new TextBox();
            label4 = new Label();
            label5 = new Label();
            txbidcli = new TextBox();
            label3 = new Label();
            label2 = new Label();
            tabStaff = new TabPage();
            txbApellidoStaff = new TextBox();
            txbNombreStaff = new TextBox();
            txbidStaff = new TextBox();
            btAceptarStaff = new Button();
            txbPassStaff = new TextBox();
            label29 = new Label();
            label16 = new Label();
            label28 = new Label();
            label17 = new Label();
            txbDireccionStaff = new TextBox();
            label27 = new Label();
            label18 = new Label();
            label26 = new Label();
            label19 = new Label();
            txtEmailStaff = new TextBox();
            label25 = new Label();
            label20 = new Label();
            label24 = new Label();
            label21 = new Label();
            txbTiendaStaff = new TextBox();
            label23 = new Label();
            label22 = new Label();
            label1 = new Label();
            btnSalir = new Button();
            btnRegresar = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabCrear.SuspendLayout();
            tabCli.SuspendLayout();
            tabStaff.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 91, 23);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(tabCrear);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(57, 39);
            panel1.Name = "panel1";
            panel1.Size = new Size(465, 584);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.Logo_OW;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(147, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(175, 86);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // tabCrear
            // 
            tabCrear.Controls.Add(tabCli);
            tabCrear.Controls.Add(tabStaff);
            tabCrear.Font = new Font("Segoe UI Symbol", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabCrear.Location = new Point(27, 146);
            tabCrear.Name = "tabCrear";
            tabCrear.SelectedIndex = 0;
            tabCrear.Size = new Size(393, 428);
            tabCrear.TabIndex = 1;
            // 
            // tabCli
            // 
            tabCli.BackColor = Color.FromArgb(255, 255, 128);
            tabCli.Controls.Add(btCli);
            tabCli.Controls.Add(label15);
            tabCli.Controls.Add(txbDireccionCli);
            tabCli.Controls.Add(label12);
            tabCli.Controls.Add(label13);
            tabCli.Controls.Add(txbEmailCli);
            tabCli.Controls.Add(label10);
            tabCli.Controls.Add(label11);
            tabCli.Controls.Add(txbTiendaCli);
            tabCli.Controls.Add(label8);
            tabCli.Controls.Add(label9);
            tabCli.Controls.Add(txbApellidosCli);
            tabCli.Controls.Add(label6);
            tabCli.Controls.Add(label7);
            tabCli.Controls.Add(txbNombreCli);
            tabCli.Controls.Add(label4);
            tabCli.Controls.Add(label5);
            tabCli.Controls.Add(txbidcli);
            tabCli.Controls.Add(label3);
            tabCli.Controls.Add(label2);
            tabCli.Font = new Font("Tahoma", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabCli.Location = new Point(4, 41);
            tabCli.Name = "tabCli";
            tabCli.Padding = new Padding(3);
            tabCli.Size = new Size(385, 383);
            tabCli.TabIndex = 0;
            tabCli.Text = "CLIENTE";
            tabCli.Click += tabCli_Click;
            // 
            // btCli
            // 
            btCli.BackColor = Color.DarkOrange;
            btCli.ForeColor = Color.FromArgb(64, 0, 64);
            btCli.Location = new Point(140, 289);
            btCli.Name = "btCli";
            btCli.Size = new Size(85, 35);
            btCli.TabIndex = 22;
            btCli.Text = "Aceptar";
            btCli.UseVisualStyleBackColor = false;
            btCli.Click += btCli_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(29, 274);
            label15.Name = "label15";
            label15.Size = new Size(0, 16);
            label15.TabIndex = 19;
            // 
            // txbDireccionCli
            // 
            txbDireccionCli.BackColor = Color.FromArgb(255, 255, 128);
            txbDireccionCli.BorderStyle = BorderStyle.None;
            txbDireccionCli.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbDireccionCli.Location = new Point(116, 231);
            txbDireccionCli.Name = "txbDireccionCli";
            txbDireccionCli.Size = new Size(109, 18);
            txbDireccionCli.TabIndex = 18;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(116, 231);
            label12.Name = "label12";
            label12.Size = new Size(109, 24);
            label12.TabIndex = 17;
            label12.Text = "_________";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(31, 238);
            label13.Name = "label13";
            label13.Size = new Size(80, 16);
            label13.TabIndex = 16;
            label13.Text = "DIRECCIÓN:";
            // 
            // txbEmailCli
            // 
            txbEmailCli.BackColor = Color.FromArgb(255, 255, 128);
            txbEmailCli.BorderStyle = BorderStyle.None;
            txbEmailCli.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbEmailCli.Location = new Point(116, 189);
            txbEmailCli.Name = "txbEmailCli";
            txbEmailCli.Size = new Size(109, 18);
            txbEmailCli.TabIndex = 15;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(116, 189);
            label10.Name = "label10";
            label10.Size = new Size(109, 24);
            label10.TabIndex = 14;
            label10.Text = "_________";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(31, 196);
            label11.Name = "label11";
            label11.Size = new Size(52, 16);
            label11.TabIndex = 13;
            label11.Text = "EMAIL:";
            // 
            // txbTiendaCli
            // 
            txbTiendaCli.BackColor = Color.FromArgb(255, 255, 128);
            txbTiendaCli.BorderStyle = BorderStyle.None;
            txbTiendaCli.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbTiendaCli.Location = new Point(116, 152);
            txbTiendaCli.Name = "txbTiendaCli";
            txbTiendaCli.Size = new Size(109, 18);
            txbTiendaCli.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(116, 152);
            label8.Name = "label8";
            label8.Size = new Size(109, 24);
            label8.TabIndex = 11;
            label8.Text = "_________";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(31, 152);
            label9.Name = "label9";
            label9.Size = new Size(58, 16);
            label9.TabIndex = 10;
            label9.Text = "TIENDA:";
            // 
            // txbApellidosCli
            // 
            txbApellidosCli.BackColor = Color.FromArgb(255, 255, 128);
            txbApellidosCli.BorderStyle = BorderStyle.None;
            txbApellidosCli.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbApellidosCli.Location = new Point(116, 109);
            txbApellidosCli.Name = "txbApellidosCli";
            txbApellidosCli.Size = new Size(109, 18);
            txbApellidosCli.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(116, 109);
            label6.Name = "label6";
            label6.Size = new Size(109, 24);
            label6.TabIndex = 8;
            label6.Text = "_________";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(31, 115);
            label7.Name = "label7";
            label7.Size = new Size(74, 16);
            label7.TabIndex = 7;
            label7.Text = "APELLIDO:";
            // 
            // txbNombreCli
            // 
            txbNombreCli.BackColor = Color.FromArgb(255, 255, 128);
            txbNombreCli.BorderStyle = BorderStyle.None;
            txbNombreCli.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbNombreCli.Location = new Point(116, 62);
            txbNombreCli.Name = "txbNombreCli";
            txbNombreCli.Size = new Size(109, 18);
            txbNombreCli.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(116, 62);
            label4.Name = "label4";
            label4.Size = new Size(109, 24);
            label4.TabIndex = 5;
            label4.Text = "_________";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(31, 63);
            label5.Name = "label5";
            label5.Size = new Size(64, 16);
            label5.TabIndex = 4;
            label5.Text = "NOMBRE:";
            // 
            // txbidcli
            // 
            txbidcli.BackColor = Color.FromArgb(255, 255, 128);
            txbidcli.BorderStyle = BorderStyle.None;
            txbidcli.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbidcli.Location = new Point(81, 18);
            txbidcli.Name = "txbidcli";
            txbidcli.Size = new Size(109, 18);
            txbidcli.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(81, 18);
            label3.Name = "label3";
            label3.Size = new Size(109, 24);
            label3.TabIndex = 2;
            label3.Text = "_________";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 18);
            label2.Name = "label2";
            label2.Size = new Size(26, 16);
            label2.TabIndex = 0;
            label2.Text = "ID:";
            // 
            // tabStaff
            // 
            tabStaff.BackColor = Color.FromArgb(255, 255, 128);
            tabStaff.Controls.Add(txbApellidoStaff);
            tabStaff.Controls.Add(txbNombreStaff);
            tabStaff.Controls.Add(txbidStaff);
            tabStaff.Controls.Add(btAceptarStaff);
            tabStaff.Controls.Add(txbPassStaff);
            tabStaff.Controls.Add(label29);
            tabStaff.Controls.Add(label16);
            tabStaff.Controls.Add(label28);
            tabStaff.Controls.Add(label17);
            tabStaff.Controls.Add(txbDireccionStaff);
            tabStaff.Controls.Add(label27);
            tabStaff.Controls.Add(label18);
            tabStaff.Controls.Add(label26);
            tabStaff.Controls.Add(label19);
            tabStaff.Controls.Add(txtEmailStaff);
            tabStaff.Controls.Add(label25);
            tabStaff.Controls.Add(label20);
            tabStaff.Controls.Add(label24);
            tabStaff.Controls.Add(label21);
            tabStaff.Controls.Add(txbTiendaStaff);
            tabStaff.Controls.Add(label23);
            tabStaff.Controls.Add(label22);
            tabStaff.Font = new Font("Segoe UI Symbol", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabStaff.Location = new Point(4, 41);
            tabStaff.Name = "tabStaff";
            tabStaff.Padding = new Padding(3);
            tabStaff.Size = new Size(385, 383);
            tabStaff.TabIndex = 1;
            tabStaff.Text = "STAFF";
            // 
            // txbApellidoStaff
            // 
            txbApellidoStaff.BackColor = Color.FromArgb(255, 255, 128);
            txbApellidoStaff.BorderStyle = BorderStyle.None;
            txbApellidoStaff.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbApellidoStaff.Location = new Point(194, 122);
            txbApellidoStaff.Name = "txbApellidoStaff";
            txbApellidoStaff.Size = new Size(109, 18);
            txbApellidoStaff.TabIndex = 31;
            // 
            // txbNombreStaff
            // 
            txbNombreStaff.BackColor = Color.FromArgb(255, 255, 128);
            txbNombreStaff.BorderStyle = BorderStyle.None;
            txbNombreStaff.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbNombreStaff.Location = new Point(181, 80);
            txbNombreStaff.Name = "txbNombreStaff";
            txbNombreStaff.Size = new Size(109, 18);
            txbNombreStaff.TabIndex = 28;
            // 
            // txbidStaff
            // 
            txbidStaff.BackColor = Color.FromArgb(255, 255, 128);
            txbidStaff.BorderStyle = BorderStyle.None;
            txbidStaff.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbidStaff.Location = new Point(181, 36);
            txbidStaff.Name = "txbidStaff";
            txbidStaff.Size = new Size(109, 18);
            txbidStaff.TabIndex = 25;
            // 
            // btAceptarStaff
            // 
            btAceptarStaff.BackColor = Color.DarkOrange;
            btAceptarStaff.ForeColor = Color.FromArgb(64, 0, 64);
            btAceptarStaff.Location = new Point(177, 325);
            btAceptarStaff.Name = "btAceptarStaff";
            btAceptarStaff.Size = new Size(85, 35);
            btAceptarStaff.TabIndex = 44;
            btAceptarStaff.Text = "Aceptar";
            btAceptarStaff.UseVisualStyleBackColor = false;
            btAceptarStaff.Click += btAceptarStaff_Click;
            // 
            // txbPassStaff
            // 
            txbPassStaff.BackColor = Color.FromArgb(255, 255, 128);
            txbPassStaff.BorderStyle = BorderStyle.None;
            txbPassStaff.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbPassStaff.Location = new Point(216, 281);
            txbPassStaff.Name = "txbPassStaff";
            txbPassStaff.Size = new Size(109, 18);
            txbPassStaff.TabIndex = 43;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(58, 40);
            label29.Name = "label29";
            label29.Size = new Size(30, 20);
            label29.TabIndex = 23;
            label29.Text = "ID:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(216, 281);
            label16.Name = "label16";
            label16.Size = new Size(109, 24);
            label16.TabIndex = 42;
            label16.Text = "_________";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label28.Location = new Point(181, 36);
            label28.Name = "label28";
            label28.Size = new Size(109, 24);
            label28.TabIndex = 24;
            label28.Text = "_________";
            label28.Click += label28_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(58, 285);
            label17.Name = "label17";
            label17.Size = new Size(123, 20);
            label17.TabIndex = 41;
            label17.Text = "CONTRASEÑA :";
            // 
            // txbDireccionStaff
            // 
            txbDireccionStaff.BackColor = Color.FromArgb(255, 255, 128);
            txbDireccionStaff.BorderStyle = BorderStyle.None;
            txbDireccionStaff.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbDireccionStaff.Location = new Point(177, 244);
            txbDireccionStaff.Name = "txbDireccionStaff";
            txbDireccionStaff.Size = new Size(109, 18);
            txbDireccionStaff.TabIndex = 40;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(58, 83);
            label27.Name = "label27";
            label27.Size = new Size(80, 20);
            label27.TabIndex = 26;
            label27.Text = "NOMBRE:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(177, 244);
            label18.Name = "label18";
            label18.Size = new Size(109, 24);
            label18.TabIndex = 39;
            label18.Text = "_________";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label26.Location = new Point(181, 80);
            label26.Name = "label26";
            label26.Size = new Size(109, 24);
            label26.TabIndex = 27;
            label26.Text = "_________";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(58, 248);
            label19.Name = "label19";
            label19.Size = new Size(98, 20);
            label19.TabIndex = 38;
            label19.Text = "DIRECCIÓN:";
            // 
            // txtEmailStaff
            // 
            txtEmailStaff.BackColor = Color.FromArgb(255, 255, 128);
            txtEmailStaff.BorderStyle = BorderStyle.None;
            txtEmailStaff.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtEmailStaff.Location = new Point(177, 202);
            txtEmailStaff.Name = "txtEmailStaff";
            txtEmailStaff.Size = new Size(109, 18);
            txtEmailStaff.TabIndex = 37;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(58, 125);
            label25.Name = "label25";
            label25.Size = new Size(87, 20);
            label25.TabIndex = 29;
            label25.Text = "APELLIDO:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.Location = new Point(177, 202);
            label20.Name = "label20";
            label20.Size = new Size(109, 24);
            label20.TabIndex = 36;
            label20.Text = "_________";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label24.Location = new Point(194, 122);
            label24.Name = "label24";
            label24.Size = new Size(109, 24);
            label24.TabIndex = 30;
            label24.Text = "_________";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(58, 206);
            label21.Name = "label21";
            label21.Size = new Size(60, 20);
            label21.TabIndex = 35;
            label21.Text = "EMAIL:";
            // 
            // txbTiendaStaff
            // 
            txbTiendaStaff.BackColor = Color.FromArgb(255, 255, 128);
            txbTiendaStaff.BorderStyle = BorderStyle.None;
            txbTiendaStaff.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txbTiendaStaff.Location = new Point(177, 165);
            txbTiendaStaff.Name = "txbTiendaStaff";
            txbTiendaStaff.Size = new Size(109, 18);
            txbTiendaStaff.TabIndex = 34;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(58, 169);
            label23.Name = "label23";
            label23.Size = new Size(71, 20);
            label23.TabIndex = 32;
            label23.Text = "TIENDA:";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Times New Roman", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.Location = new Point(177, 165);
            label22.Name = "label22";
            label22.Size = new Size(109, 24);
            label22.TabIndex = 33;
            label22.Text = "_________";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(255, 255, 128);
            label1.Location = new Point(77, 104);
            label1.Name = "label1";
            label1.Size = new Size(309, 31);
            label1.TabIndex = 0;
            label1.Text = "CREACIÓN USUARIOS";
            // 
            // btnSalir
            // 
            btnSalir.AutoSize = true;
            btnSalir.BackColor = Color.FromArgb(255, 128, 128);
            btnSalir.BackgroundImage = Properties.Resources.fondo1;
            btnSalir.BackgroundImageLayout = ImageLayout.None;
            btnSalir.Cursor = Cursors.Hand;
            btnSalir.FlatAppearance.BorderSize = 0;
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.Font = new Font("Sitka Small", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = Color.FromArgb(64, 0, 64);
            btnSalir.ImageAlign = ContentAlignment.BottomRight;
            btnSalir.Location = new Point(40, 9);
            btnSalir.Margin = new Padding(0);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(519, 43);
            btnSalir.TabIndex = 4;
            btnSalir.Text = "X ";
            btnSalir.TextAlign = ContentAlignment.TopRight;
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // btnRegresar
            // 
            btnRegresar.BackColor = Color.FromArgb(255, 91, 23);
            btnRegresar.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegresar.ForeColor = SystemColors.ButtonHighlight;
            btnRegresar.Location = new Point(192, 619);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(169, 48);
            btnRegresar.TabIndex = 22;
            btnRegresar.Text = "Login";
            btnRegresar.UseVisualStyleBackColor = false;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // Crear
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondo1;
            ClientSize = new Size(568, 671);
            Controls.Add(btnRegresar);
            Controls.Add(btnSalir);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Crear";
            Opacity = 0.9D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form4";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabCrear.ResumeLayout(false);
            tabCli.ResumeLayout(false);
            tabCli.PerformLayout();
            tabStaff.ResumeLayout(false);
            tabStaff.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private TabControl tabCrear;
        private TabPage tabCli;
        private TabPage tabStaff;
        private Label label2;
        private TextBox txbTiendaCli;
        private Label label8;
        private Label label9;
        private TextBox txbApellidosCli;
        private Label label6;
        private Label label7;
        private TextBox txbNombreCli;
        private Label label4;
        private Label label5;
        private TextBox txbidcli;
        private Label label3;
        private Label label15;
        private TextBox txbDireccionCli;
        private Label label12;
        private Label label13;
        private TextBox txbEmailCli;
        private Label label10;
        private Label label11;
        private Button btCli;
        private Button btAceptarStaff;
        private TextBox txbPassStaff;
        private Label label16;
        private Label label17;
        private TextBox txbDireccionStaff;
        private Label label18;
        private Label label19;
        private TextBox txtEmailStaff;
        private Label label20;
        private Label label21;
        private TextBox txbTiendaStaff;
        private Label label22;
        private Label label23;
        private TextBox txbApellidoStaff;
        private Label label24;
        private Label label25;
        private TextBox txbNombreStaff;
        private Label label26;
        private Label label27;
        private TextBox txbidStaff;
        private Label label28;
        private Label label29;
        private Button btnSalir;
        private PictureBox pictureBox1;
        private Button btnRegresar;
    }
}