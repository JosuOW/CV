﻿namespace DvDs
{
    partial class Reporte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnfiltrar = new Button();
            btbuscarepor = new Button();
            txbreporpeli = new TextBox();
            label5 = new Label();
            label7 = new Label();
            label3 = new Label();
            cBrating = new ComboBox();
            dgReporte = new DataGridView();
            reporId = new DataGridViewTextBoxColumn();
            reporDvd = new DataGridViewTextBoxColumn();
            reporCli = new DataGridViewTextBoxColumn();
            reporPrecio = new DataGridViewTextBoxColumn();
            reporFechaAlquiler = new DataGridViewTextBoxColumn();
            reporEstado = new DataGridViewTextBoxColumn();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            btnSalir = new Button();
            btnRegresar = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgReporte).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 91, 23);
            panel1.Controls.Add(btnfiltrar);
            panel1.Controls.Add(btbuscarepor);
            panel1.Controls.Add(txbreporpeli);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(cBrating);
            panel1.Controls.Add(dgReporte);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(36, 37);
            panel1.Name = "panel1";
            panel1.Size = new Size(803, 502);
            panel1.TabIndex = 0;
            // 
            // btnfiltrar
            // 
            btnfiltrar.BackColor = Color.FromArgb(255, 91, 23);
            btnfiltrar.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnfiltrar.ForeColor = SystemColors.ButtonHighlight;
            btnfiltrar.Location = new Point(420, 163);
            btnfiltrar.Name = "btnfiltrar";
            btnfiltrar.Size = new Size(158, 44);
            btnfiltrar.TabIndex = 25;
            btnfiltrar.Text = "FILTRAR";
            btnfiltrar.UseVisualStyleBackColor = false;
            btnfiltrar.Click += btnfiltrar_Click;
            // 
            // btbuscarepor
            // 
            btbuscarepor.BackColor = Color.FromArgb(255, 91, 23);
            btbuscarepor.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btbuscarepor.ForeColor = SystemColors.ButtonHighlight;
            btbuscarepor.Location = new Point(614, 399);
            btbuscarepor.Name = "btbuscarepor";
            btbuscarepor.Size = new Size(169, 48);
            btbuscarepor.TabIndex = 22;
            btbuscarepor.Text = "Buscar";
            btbuscarepor.UseVisualStyleBackColor = false;
            btbuscarepor.Click += btbuscarepor_Click;
            // 
            // txbreporpeli
            // 
            txbreporpeli.BackColor = Color.FromArgb(255, 91, 23);
            txbreporpeli.BorderStyle = BorderStyle.None;
            txbreporpeli.Font = new Font("Segoe UI Symbol", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txbreporpeli.ForeColor = SystemColors.Info;
            txbreporpeli.Location = new Point(314, 399);
            txbreporpeli.Name = "txbreporpeli";
            txbreporpeli.Size = new Size(275, 28);
            txbreporpeli.TabIndex = 24;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Perpetua Titling MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(300, 399);
            label5.Name = "label5";
            label5.Size = new Size(308, 32);
            label5.TabIndex = 23;
            label5.Text = "_____________________";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Text", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlLightLight;
            label7.Location = new Point(271, 381);
            label7.Name = "label7";
            label7.Size = new Size(106, 18);
            label7.TabIndex = 22;
            label7.Text = "¿Algo específico?";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Perpetua Titling MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(14, 399);
            label3.Name = "label3";
            label3.Size = new Size(294, 32);
            label3.TabIndex = 16;
            label3.Text = "PELÍCULA NOMBRE:";
            // 
            // cBrating
            // 
            cBrating.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cBrating.FormattingEnabled = true;
            cBrating.Items.AddRange(new object[] { "PG", "G", "NC-17", "PG-13", "R" });
            cBrating.Location = new Point(195, 176);
            cBrating.Name = "cBrating";
            cBrating.Size = new Size(161, 29);
            cBrating.TabIndex = 14;
            // 
            // dgReporte
            // 
            dgReporte.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgReporte.Columns.AddRange(new DataGridViewColumn[] { reporId, reporDvd, reporCli, reporPrecio, reporFechaAlquiler, reporEstado });
            dgReporte.Location = new Point(84, 213);
            dgReporte.Name = "dgReporte";
            dgReporte.Size = new Size(643, 150);
            dgReporte.TabIndex = 13;
            // 
            // reporId
            // 
            reporId.HeaderText = "IdRental";
            reporId.Name = "reporId";
            // 
            // reporDvd
            // 
            reporDvd.HeaderText = "DvD";
            reporDvd.Name = "reporDvd";
            // 
            // reporCli
            // 
            reporCli.HeaderText = "Cliente";
            reporCli.Name = "reporCli";
            // 
            // reporPrecio
            // 
            reporPrecio.HeaderText = "Precio";
            reporPrecio.Name = "reporPrecio";
            // 
            // reporFechaAlquiler
            // 
            reporFechaAlquiler.HeaderText = "FechaAlquiler";
            reporFechaAlquiler.Name = "reporFechaAlquiler";
            // 
            // reporEstado
            // 
            reporEstado.HeaderText = "Estado";
            reporEstado.Name = "reporEstado";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Perpetua Titling MT", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(185, 119);
            label2.Name = "label2";
            label2.Size = new Size(351, 44);
            label2.TabIndex = 12;
            label2.Text = "REPORTES DVD´S";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.Logo_OW;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(300, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(177, 97);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // btnSalir
            // 
            btnSalir.AutoSize = true;
            btnSalir.BackColor = Color.FromArgb(144, 12, 63);
            btnSalir.BackgroundImageLayout = ImageLayout.None;
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = Color.OrangeRed;
            btnSalir.ImageAlign = ContentAlignment.BottomCenter;
            btnSalir.Location = new Point(829, -9);
            btnSalir.Margin = new Padding(0);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(58, 43);
            btnSalir.TabIndex = 10;
            btnSalir.Text = "X";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // btnRegresar
            // 
            btnRegresar.BackColor = Color.FromArgb(255, 91, 23);
            btnRegresar.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegresar.ForeColor = SystemColors.ButtonHighlight;
            btnRegresar.Location = new Point(698, 511);
            btnRegresar.Name = "btnRegresar";
            btnRegresar.Size = new Size(169, 48);
            btnRegresar.TabIndex = 21;
            btnRegresar.Text = "Menú";
            btnRegresar.UseVisualStyleBackColor = false;
            btnRegresar.Click += btnRegresar_Click;
            // 
            // Reporte
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(144, 12, 63);
            ClientSize = new Size(879, 571);
            Controls.Add(btnRegresar);
            Controls.Add(btnSalir);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Reporte";
            Text = "Reporte";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgReporte).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Button btnSalir;
        private Button btnRegresar;
        private Label label2;
        private ComboBox cBrating;
        private DataGridView dgReporte;
        private DataGridViewTextBoxColumn reporId;
        private DataGridViewTextBoxColumn reporDvd;
        private DataGridViewTextBoxColumn reporCli;
        private DataGridViewTextBoxColumn reporPrecio;
        private DataGridViewTextBoxColumn reporFechaAlquiler;
        private DataGridViewTextBoxColumn reporEstado;
        private Label label3;
        private Label label7;
        private Label label5;
        private Button btnfiltrar;
        private Button btbuscarepor;
        private TextBox txbreporpeli;
    }
}