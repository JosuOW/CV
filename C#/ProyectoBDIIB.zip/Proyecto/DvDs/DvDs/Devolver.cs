﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql;

namespace DvDs
{
    public partial class Devolver : Form
    {
        private int selectedRentalId;  // Variable para almacenar el id_rental seleccionado.

        public Devolver()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Menu men = new Menu();
            men.Show();
            this.Hide();
        }

        private void txbCLiDev_Enter(object sender, EventArgs e)
        {
            // Método para manejar el evento cuando se ingresa el id_cliente y se presiona Enter.
            RealizarConsulta();
        }

        private void RealizarConsulta()
        {
            string connectionString = "Server=127.0.0.1;User Id=postgres;Password=12345678;Database=DvdRenta";

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                // Obtener el id_cliente del TextBox correspondiente.
                int idCliente = Convert.ToInt32(txbCLiDev.Text);

                using (NpgsqlCommand command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.Text;
                    command.CommandText = @"SELECT
                                                r.rental_id AS id_renta,
                                                f.title AS nombre_pelicula,
                                                r.rental_date AS fecha_renta,
                                                f.rental_rate AS precio,
                                                s.store_id AS id_tienda,
                                                ((c.city)::text || ','::text) || (cy.country)::text AS nombre_tienda
                                            FROM
                                                public.rental r
                                                JOIN public.inventory i ON r.inventory_id = i.inventory_id
                                                JOIN public.film f ON i.film_id = f.film_id
                                                JOIN public.store s ON i.store_id = s.store_id
                                                JOIN public.customer c ON r.customer_id = c.customer_id
                                                JOIN public.address a ON c.address_id = a.address_id
                                                JOIN public.city ON a.city_id = city.city_id
                                                JOIN public.country cy ON city.country_id = cy.country_id
                                            WHERE
                                                c.customer_id = @IdCliente";

                    command.Parameters.AddWithValue("@IdCliente", idCliente);

                    using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Asignar el DataTable a la grilla (DataGridView) para mostrar los resultados.
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            // Manejar el evento cuando se selecciona una fila en la grilla.
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Obtener el valor de la columna "id_renta" de la fila seleccionada.
                selectedRentalId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id_renta"].Value);

                // Mostrar el id_renta en el TextBox correspondiente.
                txbidrentaDev.Text = selectedRentalId.ToString();
            }
        }

        private void btnDevolver_Click(object sender, EventArgs e)
        {
            // Método para manejar el evento cuando se hace clic en el botón "Devolver".
            RealizarDevolucion();
        }

        private void RealizarDevolucion()
        {
            string connectionString = "Server=127.0.0.1;User Id=postgres;Password=12345678;Database=DvdRenta";

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                int idCliente = Convert.ToInt32(txbCLiDev.Text);

                using (NpgsqlCommand command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandType = CommandType.Text;
                    command.CommandText = @"UPDATE rental
                                            SET return_date = CURRENT_TIMESTAMP
                                            WHERE rental_id = @IdRental AND customer_id = @IdCliente";

                    command.Parameters.AddWithValue("@IdRental", selectedRentalId);  // Usar el id_rental seleccionado.
                    command.Parameters.AddWithValue("@IdCliente", idCliente);  // Usar el id_cliente obtenido.

                    command.ExecuteNonQuery();

                    MessageBox.Show("Película devuelta con éxito.");
                }
            }
        }
    }
}
