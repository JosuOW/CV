﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DvDs
{

    public partial class Reporte : Form
    {
        public Reporte()
        {
            InitializeComponent();
        }
        private void CargarPeliculas()
        {
            string connectionString = "Server=127.0.0.1;User Id=postgres;Password=12345678;Database=DvdRenta";

            string ratingSeleccionado = ObtenerRatingSeleccionado();

            if (!string.IsNullOrEmpty(ratingSeleccionado))
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (NpgsqlCommand command = new NpgsqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = @"WITH LatestRental AS (
                                                SELECT
                                                    r.inventory_id,
                                                    MAX(r.return_date) AS latest_return_date
                                                FROM
                                                    public.rental r
                                                GROUP BY
                                                    r.inventory_id
                                            )
                                            
                                            SELECT
                                                f.film_id AS idRental,
                                                f.title AS nombre_del_dvd,
                                                c.first_name || ' ' || c.last_name AS cliente,
                                                f.rental_rate AS precio,
                                                r.rental_date AS fecha_alquiler,
                                                CASE
                                                    WHEN lr.latest_return_date IS NULL OR lr.latest_return_date < CURRENT_DATE THEN 'Disponible'
                                                    ELSE 'No Disponible'
                                                END AS estado
                                            FROM
                                                public.film f
                                            JOIN
                                                public.inventory i ON f.film_id = i.film_id
                                            LEFT JOIN
                                                public.customer c ON i.customer_id = c.customer_id
                                            LEFT JOIN
                                                public.rental r ON i.inventory_id = r.inventory_id
                                            LEFT JOIN
                                                LatestRental lr ON i.inventory_id = lr.inventory_id
                                            WHERE
                                                f.rating = @Rating
                                            ORDER BY
                                                lr.latest_return_date DESC NULLS LAST
                                            LIMIT 1;";

                        command.Parameters.AddWithValue("@Rating", ratingSeleccionado);

                        using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Asignar el DataTable a la grilla (DataGridView) para mostrar los resultados.
                            dgReporte.DataSource = dataTable;
                        }
                    }
                }
            }
        }

        private string ObtenerRatingSeleccionado()
        {
            // Obtener el rating seleccionado del ComboBox cBrating.
            return cBrating.SelectedItem?.ToString();
        }

        private void btnfiltrar_Click(object sender, EventArgs e)
        {
            CargarPeliculas();
        }

        private void Peliculanombre()
        {
            string nombrePelicula = txbreporpeli.Text;
            string connectionString = "Server=127.0.0.1;User Id=postgres;Password=12345678;Database=DvdRenta";
            if (!string.IsNullOrEmpty(nombrePelicula))
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (NpgsqlCommand command = new NpgsqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = @"WITH LatestRental AS (
                                                SELECT
                                                    r.inventory_id,
                                                    MAX(r.return_date) AS latest_return_date
                                                FROM
                                                    public.rental r
                                                GROUP BY
                                                    r.inventory_id
                                            )
                                            
                                            SELECT
                                                f.film_id AS idRental,
                                                f.title AS nombre_del_dvd,
                                                c.first_name || ' ' || c.last_name AS cliente,
                                                f.rental_rate AS precio,
                                                r.rental_date AS fecha_alquiler,
                                                CASE
                                                    WHEN lr.latest_return_date IS NULL OR lr.latest_return_date < CURRENT_DATE THEN 'Disponible'
                                                    ELSE 'No Disponible'
                                                END AS estado
                                            FROM
                                                public.film f
                                            JOIN
                                                public.inventory i ON f.film_id = i.film_id
                                            LEFT JOIN
                                                public.customer c ON i.customer_id = c.customer_id
                                            LEFT JOIN
                                                public.rental r ON i.inventory_id = r.inventory_id
                                            LEFT JOIN
                                                LatestRental lr ON i.inventory_id = lr.inventory_id
                                            WHERE
                                                f.title = @NombrePelicula
                                            ORDER BY
                                                lr.latest_return_date DESC NULLS LAST
                                            LIMIT 1;";

                        command.Parameters.AddWithValue("@NombrePelicula", nombrePelicula);

                        using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            // Asignar el DataTable a la grilla (DataGridView) para mostrar los resultados.
                            dgReporte.DataSource = dataTable;
                        }
                    }
                }
            }
        }

        private void btbuscarepor_Click(object sender, EventArgs e)
        {
            Peliculanombre();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Menu men = new Menu();
            men.Show();
            this.Hide();
        }
    }
}
    

