using System.Drawing.Text;
using System.Security.Cryptography;
using Domain;
using Microsoft.VisualBasic;

namespace DvDs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void btnAcceder_Click(object sender, EventArgs e)
        {
            if (txbUsuarioStaff.Text != "user")
            {
                if (txbContraseniaSt.Text != "password")
                {
                    UserModel user = new UserModel();
                    var validLogin = user.LoginUser(txbUsuarioStaff.Text, txbContraseniaSt.Text);
                    if (validLogin == true)
                    {
                        Menu menu = new Menu();
                        menu.Show();
                        menu.FormClosed += logOut;
                        this.Hide();
                    }
                    else
                    {
                        MsgError(" Usuario o contrase�a incorrecto");
                        txbContraseniaSt.Text = "password";
                        txbUsuarioStaff.Focus();

                    }
                }
                else
                {
                    MsgError("Por favor ingrese contrase�a");
                }
            }
            else
            {
                MsgError("Por favor ingrese usuario");
            }
        }

        private void MsgError(string msg)
        {
            lbErrorMessage.Text = "" + msg;
            lbErrorMessage.Visible = true;
        }

        private void txbUsuarioStaff_Enter(object sender, EventArgs e)
        {
            if (txbUsuarioStaff.Text == "user")
            {
                txbUsuarioStaff.Text = "";
                txbUsuarioStaff.ForeColor = Color.White;
            }
        }

        private void txbUsuarioStaff_Leave(object sender, EventArgs e)
        {
            if (txbUsuarioStaff.Text == "")
            {
                txbUsuarioStaff.Text = "user";
                txbUsuarioStaff.ForeColor = Color.RosyBrown;
            }
        }

        private void txbContraseniaSt_Enter(object sender, EventArgs e)
        {
            if (txbContraseniaSt.Text == "password")
            {
                txbContraseniaSt.Text = "";
                txbContraseniaSt.ForeColor = Color.White;
                txbContraseniaSt.UseSystemPasswordChar = true;
            }
        }

        private void txbContraseniaSt_Leave(object sender, EventArgs e)
        {
            if (txbContraseniaSt.Text == "")
            {
                txbContraseniaSt.Text = "password";
                txbContraseniaSt.ForeColor = Color.RosyBrown;
                txbContraseniaSt.UseSystemPasswordChar = false;
            }
        }
        private void logOut(object sender, FormClosedEventArgs e)
        {
            txbContraseniaSt.Text = "password";
            txbContraseniaSt.UseSystemPasswordChar = false;
            txbUsuarioStaff.Text = "user";
            lbErrorMessage.Visible = false;
            this.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Crear crear = new Crear();
            crear.Show();
            this.Hide();
        }
    }
}
