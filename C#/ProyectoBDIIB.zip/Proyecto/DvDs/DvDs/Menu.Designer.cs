﻿namespace DvDs
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            label2 = new Label();
            btnSalir = new Button();
            pic1 = new PictureBox();
            pictureBox2 = new PictureBox();
            btnReporte = new Button();
            btnDevolucion = new Button();
            btnAlquiler = new Button();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            btlogOut = new Button();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pic1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Perpetua Titling MT", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(387, 34);
            label2.Name = "label2";
            label2.Size = new Size(240, 26);
            label2.TabIndex = 9;
            label2.Text = "RECOMENDACIONES";
            // 
            // btnSalir
            // 
            btnSalir.AutoSize = true;
            btnSalir.BackColor = Color.FromArgb(84, 35, 59);
            btnSalir.BackgroundImageLayout = ImageLayout.None;
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = Color.OrangeRed;
            btnSalir.ImageAlign = ContentAlignment.BottomCenter;
            btnSalir.Location = new Point(645, 0);
            btnSalir.Margin = new Padding(0);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(58, 43);
            btnSalir.TabIndex = 8;
            btnSalir.Text = "X";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // pic1
            // 
            pic1.BorderStyle = BorderStyle.Fixed3D;
            pic1.Location = new Point(368, 70);
            pic1.Name = "pic1";
            pic1.Size = new Size(276, 313);
            pic1.SizeMode = PictureBoxSizeMode.CenterImage;
            pic1.TabIndex = 7;
            pic1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = Properties.Resources.Logo_PY__1_;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(434, 375);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(153, 87);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // btnReporte
            // 
            btnReporte.BackColor = Color.FromArgb(255, 91, 23);
            btnReporte.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReporte.ForeColor = SystemColors.ButtonHighlight;
            btnReporte.Location = new Point(0, 305);
            btnReporte.Name = "btnReporte";
            btnReporte.Size = new Size(312, 59);
            btnReporte.TabIndex = 5;
            btnReporte.Text = "Reporte";
            btnReporte.UseVisualStyleBackColor = false;
            btnReporte.Click += btnReporte_Click;
            // 
            // btnDevolucion
            // 
            btnDevolucion.BackColor = Color.FromArgb(255, 91, 23);
            btnDevolucion.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDevolucion.ForeColor = SystemColors.ButtonHighlight;
            btnDevolucion.Location = new Point(0, 249);
            btnDevolucion.Name = "btnDevolucion";
            btnDevolucion.Size = new Size(312, 59);
            btnDevolucion.TabIndex = 3;
            btnDevolucion.Text = "Devolución";
            btnDevolucion.UseVisualStyleBackColor = false;
            btnDevolucion.Click += btnDevolucion_Click;
            // 
            // btnAlquiler
            // 
            btnAlquiler.BackColor = Color.FromArgb(255, 91, 23);
            btnAlquiler.Font = new Font("Perpetua Titling MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAlquiler.ForeColor = SystemColors.ButtonHighlight;
            btnAlquiler.Location = new Point(0, 193);
            btnAlquiler.Name = "btnAlquiler";
            btnAlquiler.Size = new Size(312, 59);
            btnAlquiler.TabIndex = 2;
            btnAlquiler.Text = "Alquiler";
            btnAlquiler.UseVisualStyleBackColor = false;
            btnAlquiler.Click += btnAlquiler_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.Logo_OW;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(312, 187);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 91, 23);
            panel1.Controls.Add(btlogOut);
            panel1.Controls.Add(btnReporte);
            panel1.Controls.Add(btnDevolucion);
            panel1.Controls.Add(btnAlquiler);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(312, 427);
            panel1.TabIndex = 5;
            // 
            // btlogOut
            // 
            btlogOut.BackColor = Color.FromArgb(255, 91, 23);
            btlogOut.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btlogOut.ForeColor = SystemColors.ButtonHighlight;
            btlogOut.Location = new Point(48, 387);
            btlogOut.Name = "btlogOut";
            btlogOut.Size = new Size(201, 28);
            btlogOut.TabIndex = 6;
            btlogOut.Text = "Cerrar sesión";
            btlogOut.UseVisualStyleBackColor = false;
            btlogOut.Click += btlogOut_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Imprint MT Shadow", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(39, 28);
            label1.Name = "label1";
            label1.Size = new Size(191, 32);
            label1.TabIndex = 0;
            label1.Text = "DVD's Rental";
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(84, 35, 59);
            ClientSize = new Size(703, 427);
            Controls.Add(label2);
            Controls.Add(btnSalir);
            Controls.Add(pic1);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            ForeColor = SystemColors.ControlText;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "menu";
            Opacity = 0.9D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)pic1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Button btnSalir;
        private PictureBox pic1;
        private PictureBox pictureBox2;
        private Button btnReporte;
        private Button btnDevolucion;
        private Button btnAlquiler;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
        private Button btlogOut;
    }
}