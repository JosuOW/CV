﻿using Common.Cache;
using Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DvDs
{
    public partial class Alquiler : Form
    {
        public Alquiler()
        {
            InitializeComponent();
            LoadUserData();
            btAlquilar.Enabled = false;
        }

 
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Menu men = new Menu();
            men.Show();
            this.Hide();
        }

        private void fotostaff_Click(object sender, EventArgs e)
        {

        }
        private void txbPelicula_Enter(object sender, EventArgs e)
        {
            UserModel user = new UserModel();
            var validPeli = user.Peli(txbPelicula.Text);
            if (validPeli == true)
            {
                if (UserLoginCache.peli_dis == "No disponible")
                {
                    lalerror.Visible = true;
                    lalerror.Text = "No disponible";
                }

                txbCliente.Focus();
            }
            else
            {
                lalerror.Visible = true;
                lalerror.Text = "No existe pelicula";
            }

        }
        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void LoadUserData()
        {
            lid.Text = UserLoginCache.staff_id.ToString();
            lnombre.Text = UserLoginCache.first_name + " " + UserLoginCache.Last_name;
            lemail.Text = UserLoginCache.Email;
            ltienda.Text = UserLoginCache.Store.ToString();
        }

        private void btAlquilar_Click(object sender, EventArgs e)
        {
            UserModel user = new UserModel();
            String validalquiler = user.Alquilar(UserLoginCache.clia_id.ToString(), UserLoginCache.peli_id.ToString(), UserLoginCache.staff_id.ToString());
            MessageBox.Show(validalquiler + " Su id rental: " + UserLoginCache.rental_id.ToString(), "Informativo", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void txbCliente_Enter(object sender, EventArgs e)
        {
            txtIdClial.Focus();
        }

        private void txtIdClial_Enter(object sender, EventArgs e)
        {
            UserModel user = new UserModel();
            var validCli = user.ClienteE(txbCliente.Text,txtIdClial.Text);
            if (validCli == true)
            {
                txbPrecio.Text = UserLoginCache.precio.ToString();
                btAlquilar.Enabled = true;
            }
            else
            {
                lalerror.Visible = true;
                lalerror.Text = "usuario no existe";
            }
        }
    }
}
