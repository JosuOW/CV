﻿using System;
using System.Data;
using Npgsql;
using Common.Cache;
using System.Collections.Generic;



namespace DataAccess
{
    public class UserD : ConnectionSql
    {
  
        public bool Login(string username, string password)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "SELECT * FROM obtener_usuario(@p_username, @p_password)";
                    command.Parameters.AddWithValue("@p_username", username);
                    command.Parameters.AddWithValue("@p_password", password);

                    NpgsqlDataReader reader = command.ExecuteReader();
                        // Check if there are any rows returned
                        if (reader.HasRows)
                        {
                        while (reader.Read())
                        {
                            UserLoginCache.staff_id = reader.GetInt32(0);
                            UserLoginCache.first_name = reader.GetString(1);
                            UserLoginCache.Last_name = reader.GetString(2);
                            UserLoginCache.Email = reader.GetString(4);
                            UserLoginCache.Store = reader.GetInt32(5);
                        }
                        // User exists, login successful
                        return true;
                        }
                        else
                        {
                            // User does not exist or incorrect password
                            return false;
                        }
                    
                }
            }
        }

        public bool pelicula(string peli)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "WITH LatestRental AS (\r\n    " +
                        "SELECT\r\n        r.inventory_id,\r\n        MAX(r.return_date) AS latest_return_date\r\n    " +
                        "FROM\r\n        public.rental r\r\n    GROUP BY\r\n        " +
                        "r.inventory_id\r\n)\r\n\r\nSELECT\r\n    f.film_id,\r\n    f.title AS film_title,\r\n    " +
                        "f.rental_rate AS rental_price,\r\n    CASE\r\n        WHEN lr.latest_return_date IS NULL OR lr.latest_return_date < CURRENT_DATE THEN 'Disponible'\r\n       " +
                        " ELSE 'No Disponible'\r\n    END AS availability\r\nFROM\r\n    public.film f\r\nJOIN\r\n    public.inventory i ON f.film_id = i.film_id\r\nLEFT JOIN\r\n    LatestRental lr " +
                        "ON i.inventory_id = lr.inventory_id\r\nWHERE\r\n    f.title = @p_peli \r\nORDER BY\r\n    lr.latest_return_date DESC NULLS LAST\r\nLIMIT 1;";
                    command.Parameters.AddWithValue("@p_peli", peli);


                    NpgsqlDataReader reader = command.ExecuteReader();
                    // Check if there are any rows returned
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            UserLoginCache.peli_id = reader.GetInt32(0);
                            UserLoginCache.peli_nombre= reader.GetString(1);
                            UserLoginCache.precio= reader.GetDecimal(2);
                            UserLoginCache.peli_dis=reader.GetString(3);
                        }
                        // User exists, login successful
                        
                        return true;
                    }
                    else
                    {
                        // User does not exist or incorrect password
                        return false;
                    }

                }
            }
        }

        public bool cliente(string clinombre, string idcliente)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "SELECT * " +
                        "FROM public.customer WHERE customer_id = @customer_id  AND first_name = @first_name";
                    command.Parameters.AddWithValue("@customer_id ", idcliente);
                    command.Parameters.AddWithValue("@first_name ", clinombre);

                    NpgsqlDataReader reader = command.ExecuteReader();
                    // Check if there are any rows returned
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            UserLoginCache.clia_id = reader.GetInt32(0);
                            UserLoginCache.clia_nombre = reader.GetString(1);
                            UserLoginCache.clia_apellido = reader.GetString(1);
                            UserLoginCache.clia_email = reader.GetString(3);
                        }
                        // User exists, login successful

                        return true;
                    }
                    else
                    {
                        // User does not exist or incorrect password
                        return false;
                    }

                }
            }
        }

        public string Alquiler(string idfilm, string idcliente, string idstaff)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new NpgsqlCommand())
                {
                    command.Connection = connection;
                    command.CommandText = "WITH LastInventory AS (\r\n    SELECT inventory_id\r\n    FROM public.inventory\r\n    WHERE film_id = @film_id\r\n    AND NOT EXISTS (\r\n        SELECT 1\r\n        FROM public.rental\r\n        WHERE inventory_id = public.inventory.inventory_id\r\n        AND return_date IS NULL\r\n    )\r\n    ORDER BY last_update DESC\r\n    LIMIT 1\r\n)INSERT INTO public.rental(rental_date, inventory_id, customer_id, staff_id, last_update)" +
                        "VALUES(CURRENT_TIMESTAMP, (SELECT inventory_id FROM LastInventory), @customer_id, @staff_id, CURRENT_TIMESTAMP)" +
                        " RETURNING rental_id";
                    command.Parameters.AddWithValue("@customer_id ", idcliente);
                    command.Parameters.AddWithValue("@film_id ", idfilm);
                    command.Parameters.AddWithValue("@staff_id ", idstaff);
                    NpgsqlDataReader reader = command.ExecuteReader();
                    // Check if there are any rows returned
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            UserLoginCache.rental_id = reader.GetInt32(0);

                        }
                        // User exists, login successful

                        return "El alquiler se realizó con éxito.";
                    }
                    else
                    {
                        // User does not exist or incorrect password
                        return "Error al realizar el alquiler. Verifica los datos proporcionados.";
                    }

                }
            }
        }
    }
}
