﻿
using Npgsql;

namespace DataAccess
{
    public abstract class ConnectionSql
    {
       
        private readonly String connectionString;

        public ConnectionSql()
        {
            connectionString = "Server=127.0.0.1;User Id=postgres;Password=12345678;Database=DvdRenta";

        }

        
        protected NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(connectionString);
        }
    }

}
