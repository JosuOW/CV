﻿using DataAccess;
namespace Domain
{
    public class UserModel
    {
        UserD userD = new DataAccess.UserD();
        public bool LoginUser(String user, String pass )
        {
            return userD.Login(user, pass);
        }
        public bool Peli(String peli)
        {
            return userD.pelicula(peli);
        }
        public bool ClienteE(String nombre,String id)
        {
            return userD.cliente(nombre,id);
        }
        public string Alquilar(String idcli,String idpeli, String idstaff)
        {
            return userD.Alquiler(idcli,idpeli,idstaff);
        }

            
    }
}
