﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql;

namespace ProyectoDVDRENTAL
{
    public partial class frmEliminar : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;

        public frmEliminar()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
            LoadFilms();

            // Agregar un manejador de eventos para el evento KeyDown del cuadro de texto de búsqueda
            txtBuscar.KeyDown += new KeyEventHandler(txtBuscar_KeyDown);
        }

        private void LoadFilms(string filter = "")
        {
            conn.Open();

            // Obtener todas las películas
            string sql = @"SELECT film_id AS ID, title AS Nombre, description AS Descripcion FROM film";
            if (!string.IsNullOrEmpty(filter))
            {
                sql += " WHERE title LIKE @filter OR film_id = @id";
            }
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);
            if (!string.IsNullOrEmpty(filter))
            {
                cmd.Parameters.AddWithValue("@filter", "%" + filter + "%");
                if (int.TryParse(filter, out int id))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@id", 0);
                }
            }

            NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            conn.Close();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                conn.Open();

                // Eliminar las filas correspondientes de las tablas payment, rental, inventory, film_actor y film_category
                string sql = "DELETE FROM payment WHERE rental_id IN (SELECT rental_id FROM rental WHERE inventory_id IN (SELECT inventory_id FROM inventory WHERE film_id = @film_id));";
                sql += "DELETE FROM rental WHERE inventory_id IN (SELECT inventory_id FROM inventory WHERE film_id = @film_id);";
                sql += "DELETE FROM inventory WHERE film_id = @film_id;";
                sql += "DELETE FROM film_actor WHERE film_id = @film_id;";
                sql += "DELETE FROM film_category WHERE film_id = @film_id;";
                NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@film_id", dataGridView1.SelectedRows[0].Cells["ID"].Value);
                cmd.ExecuteNonQuery();

                // Eliminar la película seleccionada
                sql = "DELETE FROM film WHERE film_id = @film_id";
                cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@film_id", dataGridView1.SelectedRows[0].Cells["ID"].Value);

                try
                {
                    int result = cmd.ExecuteNonQuery();

                    if (result > 0)
                    {
                        MessageBox.Show("Película eliminada con éxito");
                        LoadFilms(); 
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar la película");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una película para eliminar");
            }
        }



        private void txtBuscar_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                LoadFilms(txtBuscar.Text); // Recargar las películas filtradas cuando se presiona la tecla Enter
            }
        }
    }
}
