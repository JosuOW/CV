﻿using System;
using System.Data;
using Npgsql;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmRegistroClientes : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;

        public frmRegistroClientes()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();

                MessageBox.Show("Conexión a la base de datos exitosa.");

                string sql = "INSERT INTO customer(store_id, first_name, last_name, address_id, activebool, create_date) VALUES (@store_id, @first_name, @last_name, @address_id, @activebool, @create_date)";
                NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("store_id", int.Parse(txtTienda.Text));
                cmd.Parameters.AddWithValue("first_name", txtNombre.Text);
                cmd.Parameters.AddWithValue("last_name", txtApellido.Text);
                cmd.Parameters.AddWithValue("address_id", int.Parse(txtDireccion.Text));
                cmd.Parameters.AddWithValue("activebool", bool.Parse(txtEstado.Text));
                cmd.Parameters.AddWithValue("create_date", DateTime.Parse(txtFecha.Text));

                cmd.ExecuteNonQuery();

                MessageBox.Show("Los datos se han guardado correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnRentar_Click(object sender, EventArgs e)
        {
            frmSeleccionarCliente form3 = new frmSeleccionarCliente();
            this.Close();
            form3.Show();
        }

    }
}
