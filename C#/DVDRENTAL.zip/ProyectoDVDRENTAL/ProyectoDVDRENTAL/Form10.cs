﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace ProyectoDVDRENTAL
{
    public partial class frmIngresarDVD : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;

        public frmIngresarDVD()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO film(title, description, language_id, rental_duration, rental_rate, replacement_cost, last_update, fulltext) VALUES (@title, @description, @language_id, @rental_duration, @rental_rate, @replacement_cost, @last_update, to_tsvector('english', @fulltext))";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@title", txtNombre.Text);
            cmd.Parameters.AddWithValue("@description", txtDescripcion.Text);
            cmd.Parameters.AddWithValue("@language_id", int.Parse(txtLenguaje.Text));
            cmd.Parameters.AddWithValue("@rental_duration", int.Parse(txtDuracion.Text));
            cmd.Parameters.AddWithValue("@rental_rate", decimal.Parse(txtCalificacion.Text));
            cmd.Parameters.AddWithValue("@replacement_cost", decimal.Parse(txtCosto.Text));
            cmd.Parameters.AddWithValue("@last_update", DateTime.Parse(txtFecha.Text));
            cmd.Parameters.AddWithValue("@fulltext", txtTexto.Text);

            try
            {
                conn.Open();
                int result = cmd.ExecuteNonQuery();

                if (result > 0)
                {
                    MessageBox.Show("Film agregado con éxito");
                    this.Close(); 
                }
                else
                {
                    MessageBox.Show("No se pudo agregar el film");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
