﻿using System;
using System.Data;
using Npgsql;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmDevolverPeli : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;
        private object customerId;

        public frmDevolverPeli(object customerId)
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
            this.customerId = customerId;
            LoadRentals();
        }

        private void LoadRentals()
        {
            try
            {
                conn.Open();

                // Obtener todas las películas rentadas por el cliente que aún no han sido devueltas
                string sql = @"SELECT r.rental_id, f.title
                       FROM rental r
                       JOIN inventory i ON r.inventory_id = i.inventory_id
                       JOIN film f ON i.film_id = f.film_id
                       WHERE r.customer_id = @customerId";
                NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("customerId", int.Parse(customerId.ToString()));

                NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Update(); 

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message + "\n" + ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDevolver_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    conn.Open();

                    var rentalId = dataGridView1.SelectedRows[0].Cells["rental_id"].Value;

                    if (rentalId == null)
                    {
                        MessageBox.Show("No se pudo obtener el rentalId.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Actualizar la tabla rental con la fecha de retorno y la fecha de última actualización
                    string sqlRental = @"UPDATE rental SET return_date = NOW(), last_update = NOW() WHERE rental_id = @rentalId";
                    NpgsqlCommand cmdRental = new NpgsqlCommand(sqlRental, conn);
                    cmdRental.Parameters.AddWithValue("rentalId", rentalId);
                    cmdRental.ExecuteNonQuery();

                    conn.Close();

                    MessageBox.Show("La película ha sido devuelta exitosamente.", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Recargar las películas rentadas
                    LoadRentals();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message + "\n" + ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecciona una película para devolver.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
