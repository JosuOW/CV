﻿using System;
using System.Data;
using Npgsql;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmSeleccionarCliente : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;
        private object customerId;

        public frmSeleccionarCliente()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
            txtBuscar.KeyDown += new KeyEventHandler(txtBuscar_KeyDown);
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
        }

        private void txtBuscar_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BuscarCliente();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            customerId = dataGridView1.Rows[e.RowIndex].Cells["customer_id"].Value;
        }

        private void BuscarCliente()
        {
            conn.Open();

            string sql = "SELECT customer_id, first_name, last_name FROM customer WHERE first_name LIKE @name OR last_name LIKE @name";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("name", "%" + txtBuscar.Text + "%");

            NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            conn.Close();
        }

        private void btnAlquilar_Click(object sender, EventArgs e)
        {
            // Verificar si hay una fila seleccionada
            if (dataGridView1.SelectedRows.Count > 0)
            {
                frmSeleccionarPeli form4 = new frmSeleccionarPeli(customerId);
                this.Close();
                form4.Show();
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un cliente antes de proceder.");
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Obtener el ID del cliente seleccionado
            customerId = dataGridView1.Rows[e.RowIndex].Cells["customer_id"].Value;
        }


        private void btnDevolver_Click(object sender, EventArgs e)
        {
            // Verificar si hay una fila seleccionada
            if (dataGridView1.SelectedRows.Count > 0)
            {
                frmDevolverPeli form5 = new frmDevolverPeli(customerId);
                this.Close();
                form5.Show();
            }
            else
            {
                MessageBox.Show("Por favor, selecciona un cliente antes de proceder.");
            }
        }
    }
}
