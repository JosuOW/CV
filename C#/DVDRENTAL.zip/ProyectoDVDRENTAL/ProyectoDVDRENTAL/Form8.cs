﻿using System;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            frmAgregarStaff form9 = new frmAgregarStaff();
            form9.Show();
            this.Close(); 
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            frmIngresarDVD form10 = new frmIngresarDVD();
            form10.Show();
            this.Close();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            frmEliminar form11 = new frmEliminar();
            form11.Show();
            this.Close();
        }
    }
}
