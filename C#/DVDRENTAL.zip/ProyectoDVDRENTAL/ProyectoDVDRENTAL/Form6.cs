﻿using System;
using System.Data;
using Npgsql;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmRentar : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;
        private object customerId;
        private object filmId;

        public frmRentar(object customerId, object filmId)
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
            this.customerId = customerId;
            this.filmId = filmId;
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            
        }

        private void btnGuardarInv_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();

                // Agregar el inventario
                string sqlInv = @"INSERT INTO inventory (film_id, store_id, last_update) 
                                  VALUES (@filmId, @storeId, @lastUpdate)";
                NpgsqlCommand cmdInv = new NpgsqlCommand(sqlInv, conn);
                cmdInv.Parameters.AddWithValue("filmId", filmId);
                cmdInv.Parameters.AddWithValue("storeId", Convert.ToInt16(txtTienda.Text));
                cmdInv.Parameters.AddWithValue("lastUpdate", DateTime.Parse(txtActualizar.Text));
                cmdInv.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("El inventario se ha agregado exitosamente a la base de datos.", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hubo un error al agregar el inventario: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnGuardarRenta_Click(object sender, EventArgs e)
        {
            try
            {

                conn.Open();

                // Obtener el ID del inventario que acabamos de insertar
                string sqlInvId = "SELECT MAX(inventory_id) FROM inventory WHERE film_id = @filmId";
                NpgsqlCommand cmdInvId = new NpgsqlCommand(sqlInvId, conn);
                cmdInvId.Parameters.AddWithValue("filmId", filmId);
                object inventoryId = cmdInvId.ExecuteScalar();

                // Agregar los datos de alquiler
                string sqlRenta = @"INSERT INTO rental (rental_date, inventory_id, customer_id, return_date, staff_id, last_update) 
                            VALUES (@rentalDate, @inventoryId, @customerId, @returnDate, @staffId, @lastUpdate)";
                NpgsqlCommand cmdRenta = new NpgsqlCommand(sqlRenta, conn);
                cmdRenta.Parameters.AddWithValue("rentalDate", DateTime.Parse(txtRenta.Text));
                cmdRenta.Parameters.AddWithValue("inventoryId", inventoryId);
                cmdRenta.Parameters.AddWithValue("customerId", customerId);
                cmdRenta.Parameters.AddWithValue("returnDate", DateTime.Parse(txtRetorno.Text));
                cmdRenta.Parameters.AddWithValue("staffId", Convert.ToInt16(txtStaff.Text));
                cmdRenta.Parameters.AddWithValue("lastUpdate", DateTime.Parse(textBox1.Text));
                cmdRenta.ExecuteNonQuery();

                // Obtener el ID de la renta que acabamos de insertar
                string sqlRentaId = "SELECT MAX(rental_id) FROM rental WHERE inventory_id = @inventoryId";
                NpgsqlCommand cmdRentaId = new NpgsqlCommand(sqlRentaId, conn);
                cmdRentaId.Parameters.AddWithValue("inventoryId", inventoryId);
                object rentalId = cmdRentaId.ExecuteScalar();

                conn.Close();

                MessageBox.Show("Los datos de alquiler se han agregado exitosamente a la base de datos.", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);

                frmPagar form7 = new frmPagar(customerId, rentalId, filmId);
                this.Close();
                form7.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hubo un error al agregar los datos de alquiler: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
