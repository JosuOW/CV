﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql;

namespace ProyectoDVDRENTAL
{
    public partial class frmHistorial : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;

        public frmHistorial()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
        }

        private void LoadCustomerHistory(string filter)
        {
            conn.Open();

            // Obtener todo el historial del cliente
            string sql = @"SELECT c.customer_id AS ID, c.first_name || ' ' || c.last_name AS Nombre, r.rental_date AS Fecha_Renta, r.return_date AS Fecha_Devolucion, p.amount AS Costo_Pelicula, f.title AS Titulo_Pelicula
                           FROM customer c
                           JOIN rental r ON c.customer_id = r.customer_id
                           JOIN payment p ON r.rental_id = p.rental_id
                           JOIN inventory i ON r.inventory_id = i.inventory_id
                           JOIN film f ON i.film_id = f.film_id
                           WHERE c.first_name || ' ' || c.last_name LIKE @filter OR c.customer_id = @id";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@filter", "%" + filter + "%");
            if (int.TryParse(filter, out int id))
            {
                cmd.Parameters.AddWithValue("@id", id);
            }
            else
            {
                cmd.Parameters.AddWithValue("@id", 0);
            }

            NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            conn.Close();
        }

        private void btnVerHistorial_Click(object sender, EventArgs e)
        {
            LoadCustomerHistory(txtBuscar.Text); // Cargar el historial del cliente cuando se hace clic en el botón "Ver Historial"
        }
    }
}
