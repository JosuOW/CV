﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace ProyectoDVDRENTAL
{
    public partial class frmAgregarStaff : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;

        public frmAgregarStaff()
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO staff(first_name, last_name, address_id, store_id, active, username, password, last_update) VALUES (@first_name, @last_name, @address_id, @store_id, @active, @username, @password, @last_update)";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@first_name", txtNombre.Text);
            cmd.Parameters.AddWithValue("@last_name", txtApellido.Text);
            cmd.Parameters.AddWithValue("@address_id", int.Parse(txtDireccion.Text));
            cmd.Parameters.AddWithValue("@store_id", int.Parse(txtTienda.Text));
            cmd.Parameters.AddWithValue("@active", bool.Parse(txtEstado.Text));
            cmd.Parameters.AddWithValue("@username", txtUsuario.Text);
            cmd.Parameters.AddWithValue("@password", txtClave.Text);
            cmd.Parameters.AddWithValue("@last_update", DateTime.Parse(txtFecha.Text));

            try
            {
                conn.Open();
                int result = cmd.ExecuteNonQuery();

                // Comprobar si la inserción fue exitosa
                if (result > 0)
                {
                    MessageBox.Show("Staff agregado con éxito");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No se pudo agregar el staff");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
