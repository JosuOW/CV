﻿using System;
using System.Data;
using Npgsql;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmPagar : Form
    {
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;
        private object rentalId;
        private object customerId;
        private object filmId;

        public frmPagar(object customerId, object rentalId, object filmId) 
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
            this.customerId = customerId;
            this.rentalId = rentalId;
            this.filmId = filmId;
        }


        private void btnPagar_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();

                // Agregar los datos de pago
                string sqlPago = @"INSERT INTO payment (customer_id, staff_id, rental_id, amount, payment_date) 
                           VALUES (@customerId, @staffId, @rentalId, @amount, @paymentDate)";
                NpgsqlCommand cmdPago = new NpgsqlCommand(sqlPago, conn);
                cmdPago.Parameters.AddWithValue("customerId", customerId);
                cmdPago.Parameters.AddWithValue("staffId", Convert.ToInt16(txtStaff.Text));
                cmdPago.Parameters.AddWithValue("rentalId", rentalId);
                cmdPago.Parameters.AddWithValue("amount", Convert.ToDecimal(txtValor.Text));
                cmdPago.Parameters.AddWithValue("paymentDate", DateTime.Parse(txtFecha.Text));
                cmdPago.ExecuteNonQuery();

                // Obtener el nombre y apellido del cliente
                string sqlCustomer = "SELECT first_name, last_name FROM customer WHERE customer_id = @customerId";
                NpgsqlCommand cmdCustomer = new NpgsqlCommand(sqlCustomer, conn);
                cmdCustomer.Parameters.AddWithValue("customerId", customerId);
                NpgsqlDataReader drCustomer = cmdCustomer.ExecuteReader();
                drCustomer.Read();
                string customerName = drCustomer["first_name"] + " " + drCustomer["last_name"];
                drCustomer.Close();

                // Obtener el nombre de la película
                string sqlFilm = "SELECT title FROM film WHERE film_id = @filmId";
                NpgsqlCommand cmdFilm = new NpgsqlCommand(sqlFilm, conn);
                cmdFilm.Parameters.AddWithValue("filmId", filmId);
                NpgsqlDataReader drFilm = cmdFilm.ExecuteReader();
                drFilm.Read();
                string filmTitle = drFilm["title"].ToString();
                drFilm.Close();

                conn.Close();

                // Mostrar un mensaje de confirmación con todos los detalles
                string message = $"El pago se ha agregado exitosamente a la base de datos.\n\n" +
                                 $"Detalles del pago:\n" +
                                 $"- Cliente: {customerName}\n" +
                                 $"- Película: {filmTitle}\n" +
                                 $"- Staff: {txtStaff.Text}\n" +
                                 $"- ID de alquiler: {rentalId}\n" +
                                 $"- Valor: {txtValor.Text}\n" +
                                 $"- Fecha de pago: {txtFecha.Text}";
                MessageBox.Show(message, "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hubo un error al agregar el pago: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtFecha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
