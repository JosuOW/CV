﻿using System;
using System.Data;
using Npgsql;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmSeleccionarPeli : Form
    {
        // Crear la conexión a la base de datos
        private string connString = "Host=localhost;Port=5432;Username=postgres;Password=12345678;Database=DvdRenta";
        private NpgsqlConnection conn;
        private object customerId;
        private object filmId;

        public frmSeleccionarPeli(object customerId)
        {
            InitializeComponent();
            conn = new NpgsqlConnection(connString);
            this.customerId = customerId;
            txtBuscar.TextChanged += new EventHandler(txtBuscar_TextChanged);
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridView1_CellClick);
            LoadDVDs();
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            LoadDVDs();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Obtener el ID del film seleccionado
            filmId = dataGridView1.Rows[e.RowIndex].Cells["film_id"].Value;
        }

        private void LoadDVDs()
        {
            // Abrir la conexión
            conn.Open();

            // Crear un nuevo comando
            string sql = @"SELECT f.film_id, f.title, c.name as category, a.first_name || ' ' || a.last_name as actor
                           FROM film f
                           JOIN film_category fc ON f.film_id = fc.film_id
                           JOIN category c ON fc.category_id = c.category_id
                           JOIN film_actor fa ON f.film_id = fa.film_id
                           JOIN actor a ON fa.actor_id = a.actor_id
                           WHERE f.title LIKE @search OR c.name LIKE @search
                           ORDER BY f.title, c.name, a.first_name, a.last_name";
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);

            // Agregar los parámetros
            cmd.Parameters.AddWithValue("search", "%" + txtBuscar.Text + "%");

            // Ejecutar el comando y llenar el DataGridView
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            // Cerrar la conexión
            conn.Close();
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {
            frmRentar form6 = new frmRentar(customerId, filmId);
            this.Close();
            form6.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
