﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoDVDRENTAL
{
    public partial class frmInicio : Form
    {
        Random random = new Random();
        public frmInicio()
        {
            InitializeComponent();
        }
        public void cambiarImagen()
        {
            int ImagenSeleccionada = random.Next(1, 4);
            pic1.Image = Image.FromFile("C:\\Users\\josus\\Downloads\\ProyectoDVDRENTAL\\ProyectoDVDRENTAL\\imagenes\\Peliculas" + ImagenSeleccionada + ".jpg");
        }
            private void btnRegistrar_Click(object sender, EventArgs e)
        {
            frmRegistroClientes form2 = new frmRegistroClientes();
            form2.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            frmAdmin form8 = new frmAdmin();
            form8.Show();
        }

        private void btnHistorial_Click(object sender, EventArgs e)
        {
           frmHistorial frm12 = new frmHistorial();
           frm12.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            cambiarImagen();
        }
    }
}
