
package Archivos;

import LinkedList.LinkedListEmpleados;
import Negocio.Empleado;
import Negocio.EmpleadoAsalariado;
import Negocio.EmpleadoBaseMasComisiones;
import Negocio.EmpleadoPorComision;
import Negocio.EmpleadoPorHoras;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 *
 * @author josune.singana
 */
public class ManejoArchivos {
     Empleado empleado;
  
     LinkedListEmpleados listaLinked=new LinkedListEmpleados();
    File fe; //puntero al archivo entrada
    File fs; //puntero al archivo de salida
    BufferedReader bEntrada;
    BufferedWriter bSalida;
    public ManejoArchivos() {
      /*  empleado=new EmpleadoEA();*/
        this.fe=new File("datos.txt");
        this.fs=new File("salida.txt");
        try{
        this.bEntrada=new BufferedReader(new FileReader(fe));
        }catch(FileNotFoundException ferror){
            {System.out.println("Archivo no encontrado "+ferror);
            }
        }
         try{
        this.bSalida=new BufferedWriter(new FileWriter(fs,true));
        }catch(IOException fsError)
            {System.out.println("No existe espacio para crear el archivo "+fsError);
         
        }      
    }
    public String lectura(){
        String linea="";
         try{
            linea=bEntrada.readLine();
         }   catch(IOException readError){
             System.out.println("se ha encontrado el fin de archivo"+readError);
         } 
         return linea;
         }
         
    public void escrituraArchivo(String dato){
        try{
            bSalida.write("Factorial:"+dato);
            bSalida.newLine();
        }catch(IOException writeError){
            System.out.println("NO es posible escribir un registro"+writeError);
        }
    }
    
    public void cerrarArchivo(){
        try{
            bEntrada.close();
            bSalida.close();
        }catch(IOException e){
            System.out.println("NO es posible cerrar el archivo"+e);
        }
    }
    public void  procesoArchivo(){
        String texto="", linea="", tipo="", Nombre="", FechaNacimiento="", FechaIngreso="", salida="";
        int posicion;
        double salario;
        
       
        texto=this.lectura();
        StringTokenizer tokensT = new StringTokenizer(texto,"E");
        while(tokensT.hasMoreTokens()){
            linea=tokensT.nextToken();
            StringTokenizer tokensL = new StringTokenizer(linea,"|");
            tipo=tokensL.nextToken();
            posicion=Integer.parseInt(tokensL.nextToken());
            Nombre=tokensL.nextToken();
            FechaIngreso=tokensL.nextToken();
            FechaNacimiento=tokensL.nextToken();
            
            if(tipo.equals("EA")){
                salario=Double.parseDouble(tokensL.nextToken());
                empleado= new EmpleadoAsalariado(salario,FechaIngreso,Nombre,FechaNacimiento);   
                if(posicion!=0){
                    this.listaLinked.agregarEmpleadoAlFinal(empleado);
                }else{
                    this.listaLinked.agregarEmpleadoAlInicio(empleado);
                }
            }else{
                if(tipo.equals("EH")){
                    int numHoras;
                    double costoHora;
                    numHoras=Integer.parseInt(tokensL.nextToken());
                    costoHora=Double.parseDouble(tokensL.nextToken());
                    empleado= new EmpleadoPorHoras(numHoras,costoHora,FechaIngreso,Nombre,FechaNacimiento);
                    if(posicion!=0){
                        this.listaLinked.agregarEmpleadoAlFinal(empleado);
                    }else{
                        this.listaLinked.agregarEmpleadoAlInicio(empleado);
                    }
                    
                }else{
                    if(tipo.equals("EC")){
                        double ventasBrutas, tarifaComision; 
                        ventasBrutas=Double.parseDouble(tokensL.nextToken());
                        tarifaComision=Double.parseDouble(tokensL.nextToken());
                        empleado=new EmpleadoPorComision(tarifaComision,ventasBrutas,FechaIngreso,Nombre,FechaNacimiento);
                        if(posicion!=0){
                            this.listaLinked.agregarEmpleadoAlFinal(empleado);
                        }else{
                            this.listaLinked.agregarEmpleadoAlInicio(empleado);
                        }
                    }else{
                        if(tipo.equals("EBC")){
                            /*EmpleadoBaseMasComisiones(double salarioBase, double tarifaComision, double ventasBrutas, String fechaIngreso, String nombres, String fecha)*/
                            salario=Double.parseDouble(tokensL.nextToken());
                            double ventasBrutas=Double.parseDouble(tokensL.nextToken());
                            double tarifaComision=Double.parseDouble(tokensL.nextToken());
                            empleado=new EmpleadoBaseMasComisiones(salario,tarifaComision,ventasBrutas,FechaIngreso,Nombre,FechaNacimiento);
                            if(posicion!=0){
                                this.listaLinked.agregarEmpleadoAlFinal(empleado);
                            }else{
                                this.listaLinked.agregarEmpleadoAlInicio(empleado);
                            }
                            
                            
                        }else{
                            this.escrituraArchivo("El empleado ingresado no coincide con ningún tipo");
                        }
                    }
                }
   
            }
            this.escrituraArchivo(listaLinked.toString());
        }
        }
        
    }



