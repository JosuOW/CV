
package ListaEncadenada;

import Negocio.Empleado;

/**
 * @author josune.singaña
 */
public class ListaEncadenada {
    Nodo inicio;

    public ListaEncadenada() {
        this.inicio=null; //lista vacia
    }
    public boolean isEmpty(){
        return inicio==null;
    }
    
    public void addStart(Empleado empleado){
        if(isEmpty())
            inicio=new Nodo(empleado);
        else
            inicio=new Nodo(empleado,inicio);        
    }
    
   public void addLast(Empleado empleado){
       if(isEmpty())
            inicio=new Nodo(empleado);
        else{
            Nodo p = inicio, q = inicio;
             while (p != null) {
                 q = p;
                p = p.getEnlace();
             }
         q.setEnlace(new Nodo(empleado)); 
        }        
    }
   
      public void addOrdenada(Empleado empleado){/// en orden
        Nodo p,q,r;
        p=q=inicio;
        r=new Nodo(empleado); 
        boolean bandera=false;
            if (isEmpty()){
                inicio=r; 
                bandera=true;
        }
            else while (p!=null){          
            if (r.getEmpleado().getNombres().compareTo(p.getEmpleado().getNombres())<0){
                if(p==inicio){
                    r.setEnlace(inicio);
                    inicio=r;
                }else {
                    q.setEnlace(r);
                    r.setEnlace(p);
                }bandera =true;
                break;
            }
            else{
            q=p;
            p=p.getEnlace();    
            }  
        }
            if(bandera==false){
                q.setEnlace(r);
            }
           
    }

    
  public boolean eliminarNodo(Empleado empleado){
         Nodo p = inicio, q = inicio;
        boolean bandera= false;
        while (p != null) {
            if (p.getEmpleado().getNombres().equals(empleado.getNombres())) {
                if (p == inicio)//borrar el primer nodo
                {
                    this.inicio = p.getEnlace();
                } else {//borrado intermedio o final
                    q.setEnlace(p.getEnlace());

                }
                bandera= true;
                break;
            } else {

                q = p;
                p = p.getEnlace();
            }
        }
        return bandera;
    
  }    
      
        
    @Override
    public String toString() {
        String salida="";
        Nodo p=inicio;
        while(p!=null){
            salida+=p.getEmpleado()+"\n__________________\n";
            p=p.getEnlace();
        }
        return salida;
    }
    
}
