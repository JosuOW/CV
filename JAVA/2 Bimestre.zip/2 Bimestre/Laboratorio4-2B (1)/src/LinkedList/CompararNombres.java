
package LinkedList;

import Negocio.Empleado;
import java.util.Comparator;

/**
 *
 * @author josune.singaña
 */
public class CompararNombres implements Comparator {

    @Override
       public int compare(Object o1, Object o2) {
     Empleado empleado1=(Empleado)o1;
     Empleado empleado2=(Empleado)o2;
       if( empleado1.getNombres().compareTo(empleado2.getNombres())>0)
    return 1; 
       else
           if( empleado1.getNombres().compareTo(empleado2.getNombres())<0)
         return -1; 
       else
         return 0; 
    }
}
