
package LinkedList;
import Negocio.Empleado;
import java.util.Collections;
import java.util.LinkedList;
/**
 *
 * @author josune.singaña 
 */
public class LinkedListEmpleados {
    private  LinkedList<Empleado> listaEmpleadosC;
   

    public LinkedListEmpleados() {
        this.listaEmpleadosC = new LinkedList<Empleado>();
    }

    public LinkedList getListaEmpleadosC() {
        return listaEmpleadosC;
    }

    public void setListaEmpleadosC(LinkedList listaEmpleadosC) {
        this.listaEmpleadosC = listaEmpleadosC;
    }

   public void agregarEmpleadoAlInicio(Empleado empleado) {
    listaEmpleadosC.addFirst(empleado);  
    }

    public void agregarEmpleadoAlFinal(Empleado empleado) {
       this.listaEmpleadosC.addLast(empleado);
     }
    
     public void ordenarlistaNombres(){
    Collections.sort(listaEmpleadosC, new CompararNombres());
    }
    
@Override
    public String toString() {
       String salida="";
       for(Empleado aux:listaEmpleadosC)    
           salida+=aux.toString()+"\n__________________\n";
       return salida;
           }
    
    }