
package Negocio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author josune.singaña
 */
public class Pais {
   private List <Provincia> listaProvincias;
   
    public Pais() {
        this.listaProvincias = new <Provincia>ArrayList();
    }
    public Object getProvincia(int posicion) {
        int i=0;
        for(Provincia aux:listaProvincias)    
        { if(i==posicion)
                return aux;
            i++;
        }
    return 0;
    }
    public void addProvincia(Provincia provincia){
        listaProvincias.add(provincia);
    }
    public void ordenarlista(){
    Collections.sort(listaProvincias, new CompararNombresProv());
    }
   
    public void ordenarNumHabitantes(){
    Collections.sort(listaProvincias, new  CompararNumHabitantes());
    }
    public Object provinciaMaxNumHabitantes(){
       return   Collections.max(listaProvincias, new CompararNumHabitantes());
       
    }
    public Object provinciaMinNumHabitantes(){
       return   Collections.min(listaProvincias, new CompararNumHabitantes());
       
    }
    public int busquedaBinariaNombreProvincia(Provincia prov){
        ordenarlista();
        return Collections.binarySearch(listaProvincias, prov, new CompararNombresProv());
    }
    public int busquedaBinariaNumHabitantes(Provincia prov){
        ordenarNumHabitantes();
        return Collections.binarySearch(listaProvincias, prov, new CompararNumHabitantes());
        /*retorna indice donde se encuentra el objeto caso contrario retorna -1 */
    }
    public void eliminarProvinciaNombre(String Nombre){
       Provincia provincia;
        Iterator < Provincia > itr = listaProvincias.iterator();
       String nombre=Nombre;
       while (itr.hasNext()) {
       provincia=(Provincia)itr.next();
         if (nombre.equals(provincia.getNombre())) {
           itr.remove();
         }
       } 
    }

    public void eliminarProvinciaNumHabitantes(int numH){
       Provincia provincia;
        Iterator < Provincia > itr = listaProvincias.iterator();
       int NumHabitantes=numH;
       while (itr.hasNext()) {
       provincia=(Provincia)itr.next();
         if (NumHabitantes==provincia.getNumHabitantes()) {
           itr.remove();
         }
       } 
    }
    @Override
    public String toString() {
       String salida="";
       for(Provincia aux:listaProvincias)    
           salida+=aux.toString()+"\n__________________\n";
       return salida;
           } 
}
