
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Provincia {
    private String nombre;
    private int numProvincia;
    private int numHabitantes;

    public Provincia(String nombre, int numProvincia, int numHabitantes) {
        this.nombre = nombre;
        this.numProvincia = numProvincia;
        this.numHabitantes = numHabitantes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumProvincia() {
        return numProvincia;
    }

    public void setNumProvincia(int numProvincia) {
        this.numProvincia = numProvincia;
    }

    public int getNumHabitantes() {
        return numHabitantes;
    }

    public void setNumHabitantes(int numHabitantes) {
        this.numHabitantes = numHabitantes;
    }

    @Override
    public String toString() {
        return "Provincia\nNombre: " + nombre + "\nNúmero Provincia: " + numProvincia + "\nNúmero Habitantes: " + numHabitantes;
    }
}
