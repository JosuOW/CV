
package Negocio;

/**
 *
 * @author  josune.singaña
 */
public class Auto implements ImpactoEcologico {
     private String marca;
    private String modelo;
     private int aniosPertenencia;

    public Auto(String marca, String modelo, int aniosPertenencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.aniosPertenencia = aniosPertenencia;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAniosPertenencia() {
        return aniosPertenencia;
    }

    public void setAniosPertenencia(int aniosPertenencia) {
        this.aniosPertenencia = aniosPertenencia;
    }

    @Override
    public double obtenerImpactoEcologico() {
        if(this.aniosPertenencia>5)
        return 0;
       return 100*this.aniosPertenencia;
    }


    @Override
    public String toString() {
        String salida="";
        salida+="Auto\nMarca: " + marca + "\nModelo: " + modelo + "\nAños Pertenencia: " + aniosPertenencia ;
        salida+="Impacto Ecológico: ";
        if( obtenerImpactoEcologico()==0)
               salida+=" Supera los años de vida útil";
           salida+=obtenerImpactoEcologico();
        return salida;
    }
    
}
