
package Negocio;

/**
 *
 * @author josune.singaña
 */
public interface ImpactoEcologico {
    double obtenerImpactoEcologico();
}
