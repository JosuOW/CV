
package Negocio;

import static java.lang.Integer.parseInt;

/**
 *
 * @author josune.singaña
 */
public class Edificio implements ImpactoEcologico {
    private String nombre;
    private String ubicacion;
    private int pisos;
     private int aniosUso;

    public Edificio(String nombre, String ubicacion, String pisos, String aniosUso) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.pisos =Integer.parseInt(pisos);
        this.aniosUso =Integer.parseInt(aniosUso) ;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getPisos() {
        return pisos;
    }

    public void setPisos(int pisos) {
        this.pisos = pisos;
    }

    public int getAniosUso() {
        return aniosUso;
    }

    public void setAniosUso(int aniosUso) {
        this.aniosUso = aniosUso;
    }
    
    
    @Override
    public double obtenerImpactoEcologico() {
       if(this.aniosUso>25)
        return 0;
       return 50*this.pisos*aniosUso;
    }

    @Override
    public String toString() {
        String salida="";
        salida+="Edificio\nNombre del Edificio: " + nombre + "\nUbicación del Edificio: " + ubicacion+"\nNúmero de pisos: " +pisos+"\nNúmero de años: "+ aniosUso;
    salida+="Impacto Ecológico: ";
           if( obtenerImpactoEcologico()==0)
               salida+=" Supera los años de vida útil";
           salida+=obtenerImpactoEcologico();
        return salida;
                }
    
}
