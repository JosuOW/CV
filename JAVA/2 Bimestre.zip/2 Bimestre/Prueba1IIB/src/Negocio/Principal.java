
package Negocio;

import VIsual.jFImpacto;

/**
 *
 * @author  josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
      jFImpacto jfimpacto=new jFImpacto();
      jfimpacto.setVisible(true);
    }
    
}
