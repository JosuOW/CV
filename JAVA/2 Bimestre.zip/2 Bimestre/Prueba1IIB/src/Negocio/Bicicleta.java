
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Bicicleta implements ImpactoEcologico {
    private String Material;
private int aniosUso;

    public Bicicleta(String Material, int aniosUso) {
        this.Material = Material;
        this.aniosUso = aniosUso;
    }

    public String getMaterial() {
        return Material;
    }

    public void setMaterial(String Material) {
        this.Material = Material;
    }

    public int getAniosUso() {
        return aniosUso;
    }

    public void setAniosUso(int aniosUso) {
        this.aniosUso = aniosUso;
    }

    @Override
    public double obtenerImpactoEcologico() {
     if(this.aniosUso>10)
        return 0;
       return this.aniosUso/5;
    }

    @Override
    public String toString() {
       String salida="";
        salida+="Bicicleta\nMaterial: " + Material + "\nAños Uso:" + aniosUso;
        salida+="Impacto Ecológico: ";
        if( obtenerImpactoEcologico()==0)
               salida+=" Supera los años de vida útil";
           salida+=obtenerImpactoEcologico();
        return salida; 
    }   
}
