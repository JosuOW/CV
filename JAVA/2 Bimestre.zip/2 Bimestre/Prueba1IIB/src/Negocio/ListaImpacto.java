
package Negocio;

import java.util.ArrayList;

/**
 *
 * @author josune.singaña
 */
public class ListaImpacto {
    
ArrayList <ImpactoEcologico> listaimpactos;

    public ListaImpacto() {
        this.listaimpactos =new ArrayList();
    }
    public void addImpacto(ImpactoEcologico impacto){
        this.listaimpactos.add(impacto);
    }

    @Override
    public String toString() {
        String salida="";
        for(ImpactoEcologico aux:this.listaimpactos){
            salida+=aux.toString()+"___________________";
        }
        return salida;
    }
        
        }
