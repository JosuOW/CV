package Negocio;

import java.util.StringTokenizer;

/**
 *
 * @josune.singaña
 */
public class Fecha {
    private int dia, mes, anio;

    public Fecha(String fecha) {
        setFecha(fecha);
    }

    public Fecha() {
    }

    
    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }
    
    public void setFecha(String fecha){
        StringTokenizer token= new StringTokenizer(fecha,"/");
        this.dia=Integer.parseInt(token.nextToken());
        this.mes=Integer.parseInt(token.nextToken());
        this.anio=Integer.parseInt(token.nextToken());
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    @Override
    public String toString() {
        return this.dia + "/" + this.mes + "/" + this.anio;
    }
}