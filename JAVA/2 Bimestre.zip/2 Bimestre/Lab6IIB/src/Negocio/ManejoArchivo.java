
package Negocio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author LabP41014
 */
public class ManejoArchivo {
    Numero numero;
    File fe; //puntero al archivo entrada
    File fs; //puntero al archivo de salida
    BufferedReader bEntrada;
    BufferedWriter bSalida;
    public ManejoArchivo() {
        numero=new Numero();
        this.fe=new File("datos.txt");
        this.fs=new File("salida.txt");
        try{
        this.bEntrada=new BufferedReader(new FileReader(fe));
        }catch(FileNotFoundException ferror){
            {System.out.println("Archivo no encontrado "+ferror);
            }
        }
         try{
        this.bSalida=new BufferedWriter(new FileWriter(fs,true));
        }catch(IOException fsError)
            {System.out.println("No existe espacio para crear el archivo "+fsError);
         
        }      
    }
    public String lectura(){
        String linea="";
         try{
            linea=bEntrada.readLine();
         }   catch(IOException readError){
             System.out.println("se ha encontrado el fin de archivo"+readError);
         } 
         return linea;
         }
         
    public void escrituraArchivo(String dato){
        try{
            bSalida.write("Factorial:"+dato);
            bSalida.newLine();
        }catch(IOException writeError){
            System.out.println("NO es posible escribir un registro"+writeError);
        }
    }
    
    public void cerrarArchivo(){
        try{
            bEntrada.close();
            bSalida.close();
        }catch(IOException e){
            System.out.println("NO es posible cerrar el archivo"+e);
        }
    }
    public void  procesoArchivo(){
        String linea="";
        long facto;
        int dato;
        
        try{
        while(bEntrada.ready()){
            linea=this.lectura();
            dato=Integer.parseInt(linea);
            facto=numero.factorial(Integer.parseInt(linea));
            this.escrituraArchivo("El factorial de "+dato+" es "+facto);
        }
        }catch(IOException e){
        System.out.println("No es posible lectura del archivo en proceso general "+e);
                }
        }
        
    }




    

