
package Negocio;

/**
 *
 * @author LabP41014
 */
public class Numero {
 
    private int x;

    public Numero() {
    }

    public Numero(int x) {
        this.x = x;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
public long factorial(int x) {
if (x==0) return 1;
else return x*factorial(x-1);
}
    @Override
    public String toString() {
        return "Numero{" + "x=" + x + '}';
    }
    

   
}
