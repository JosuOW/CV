package Negocio;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author josune.singaña
 */
public class Punto extends Figura {
    private double x;
    private double y;

    public Punto(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

   
    public void dibujar(Graphics c) {
       c.setColor(Color.black);
       c.fillOval((int)this.x, (int)this.y, 5, 5);
    }

    @Override
    public double getArea() {
        return 0;
    }

    @Override
    public double getPerimetro() {
        return 0;
    }

    @Override
    public double getVolumen() {
        return 0;
    }

    @Override
    public String toString() {
        return "\nPunto \nx: " + x + "\ny: " + y;
    }

    @Override
    public void dibujar() {
     }
    
}
