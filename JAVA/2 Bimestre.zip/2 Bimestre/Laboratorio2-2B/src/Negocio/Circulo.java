package Negocio;
import java.awt.Color;
import java.awt.Graphics;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
/**
 *
 * @author josune.singaña
 */
public class Circulo extends Punto {
    private double radio;

    public Circulo(double radio, double x, double y) {
        super(x, y);
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    @Override
    public double getArea() {
      DecimalFormatSymbols separadorPersonalizado=new DecimalFormatSymbols();
      separadorPersonalizado.setDecimalSeparator('.');
      DecimalFormat formato=new DecimalFormat("#.##", separadorPersonalizado);
      return Double.parseDouble(formato.format(Math.PI*Math.pow(radio, 2))) ;
    }

    @Override
    public double getPerimetro() {
      DecimalFormatSymbols separadorPersonalizado=new DecimalFormatSymbols();
      separadorPersonalizado.setDecimalSeparator('.');
      DecimalFormat formato=new DecimalFormat("#.##", separadorPersonalizado);
      return Double.parseDouble(formato.format(Math.PI*this.radio*2)) ;
    }

    @Override
    public double getVolumen() {
      return 0;
    }
       @Override
    public void dibujar(Graphics g){
    g.setColor(Color.black);
    g.drawOval((int)super.getX(), (int)super.getY(),(int)this.radio*2, (int)this.radio*2);
    }

    @Override
    public String toString() {
        return "\nCirculo"+super.toString()+"\nRadio: " + radio+"\nEl area es: "+getArea()+"\nEl perimetro es: "+getPerimetro()+"\nEl volumen es: "+getVolumen();
    }
    
}
