
package Negocio;

import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author josune.singana
 */
public class NumeroComplejo {
    private double real, imaginaria;

    public NumeroComplejo() {
    }

    public NumeroComplejo(double real, double imaginaria) {
        this.real = real;
        this.imaginaria = imaginaria;
    }

  

    public void setImaginario() {
        String linea;
        StringTokenizer tokens;
    try
    {
      linea= JOptionPane.showInputDialog("Ingrese parte real e imaginaria de un número complejo separe con espacios ");
      tokens= new StringTokenizer(linea);
      this.real=Double.parseDouble(tokens.nextToken());
      this.imaginaria=Double.parseDouble(tokens.nextToken());
    }
catch(NumberFormatException e)
{
    JOptionPane.showMessageDialog(null, "Favor ingresar números ");
 setImaginario();
 
}
    }
    public double getReal() {
        return real;
    }

    public void setReal(double real) {
        this.real = real;
    }

    public double getImaginaria() {
        return imaginaria;
    }

    public void setImaginaria(double imaginaria) {
        this.imaginaria = imaginaria;
    }
 public NumeroComplejo sumarcomplejo(NumeroComplejo complejo)
 {
     NumeroComplejo complejoAux=new NumeroComplejo();
     complejoAux.real=this.real+complejo.real;
     complejoAux.imaginaria=this.imaginaria+complejo.imaginaria;
     
     return complejoAux;
 }
    @Override
    public String toString() {
         return " {"+" "+real+" , "+imaginaria+" i}"; 
    }
    

    
}
