
package Negocio;

import Vista.jFPrueba;

/**
 *
 * @author LabP41014
 */
public class Principal {

    public static void main(String[] args) {
      jFPrueba jfprueba=new jFPrueba();
      jfprueba.setVisible(true);
    }
    
}
