
package Negocio;

/**
 *
 * @author LabP41014
 */
public class Cliente {
   String nombre;
   private Fecha fechaNacimiento;
   private long cedula;

   

    public Cliente(String Nombre, String fechaNacimiento, long cedula) {
        this.nombre = Nombre;
        this.fechaNacimiento = new Fecha(fechaNacimiento);;
        this.cedula = cedula;
    }

    public Cliente() {
     }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public Fecha getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = new Fecha(fechaNacimiento);
    }

    public double getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    @Override
    public String toString() {
        return "\nCliente\nNombres: " + nombre + "\nFecha Nacimiento: " + fechaNacimiento+"\nCedula: " + cedula;
    }
   
   
}
