
package ListaEncadenada;


import LinkedList.ListaCuenta;
import Negocio.Cliente;


/**
 *
 * @author LabP41014
 */
public class Nodo {
  private Cliente cliente;
    private Nodo enlace;
 ListaCuenta cuentas;
    public Nodo(Cliente cliente) {
        this.cliente = cliente;
        
        this.enlace=null;
    }

    public Nodo(Cliente cliente, ListaCuenta cuenta, Nodo enlace) {
        this.cliente = cliente;
        this.cuentas=cuenta;
        this.enlace = enlace;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Nodo getEnlace() {
        return enlace;
    }

    public void setEnlace(Nodo enlace) {
        this.enlace = enlace;
    }

    public ListaCuenta getCuentas() {
        return cuentas;
    }

    public void setCuentas(ListaCuenta cuentas) {
        this.cuentas = cuentas;
    }
   
    
}
