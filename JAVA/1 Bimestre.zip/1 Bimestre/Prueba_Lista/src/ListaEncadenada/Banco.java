
package ListaEncadenada;

import LinkedList.ListaCuenta;
import Negocio.Cliente;


/**
 *
 * @author LabP41014
 */
public class Banco {
     Nodo inicio;
       ListaCuenta listacuentas= new ListaCuenta();
       
    public Banco() {
        this.inicio=null; //lista vacia
    }
    public boolean isEmpty(){
        return inicio==null;
    }
    
    public void addStart(Cliente cliente,ListaCuenta cuentas){
        if(isEmpty())
            inicio=new Nodo(cliente,cuentas);
        else
            inicio=new Nodo( cliente,cuentas,inicio);        
    }
    
   public void addLast(Cliente cliente,ListaCuenta cuentas){
       if(isEmpty())
            inicio=new Nodo(cliente,cuentas);
        else{
            Nodo p = inicio, q = inicio;
             while (p != null) {
                 q = p;
                p = p.getEnlace();
             }
         q.setEnlace(new Nodo(cliente,cuentas)); 
        }        
    }
   
      public void addOrdenada(Cliente cliente,ListaCuenta cuentas){/// en orden
        Nodo p,q,r;
        p=q=inicio;
        r=new Nodo(cliente,cuentas); 
        boolean bandera=false;
            if (isEmpty()){
                inicio=r; 
                bandera=true;
        }
            else while (p!=null){          
            if (r.getCliente().getNombre().compareTo(p.getCliente().getNombre())<0){
                if(p==inicio){
                    r.setEnlace(inicio);
                    inicio=r;
                }else {
                    q.setEnlace(r);
                    r.setEnlace(p);
                }bandera =true;
                break;
            }
            else{
            q=p;
            p=p.getEnlace();    
            }  
        }
            if(bandera==false){
                q.setEnlace(r);
            }
           
    }
    
    @Override
    public String toString() {
        String salida="";
        Nodo p=inicio;
        while(p!=null){
            salida+=p.getCliente()+"\n------------------\n"+p.getCuentas().toString()+"\n__________________\n";
            p=p.getEnlace();
        }
        return salida;
    }
}
