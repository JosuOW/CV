
package LinkedList;

import Negocio.Cuenta;
import java.util.LinkedList;

/**
 *
 * @author LabP41014
 */
public class ListaCuenta {
    private  LinkedList<Cuenta> listaCuentas;
 public ListaCuenta() {
        this.listaCuentas = new LinkedList<Cuenta>();
    }

    public LinkedList getlistaCuentas() {
        return listaCuentas;
    }

    public void setlistaCuentas(LinkedList listaCuentas) {
        this.listaCuentas = listaCuentas;
    }

   public void agregarCuentaAlInicio(Cuenta cuenta) {
    listaCuentas.addFirst(cuenta);  
    }

    public void agregarCuentaAlFinal(Cuenta cuenta) {
       this.listaCuentas.addLast(cuenta);
     }
  
@Override
    public String toString() {
       String salida="";
       int i=1;
       for(Cuenta aux:listaCuentas)    
            salida+= aux.toString();
       return salida;
           }
       
   
}
