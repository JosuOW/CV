
package Negocio;

import Vista.jFMatriculas;

/**
 *
 * @author LabP41022
 */
public class Principal {

    public static void main(String[] args) {
        jFMatriculas jffmatricula=new jFMatriculas();
        jffmatricula.setVisible(true);
    }
    
}
