
package Negocio;

/**
 *
 * @josune.singaña
 */
public class Vehiculo {
    private String numeroChasis;
    private String color;

    public Vehiculo() {
    }

    public Vehiculo(String NumeroChasis, String color) {
        this.numeroChasis = NumeroChasis;
        this.color = color;
    }

   

    @Override
    public String toString() {
        return "\nVehiculo" + "\n\tNumero Chasis= " + numeroChasis + "\n\tColor= " + color+"\n";
    }
    
}
