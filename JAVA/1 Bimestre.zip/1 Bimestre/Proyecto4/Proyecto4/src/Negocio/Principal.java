
package Negocio;

import Vista.JFEstudiante;
import Vista.EscritorioLimpio;
import Vista.Login;
/**
 * @josune.singaña
 */
public class Principal {
    public static void main(String[] args) {
       EscritorioLimpio escritorio=new EscritorioLimpio();
       escritorio.setVisible(true);
       Login login=new Login();
       login.setVisible(true);
    }
    
}
