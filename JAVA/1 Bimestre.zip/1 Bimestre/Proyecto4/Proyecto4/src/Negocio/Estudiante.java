package Negocio;
/**
 *
 * @josune.singaña
 */
public class Estudiante {
    private String nombres;
    private long cedula;
    private double n1, n2, n3;

    public Estudiante() {
        setEstudiante(nombres,cedula,n1,n2,n3);
    }

    public Estudiante(String nombres, long cedula, double n1, double n2, double n3) {
        this.nombres = nombres;
        this.cedula = cedula;
        this.n1 = n1;
        this.n2 = n2;
        this.n3 = n3;
    }
public void setEstudiante(String nombres, long cedula, double n1, double n2, double n3){
    this.nombres = nombres;
        this.cedula = cedula;
        this.n1 = n1;
        this.n2 = n2;
        this.n3 = n3;
    }
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public long getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    public double getN1() {
        return n1;
    }

    public void setN1(double n1) {
        this.n1 = n1;
    }

    public double getN2() {
        return n2;
    }

    public void setN2(double n2) {
        this.n2 = n2;
    }

    public double getN3() {
        return n3;
    }

    public void setN3(double n3) {
        this.n3 = n3;
    }
    public boolean aprueba(){

         return ((this.n1+this.n2+this.n3)>=24);

    }
    @Override
    public String toString() {
        return "Nombre=" + nombres +"\n"+ 
                "Cédula=" + cedula + "\n"+
                "Nota 1=" + n1 + "\n"+
                "Nota 2=" + n2 + "\n"+
                "Nota 3=" + n3 ;
    }
    
}
