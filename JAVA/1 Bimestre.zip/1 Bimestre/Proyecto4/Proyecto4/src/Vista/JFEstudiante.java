package Vista;

import Negocio.Estudiante;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
/**
 *
 * @josune.singaña
 */
public class JFEstudiante extends javax.swing.JFrame {
 Estudiante estudiante;
    public JFEstudiante() {
        initComponents();
        this.setLocationRelativeTo(this);
        setIcon();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        JTFnombres = new javax.swing.JTextField();
        JTFcedula = new javax.swing.JTextField();
        JTFnota1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JTFnota2 = new javax.swing.JTextField();
        JTFnota3 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTAresultados = new javax.swing.JTextArea();
        JBaceptar = new javax.swing.JButton();
        JBnuevo = new javax.swing.JButton();
        JBsalir = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMnuSalir = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        jScrollPane2.setViewportView(jTextPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("datos");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos estudiante"));

        jLabel1.setText("Nombres:");

        jLabel2.setText("Cédula:");

        jLabel3.setText("Nota1:");

        JTFcedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFcedulaActionPerformed(evt);
            }
        });
        JTFcedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTFcedulaKeyTyped(evt);
            }
        });

        JTFnota1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFnota1ActionPerformed(evt);
            }
        });
        JTFnota1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTFnota1KeyTyped(evt);
            }
        });

        jLabel4.setText("Nota2:");

        jLabel5.setText("Nota3:");

        JTFnota2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFnota2ActionPerformed(evt);
            }
        });
        JTFnota2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTFnota2KeyTyped(evt);
            }
        });

        JTFnota3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFnota3ActionPerformed(evt);
            }
        });
        JTFnota3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTFnota3KeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(JTFnota3, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                    .addComponent(JTFnota2)
                    .addComponent(JTFnota1)
                    .addComponent(JTFcedula)
                    .addComponent(JTFnombres))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(JTFnombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(JTFcedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(JTFnota1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(JTFnota2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(JTFnota3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        JTAresultados.setEditable(false);
        JTAresultados.setColumns(20);
        JTAresultados.setRows(5);
        JTAresultados.setBorder(javax.swing.BorderFactory.createTitledBorder("Resultados"));
        jScrollPane1.setViewportView(JTAresultados);

        JBaceptar.setText("Aceptar");
        JBaceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBaceptarActionPerformed(evt);
            }
        });

        JBnuevo.setText("Nuevo");
        JBnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBnuevoActionPerformed(evt);
            }
        });

        JBsalir.setText("Salir");
        JBsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBsalirActionPerformed(evt);
            }
        });

        jMnuSalir.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_CANCEL, java.awt.event.InputEvent.ALT_DOWN_MASK | java.awt.event.InputEvent.CTRL_DOWN_MASK));
        jMenuItem1.setText("Salir");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMnuSalir.add(jMenuItem1);

        jMenuBar1.add(jMnuSalir);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(JBaceptar)
                        .addGap(17, 17, 17)
                        .addComponent(JBnuevo))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(JBsalir))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JBaceptar)
                        .addComponent(JBnuevo))
                    .addComponent(JBsalir))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JBnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBnuevoActionPerformed
       this.JTFnombres.setText("");
        this.JTFcedula.setText("");
         this.JTFnota1.setText("");
          this.JTFnota2.setText("");
           this.JTFnota3.setText("");
            this.JTAresultados.setText("");
    }//GEN-LAST:event_JBnuevoActionPerformed

    private void JTFnota1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFnota1ActionPerformed
      double aux=Double.parseDouble(this.JTFnota1.getText());
      if(aux<0 || aux>10){
          this.JTFnota1.setText("");
          JOptionPane.showMessageDialog(null, " Los datos solo entre 1 y 10 ");
      }else{
          this.JTFnota2.requestFocus();
      }
    }//GEN-LAST:event_JTFnota1ActionPerformed

    private void JTFcedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFcedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JTFcedulaActionPerformed

    private void JBaceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBaceptarActionPerformed
    String salida=new String();
        this.estudiante= new Estudiante(
      this.JTFnombres.getText(),
     Long.parseLong(this.JTFcedula.getText()),
    Double.parseDouble(this.JTFnota1.getText()),
    Double.parseDouble(this.JTFnota2.getText()),
    Double.parseDouble(this.JTFnota3.getText()));
   salida+=estudiante;
   salida+="\n"+(estudiante.aprueba()?"Aprueba":"Reprueba");
   this.JTAresultados.setText(salida);
   
    }//GEN-LAST:event_JBaceptarActionPerformed

    private void JBsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBsalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_JBsalirActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void JTFnota1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFnota1KeyTyped
     char variable=evt.getKeyChar();
     if(Character.isLetter(variable)){
         getToolkit().beep();
         evt.consume();
         JOptionPane.showMessageDialog(null, " Ingrese números");
     }
    }//GEN-LAST:event_JTFnota1KeyTyped

    private void JTFnota2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFnota2KeyTyped
            char variable=evt.getKeyChar();
     if(Character.isLetter(variable)){
         getToolkit().beep();
         evt.consume();
         JOptionPane.showMessageDialog(null, " Ingrese números");
     }
    }//GEN-LAST:event_JTFnota2KeyTyped

    private void JTFnota3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFnota3KeyTyped
            char variable=evt.getKeyChar();
     if(Character.isLetter(variable)){
         getToolkit().beep();
         evt.consume();
         JOptionPane.showMessageDialog(null, " Ingrese números");
     }
    }//GEN-LAST:event_JTFnota3KeyTyped

    private void JTFcedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFcedulaKeyTyped
           char variable=evt.getKeyChar();
     if(Character.isLetter(variable)){
         getToolkit().beep();
         evt.consume();
         JOptionPane.showMessageDialog(null, " Ingrese números");
     }
    }//GEN-LAST:event_JTFcedulaKeyTyped

    private void JTFnota2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFnota2ActionPerformed
       double aux=Double.parseDouble(this.JTFnota2.getText());
      if(aux<0 || aux>10){
          this.JTFnota2.setText("");
          JOptionPane.showMessageDialog(null, " Los datos solo entre 1 y 10 ");
      }else{
          this.JTFnota3.requestFocus();
      }
    }//GEN-LAST:event_JTFnota2ActionPerformed

    private void JTFnota3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFnota3ActionPerformed
     double aux=Double.parseDouble(this.JTFnota1.getText());
      if(aux<0 || aux>10){
          this.JTFnota3.setText("");
          JOptionPane.showMessageDialog(null, " Los datos solo entre 1 y 10 ");
      }
    }//GEN-LAST:event_JTFnota3ActionPerformed
    
    public void setIcon(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("estudiante.png")));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFEstudiante().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBaceptar;
    private javax.swing.JButton JBnuevo;
    private javax.swing.JButton JBsalir;
    private javax.swing.JTextArea JTAresultados;
    private javax.swing.JTextField JTFcedula;
    private javax.swing.JTextField JTFnombres;
    private javax.swing.JTextField JTFnota1;
    private javax.swing.JTextField JTFnota2;
    private javax.swing.JTextField JTFnota3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenu jMnuSalir;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
