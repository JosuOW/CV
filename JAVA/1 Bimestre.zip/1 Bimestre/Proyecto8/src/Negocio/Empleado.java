
package Negocio;

/**
 *
 * josune.singaña
 */
public class Empleado {
    private String nombres;
    private Fecha fechaNacimiento;
    private Fecha fechaIngreso;

    public Empleado(String nombres, Fecha fechaNacimiento, Fecha fechaIngreso) {
        this.nombres = nombres;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaIngreso = fechaIngreso;
    }
      public Empleado(String nombres, String fechaNacimiento, String fechaIngreso) {
        this.nombres = nombres;
        this.fechaNacimiento = new Fecha(fechaNacimiento);
        this.fechaIngreso =new Fecha(fechaIngreso);
    }

    @Override
    public String toString() {
        return "\n" + "nombres=" + nombres + ", fechaNacimiento=" + fechaNacimiento + ", fechaIngreso=" + fechaIngreso + '\n';
    }
    
      
}
