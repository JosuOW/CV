
package Negocio;

/**
 *
 * @josune.singaña
 */
public class ListaEmpleados {
    
}
