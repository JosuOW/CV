package negocio;
import vista.JFEcuacion;
public class Principal {

    public static void main(String[] args) {
        JFEcuacion jfEstudiante = new JFEcuacion();
        jfEstudiante.setVisible(true);
    }
    
}