
package Negocio;

import Visual.Fondo;

/**
 *
 * @author Home
 */
public class Principal {

    public static void main(String[] args) {
        ManejoStrings nombre=new ManejoStrings("Juan Pedro Rosales Teran");
        System.out.println(nombre.getIniciales());
        Fondo fondo1= new Fondo();
        fondo1.setVisible(true);
    }
    
}
