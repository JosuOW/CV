
package Negocio;

/**
 *
 * @author Home
 */
public class ManejoStrings {
String nombre;

    public ManejoStrings(String nombre) {
        this.nombre = nombre;
    }
public String getIniciales(){
   int pos;
   int x;
    String iniciales;
    iniciales="";
   
    for(int i=0; i<5;i++){
      x=this.nombre.indexOf(" ")+i;
        pos=i+this.nombre.indexOf("",x);
       System.out.println("sasasasas "+pos);
    iniciales += String.valueOf( this.nombre.charAt( pos)); 

   }
 return iniciales;

}

   
    @Override
    public String toString() {
        
        return this.nombre; 
    }


}
