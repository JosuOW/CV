package Negocio;

import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @josune.singaña
 */
public class Ecuacion {
    private double a,b,c;

    public Ecuacion() {
    }

    public Ecuacion(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public void setEcuacion() {
        String linea;
        StringTokenizer token;
    try
    {
      linea= JOptionPane.showInputDialog(null,"Ingrese a,b,c separe con espacios ");
      token= new StringTokenizer(linea);
      this.a=Double.parseDouble(token.nextToken());
      this.b=Double.parseDouble(token.nextToken());
      this.c=Double.parseDouble(token.nextToken());
    }
catch(NumberFormatException e)
{
    JOptionPane.showMessageDialog(null, "Error. Ingrese números ","Ingreso errado ",JOptionPane.ERROR_MESSAGE);
 setEcuacion();
 
}
    }
    public double operacionRaiz(){
        double result;
        double potencia;
        potencia= Math.pow(this.b, 2);
        result= Math.sqrt(potencia-(4*this.a*this.c));
        return result;
    }

    @Override
    public String toString() {
        return " Los números {"+"a="+a+" b="+b+" c="+c+" }"; 
    }
}

