package Negocio;

import javax.swing.JOptionPane;

/**
 *
 * @author josune.singaña
 */
public class Principal {
 
    public static void main(String[] args) {
        String salida="";
        int opcion;
        // Instanciar objetos
        Numero numero1=new Numero();
        do{
        numero1.setNumero();
        /*
        System.out.println(numero1);
        System.out.println(numero1+ (numero1.esPar()?" Es Par": " Es Impar"));
//        if (numero1.esPar())
//        {
//             System.out.println(numero1.getX()+" Es par");
//        }else{
//            System.out.println(numero1.getX()+" Es impar");
//        }
        System.out.println(numero1+ (numero1.esPrimo()?" Es Primo": " No Es Primo"));
        System.out.println(numero1+ (numero1.esPerfecto()?" Es Perfecto": " No Es Perfecto"));
        System.out.println(" La sumatoria de los dígitos del "+numero1+" es "+numero1.sumaDigitos());
        System.out.println("El factorial de "+numero1+" es "+numero1.suFactorial());
        */
        salida+=(numero1)+"\n";
        salida+=(numero1+ (numero1.esPar()?" Es Par": " Es Impar"))+"\n";
        salida+=(numero1+ (numero1.esPrimo()?" Es Primo": " No Es Primo"))+"\n";
        salida+=(numero1+ (numero1.esPerfecto()?" Es Perfecto": " No Es Perfecto"))+"\n";
        salida+=(" La sumatoria de los dígitos del "+numero1+" es "+numero1.sumaDigitos())+"\n";
        salida+=("El factorial de "+numero1+" es "+numero1.suFactorial())+"\n";
     opcion=JOptionPane.showConfirmDialog(null, "Continua....?", "Opciones", JOptionPane.YES_NO_OPTION);
        }while(opcion==JOptionPane.YES_OPTION);
        salida+=("¡Gracias por usar el programa!")+"\n";
        JOptionPane.showMessageDialog(null, salida,"RESULTADOS", JOptionPane.INFORMATION_MESSAGE);
        //System.out.println(" ¡Gracias por usar el programa! ");
 }
}
