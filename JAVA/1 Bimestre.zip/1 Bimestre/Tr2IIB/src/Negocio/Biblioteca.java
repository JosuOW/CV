
package Negocio;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
/**
 *
 * @author LabP41014
 */
public class Biblioteca {
   private List <Libro> listaLibros;

    public Biblioteca() {
        this.listaLibros = new Vector();
    }
    public void ordenarlistaTitulo(){
    Collections.sort(listaLibros, new CompararTitulo());
    }
   public void ordenarlistaAutor(){
    Collections.sort(listaLibros, new CompararAutor());
    }
    

   public Object libroMasAntiguo(){
       return   Collections.max(listaLibros, new CompararAnio());
    }
   public Object libroMasNuevo(){
       return   Collections.max(listaLibros, new CompararAnio());
    }
   public Object libroMasCaro(){
       return   Collections.max(listaLibros, new CompararPrecios());
    }
   public Object libroMasbarato(){
       return   Collections.max(listaLibros, new CompararPrecios());
    }
   public void addLibro(Libro libro){
        listaLibros.add(libro);
    }
   public void eliminarLibro(String titulo){
        Libro libro;
       Iterator itr= this.listaLibros.iterator();
        
      while (itr.hasNext())
            {
       libro =(Libro)itr.next();
        if(titulo.equals(libro.getTitulo())){
               itr.remove();
           }
    }
     
    }

    @Override
    public String toString() {
        String salida="";
       for(Libro aux:listaLibros)    
           salida+=aux.toString()+"\n__________________\n";
       return salida;
           } 
    }
   

