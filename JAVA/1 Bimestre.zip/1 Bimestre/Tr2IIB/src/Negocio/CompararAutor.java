
package Negocio;

import java.util.Comparator;

/**
 *
 * @author LabP41014
 */
public class CompararAutor implements Comparator {

    @Override
    public int compare(Object o1, Object o2) {
     Libro libro1=(Libro)o1;
     Libro libro2=(Libro)o2;
       if( libro1.getAutor().compareTo(libro2.getAutor())>0)
    return 1; 
       else
           if( libro1.getAutor().compareTo(libro2.getAutor())<0)
         return -1; 
       else
         return 0; 
    }
    
}
