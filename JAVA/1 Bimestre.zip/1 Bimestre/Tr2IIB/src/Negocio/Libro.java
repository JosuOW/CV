/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Negocio;

/**
 *
 * @author LabP41014
 */
public class Libro {
   private String titulo;
   private String Autor;
   private int AnioEdicion;
   private double precio;

    public Libro(String titulo, String Autor, int AnioEdicion, double precio) {
        this.titulo = titulo;
        this.Autor = Autor;
        this.AnioEdicion = AnioEdicion;
        this.precio = precio;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String Autor) {
        this.Autor = Autor;
    }

    public int getAnioEdicion() {
        return AnioEdicion;
    }

    public void setAnioEdicion(int AñoEdicion) {
        this.AnioEdicion = AñoEdicion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Libro\nTítulo: " + titulo + "\nAutor: " + Autor + "\nAño Edición: " + AnioEdicion + "\nPrecio: " + precio ;
    }
   
}
