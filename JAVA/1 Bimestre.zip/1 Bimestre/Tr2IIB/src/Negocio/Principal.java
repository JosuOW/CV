/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Negocio;

import Visual.jFLibro;

/**
 *
 * @author LabP41014
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   jFLibro    jflibro=new jFLibro();
   jflibro.setVisible(true);
    }
}
