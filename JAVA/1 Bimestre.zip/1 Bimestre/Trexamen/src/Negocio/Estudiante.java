package Negocio;

/**
 *
 * @author Home
 */
public class Estudiante {
    private String nombre;
    private long cedula;

    public Estudiante(String nombre, long cedula) {
        this.nombre = nombre;
        this.cedula = cedula;
    }

    public Estudiante() {
    }

    @Override
    public String toString() {
        return "Datos estudiante:\nNombre:" + nombre + " \nNúmero de Cédula=" + cedula + '\n';
    }
    
}
