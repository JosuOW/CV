
package Negocio;

import java.util.ArrayList;

/**
 *
 * @author Home
 */
public class ListaEstudianteMateria {
    ArrayList <EstudianteMateria> listaEstudiantes;

    public ListaEstudianteMateria() {
        this.listaEstudiantes = new ArrayList();
    }

   public void addEstudianteLista(EstudianteMateria estudiantemateria){
       listaEstudiantes.add(estudiantemateria);
   }

    @Override
    public String toString() {
        String salida="";
        for(EstudianteMateria aux:listaEstudiantes)
        salida+=aux.toString();
            return salida;
                }

}
