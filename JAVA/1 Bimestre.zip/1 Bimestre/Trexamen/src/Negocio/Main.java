package Negocio;
//Josune

import Visual.JFEstudiante;

public class Main {
    public static void main(String[] args) {
        JFEstudiante jfestudiante = new JFEstudiante();
        jfestudiante.setVisible(true);
    }
    
}
