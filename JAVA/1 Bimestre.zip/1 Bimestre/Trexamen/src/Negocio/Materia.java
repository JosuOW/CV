
package Negocio;

/**
 *
 * @author Home
 */
public class Materia {
    private String nombreMateria;
    private String codigo;

    public Materia(String nombreMateria, String codigo) {
        this.nombreMateria = nombreMateria;
        this.codigo = codigo;
    }

    public Materia() {
    }

    @Override
    public String toString() {
        return "Materia: " + nombreMateria + " \nCódigo: " + codigo + '\n';
    }
    
}
