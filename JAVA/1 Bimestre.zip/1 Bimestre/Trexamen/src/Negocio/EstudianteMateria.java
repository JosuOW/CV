
package Negocio;

import java.util.ArrayList;

/**
 *
 * @author Home
 */
public class EstudianteMateria {
    private Estudiante estudiante;
    ArrayList <Materia> listaMaterias;

    public EstudianteMateria(String nombre, long cedula) {
        this.estudiante =new Estudiante(nombre,cedula);
        this.listaMaterias=new ArrayList();
    }
   public void addMateriaLista(Materia materia){
       listaMaterias.add(materia);
   }

    @Override
    public String toString() {
        String salida="";
        for(Materia aux:listaMaterias)
        salida+=aux.toString();
                return "REGISTRO \nEstudiante: " + estudiante + "\nLista Materias: " + salida + '\n';
    }
   
   
   
   
}
