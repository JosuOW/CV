
package Negocio;

import BaseDatos.ConexionBD;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
/**
 *
 * @author Home
 */
public class Estudiante {
     int codigo;
    String nombres,apellidos,cedula,direccion,telefono,fechaNacimiento;
  
       

    public Estudiante() {
    }

    public Estudiante(int codigo, String fechaNacimiento, String nombres, String apellidos, String cedula, String direccion, String telefono) {
        this.codigo = codigo;
        this.fechaNacimiento = fechaNacimiento;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.cedula = cedula;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }


    public Object buscarString(String atributoBuscar,String condicione){
        Estudiante estudiante=new Estudiante();
            String condicion="\""+condicione+"\"";
        try {
            ConexionBD con = new ConexionBD();
   Connection conexion= con.conexion(); 
            String consulta = "SELECT * FROM estudiantes WHERE "+atributoBuscar+" LIKE "+condicion; 
           Statement st= conexion.createStatement(); 
            ResultSet resultado = st.executeQuery(consulta);
            if (resultado.next()) {
               int codigo = resultado.getInt("codigo_e"); 
                String nombres = resultado.getString("nombre_e"); 
                String apellidos = resultado.getString("apellido_e"); 
                String fechaNacimiento = resultado.getString("fechaNacimiento_e"); 
                 String cedula = resultado.getString("cedula_e"); 
                String direccion = resultado.getString("direccion"); 
                String telefonoe = resultado.getString("telefono");  
               estudiante= new Estudiante(codigo, fechaNacimiento, nombres, apellidos, cedula, direccion, telefonoe);
            } else {
                System.out.println("No se encontró ningún estudiante con el " + atributoBuscar+" ="+ condicion);
            }

        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return estudiante;
        
    }
    
    public Object buscarInt(String atributoBuscar,int condicione){
        Estudiante estudiante=new Estudiante();
            int condicion=condicione;
        try {
            ConexionBD con = new ConexionBD();
   Connection conexion= con.conexion(); 
            String consulta = "SELECT * FROM estudiantes WHERE "+atributoBuscar+"="+condicion; 
           Statement st= conexion.createStatement(); 
            ResultSet resultado = st.executeQuery(consulta);
            if (resultado.next()) {
               int codigo = resultado.getInt("codigo_e"); 
                String nombres = resultado.getString("nombre_e"); 
                String apellidos = resultado.getString("apellido_e"); 
                String fechaNacimiento = resultado.getString("fechaNacimiento_e"); 
                 String cedula = resultado.getString("cedula_e"); 
                String direccion = resultado.getString("direccion"); 
                String telefonoe = resultado.getString("telefono");  
               estudiante= new Estudiante(codigo, fechaNacimiento, nombres, apellidos, cedula, direccion, telefonoe);
            } else {
                System.out.println("No se encontró ningún estudiante con el " + atributoBuscar+" = "+ condicion);
      
            }

        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return estudiante;
        
    }
  public boolean buscarPrestamo(int codigo_estudiante) {
      boolean encontrado = false;
    try {
                   ConexionBD con = new ConexionBD();
   Connection conn= con.conexion(); 
        
        String sql = "SELECT * FROM estudiantes_libros WHERE codigo_e = ? AND estado = 'No entregado'";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, codigo_estudiante);
        ResultSet rs = stmt.executeQuery();
   
        if (rs.next()) {
            encontrado = true;
        }
        
    } catch (SQLException e) {
        // Manejo de excepciones
        e.printStackTrace();
    }
    return encontrado;
}
  

}
