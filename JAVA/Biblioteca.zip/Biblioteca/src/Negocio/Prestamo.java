
package Negocio;

import BaseDatos.ConexionBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Home
 */
public class Prestamo {
    int codigo_e;
    int codigo_l;
     String fechaPrestamo;
    String estado;
    String fechaEntrega;

    public Prestamo() {
    }

    public Prestamo(int codigo_e, int codigo_l, String fechaPrestamo, String estado, String fechaEntrega) {
        this.codigo_e = codigo_e;
        this.codigo_l = codigo_l;
        this.fechaPrestamo = fechaPrestamo;
        this.estado = estado;
        this.fechaEntrega = fechaEntrega;
    }

    public int getCodigo_e() {
        return codigo_e;
    }

    public void setCodigo_e(int codigo_e) {
        this.codigo_e = codigo_e;
    }

    public int getCodigo_l() {
        return codigo_l;
    }

    public void setCodigo_l(int codigo_l) {
        this.codigo_l = codigo_l;
    }

    public String getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(String fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }
public Object buscarIntPrestamo(String atributoBuscar,int condicione){
        Prestamo prestamo=new Prestamo();
            int condicion=condicione;
        try {
            ConexionBD con = new ConexionBD();
  Connection conexion= con.conexion(); 
            String consulta = "SELECT * FROM estudiantes_libros WHERE "+atributoBuscar+" LIKE "+condicion; 
           Statement st= conexion.createStatement(); 
            ResultSet resultado = st.executeQuery(consulta);
            if (resultado.next()) {
               int codigoe = resultado.getInt("codigo_e"); 
               int codigol = resultado.getInt("codigo_l"); 
                String fecha_p = resultado.getString("fecha_p"); 
                String estado = resultado.getString("estado"); 
                String fecha_e = resultado.getString("fecha_e"); 
                 prestamo= new Prestamo(codigoe, codigol,fecha_p,estado,fecha_e);
            } else {
                System.out.println("No se encontró ningún libro con el " + atributoBuscar+" = "+ condicion);
           
            }

        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return prestamo;
        
    }
    public Object buscarStringPrestamo(String atributoBuscar,String condicione){
      Prestamo prestamo=new Prestamo();
             String condicion="\""+condicione+"\"";
        try {
            ConexionBD con = new ConexionBD();
   Connection conexion= con.conexion(); 
            String consulta = "SELECT * FROM estudiantes_libros WHERE "+atributoBuscar+" LIKE "+condicion; 
           Statement st= conexion.createStatement(); 
            ResultSet resultado = st.executeQuery(consulta);
            if (resultado.next()) {
               int codigoe = resultado.getInt("codigo_e"); 
               int codigol = resultado.getInt("codigo_l"); 
                String fecha_p = resultado.getString("fecha_p"); 
                String estado = resultado.getString("estado"); 
                String fecha_e = resultado.getString("fecha_e"); 
                 prestamo= new Prestamo(codigoe, codigol,fecha_p,estado,fecha_e);
            } else {
                System.out.println("No se encontró ningún libro con el " + atributoBuscar+" ="+ condicion);
            }

        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return prestamo;
        
    }
    public Object buscarPrestamo(String atributoBuscar,String atributoBuscar2,int condicione,int condicion2){
        Prestamo prestamo=new Prestamo();
            int condicion=condicione;
            int condicionl=condicion2;
        try {
            ConexionBD con = new ConexionBD();
   Connection conexion= con.conexion(); 
           String consulta = "SELECT * FROM estudiantes_libros WHERE "+atributoBuscar+"="+condicion+" AND "+atributoBuscar2+"="+condicionl; 
           Statement st= conexion.createStatement(); 
            ResultSet resultado = st.executeQuery(consulta);
            if (resultado.next()) {
               int codigoe = resultado.getInt("codigo_e"); 
               int codigol = resultado.getInt("codigo_l"); 
                String fecha_p = resultado.getString("fecha_p"); 
                String estado = resultado.getString("estado"); 
                String fecha_e = resultado.getString("fecha_e"); 
                 prestamo= new Prestamo(codigoe, codigol,fecha_p,estado,fecha_e);
            } else {
                System.out.println("No se encontró ningún libro con el " + atributoBuscar+" = "+ condicion);
           
            }

        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return prestamo;
        
    }
 
   public int contarPrestamos(int codigoLibro) {
    int cantidad = 0;
    try {
        ConexionBD con = new ConexionBD();
   Connection conn= con.conexion();
       
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS cantidad FROM Prestamo WHERE codigo_l = " + codigoLibro+"AND edtado=0");
        if (rs.next()) {
            cantidad = rs.getInt("cantidad");
        }
        rs.close();
        stmt.close();
        conn.close();
    } catch (SQLException ex) {
        System.out.println("Error al contar préstamos: " + ex.getMessage());
    }
    return cantidad;
} 
    
    public void reducirDisponibles(int codigo){ 
        String url = "jdbc:mysql://localhost:3306/base_libros"; 
        String usuario = "root"; 
        String password = "root"; 
        try{
            Connection conexion = DriverManager.getConnection(url, usuario, password); 
            String sql="UPDATE libro SET copias_l = copias_l - 1 WHERE codigo_l = ?";
            PreparedStatement pps= conexion.prepareStatement(sql);
            pps.setInt(1, codigo); 
            pps.executeUpdate();
            System.out.println("Si reduce");
        }catch(SQLException e){
            e.printStackTrace();
        }
}

     public void recuperarDisponibles(int codigo){ 
        String url = "jdbc:mysql://localhost:3306/base_libros"; 
        String usuario = "root"; 
        String password = "root"; 
        try{
            Connection conexion = DriverManager.getConnection(url, usuario, password); 
            String sql="UPDATE libro SET copias_l = copias_l + 1 WHERE codigo_l = ?";
            PreparedStatement pps= conexion.prepareStatement(sql);
            pps.setInt(1, codigo); 
            pps.executeUpdate();
            System.out.println("Si reduce");
        }catch(SQLException e){
            e.printStackTrace();
        }
}
    
}
