
package Negocio;

import BaseDatos.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
/**
 *
 * @author Home
 */
public class Libro {
     private int codigo;
     private String titulo;
      private String autor;
   private int copias;
private int total;
    public Libro() {
    }

    public Libro(int codigo, String titulo, String autor, int copias,int total) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.autor = autor;
        this.copias =copias;
        this.total=total;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getCopias() {
        return copias;
    }

    public void setCopias(int copias) {
        this.copias = copias;
    }
    
    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    
    
    
  public Object buscarStringLibro(String atributoBuscar,String condicione){
        Libro libro=new Libro();
            String condicion="\""+condicione+"\"";
        try {
            ConexionBD con = new ConexionBD();
   Connection conexion= con.conexion(); 
            String consulta = "SELECT * FROM libros WHERE "+atributoBuscar+" LIKE "+condicion; 
           Statement st= conexion.createStatement(); 
            ResultSet resultado = st.executeQuery(consulta);
            if (resultado.next()) {
               int codigo = resultado.getInt("codigo_l"); 
                String titulo = resultado.getString("titulo_l"); 
                String autor = resultado.getString("autor_l"); 
                int copias = resultado.getInt("copias_l"); 
                int total= resultado.getInt("total_l");
                 libro= new Libro(codigo, titulo, autor, copias,total);
            } else {
                System.out.println("No se encontró ningún libro con el " + atributoBuscar+" ="+ condicion);
            }

        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return libro;
        
    }
    
    public Object buscarIntLibro(String atributoBuscar,int condicione){
        Libro libro=new Libro();
            int condicion=condicione;
        try {
            ConexionBD con = new ConexionBD();
   Connection conexion= con.conexion(); 
           String consulta = "SELECT * FROM libros WHERE "+atributoBuscar+" LIKE "+condicion; 
           Statement st= conexion.createStatement(); 
            ResultSet resultado = st.executeQuery(consulta);
            if (resultado.next()) {
               int codigo = resultado.getInt("codigo_l"); 
                String titulo = resultado.getString("titulo_l"); 
                String autor = resultado.getString("autor_l"); 
                int copias = resultado.getInt("copias_l");
                int total= resultado.getInt("total_l");
                 libro= new Libro(codigo, titulo, autor, copias, total);
            } else {
                System.out.println("No se encontró ningún libro con el " + atributoBuscar+" = "+ condicion);
           
            }

        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
        return libro;
        
    }
    
    
    
 public void actualizarDatos(int num,String codigo){
      ConexionBD con = new ConexionBD();
        try (Connection connection= con.conexion()) {            
            PreparedStatement st = null;           
            try{
            
                String query = "UPDATE libros SET copias_l="+num+" WHERE codigo_l="+codigo;
                st=connection.prepareStatement(query);
                
                st.executeUpdate();
                System.out.println("Libro actualizado");
            
            }catch(SQLException e){
                System.out.println(e);
            }
        }catch(SQLException e){
        System.out.println(e);        
        } 
    }
 
 public boolean buscarPrestamo(int codigo_estudiante) {
      boolean encontrado = false;
    try {
                   ConexionBD con = new ConexionBD();
   Connection conn= con.conexion(); 
        
        String sql = "SELECT * FROM estudiantes_libros WHERE codigo_l = ? AND estado = 'No entregado'";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, codigo_estudiante);
        ResultSet rs = stmt.executeQuery();
   
        if (rs.next()) {
            encontrado = true;
        }
        
    } catch (SQLException e) {
        // Manejo de excepciones
        e.printStackTrace();
    }
    return encontrado;
}
  
}
