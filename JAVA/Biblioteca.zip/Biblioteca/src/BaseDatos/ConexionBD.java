
package BaseDatos;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;

/**
 *
 * @author grupo5
 */
public class ConexionBD {
    java.sql.Connection cn;
    public Connection conexion() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            cn= DriverManager.getConnection("jdbc:mysql://localhost:3306/base_libros","root","root");
        System.out.println("Se hizo la conexión de forma correcta");
    }catch(Exception e){
        System.out.println(e.getMessage());
    }return cn;
    }
   
Statement createStatement(){
    throw new UnsupportedOperationException("No soportado");
    
}
    
   
}
