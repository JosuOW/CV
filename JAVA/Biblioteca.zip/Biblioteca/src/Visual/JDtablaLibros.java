package Visual;

import BaseDatos.ConexionBD;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class JDtablaLibros extends javax.swing.JDialog {

    DefaultTableModel modelo= new DefaultTableModel();
    Connection con = new ConexionBD().conexion();
    ResultSet rs;
    int codigolibro=-1;
    String Titulo;
    
    
    public JDtablaLibros() {
        initComponents();
           this.JTFbusqueda.setEnabled(false);
        mostrartabla();
        this.setLocationRelativeTo(null);
    }
    
    public int getCodigolibro() {
        return codigolibro;
    }

    public String getTitulo() {
        return Titulo;
    }
    
    
    public void mostrartabla(){
        modelo.addColumn("Codigo");
        modelo.addColumn("Título");
        modelo.addColumn("Autor");
        modelo.addColumn("Copias Disponibles");
        modelo.addColumn("Total Copias");
        modelo.setRowCount(0);
        String sql="SELECT * FROM libros";     
        String datos[]=new String[5];
        try {
            rs = con.createStatement().executeQuery(sql);
            while(rs.next()==true){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                modelo.addRow(datos);
            }
            jTabla.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(JDtablaLibros.class.getName()).log(Level.SEVERE, null, ex);
        }                   
    }
    
    public void buscar(String buscar){
        modelo.setRowCount(0);
        String sql = null;
        switch(this.JCBbusqueda.getSelectedIndex()){
            case 0:
                sql="SELECT * FROM libro WHERE codigo_l LIKE '%"+buscar+"%'";     
                break;
            case 1:
                sql="SELECT * FROM libro WHERE titulo_l LIKE '%"+buscar+"%'";
                break;
            case 2:
                sql="SELECT * FROM libro WHERE autor_l LIKE '%"+buscar+"%'";
                break;
            
        } 
        
        String datos[]=new String[5];
        try {
            rs = con.createStatement().executeQuery(sql);
            while(rs.next()==true){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                modelo.addRow(datos);
            }
            jTabla.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(JDtablaLibros.class.getName()).log(Level.SEVERE, null, ex);
        }                   
    }  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        body = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        JTFbusqueda = new javax.swing.JTextField();
        JCBbusqueda = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTabla = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        Title1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(750, 430));
        jPanel1.setPreferredSize(new java.awt.Dimension(750, 430));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        body.setBackground(new java.awt.Color(255, 255, 255));
        body.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(body, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 153, 255));
        jSeparator2.setPreferredSize(new java.awt.Dimension(250, 10));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 480, 10));

        JTFbusqueda.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        JTFbusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                JTFbusquedaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTFbusquedaKeyTyped(evt);
            }
        });
        jPanel1.add(JTFbusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 470, -1));

        JCBbusqueda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Codigo", "Titulo", "Autor" }));
        JCBbusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCBbusquedaActionPerformed(evt);
            }
        });
        jPanel1.add(JCBbusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 50, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Buscar:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 70, 20));

        jTabla = new JTable(){
            public boolean isCellEditable(int row, int column)
            {
                for(int i =0;i<jTabla.getRowCount();i++){
                    if(row==i){
                        return false;
                    }
                }
                return true;
            }
        };
        jTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTabla);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 760, 310));

        jPanel2.setBackground(new java.awt.Color(21, 101, 192));

        Title1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Title1.setForeground(new java.awt.Color(255, 255, 255));
        Title1.setText("Libros");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(Title1)
                .addContainerGap(675, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(Title1)
                .addGap(0, 8, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 758, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablaMouseClicked
        if(evt.getClickCount()==2){
            int fila=jTabla.getSelectedRow();
            int cantidad=Integer.parseInt(jTabla.getValueAt(fila, 5).toString());
            if(cantidad>0){
            codigolibro= Integer.parseInt(jTabla.getValueAt(fila, 0).toString());
            Titulo=(String) jTabla.getValueAt(fila, 1);
            this.dispose();}else{
                JOptionPane.showMessageDialog(null, "No hay existencias del libro seleccionado en este momento");
            }
        }
    }//GEN-LAST:event_jTablaMouseClicked

    private void JTFbusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFbusquedaKeyReleased
        buscar(this.JTFbusqueda.getText());
    }//GEN-LAST:event_JTFbusquedaKeyReleased

    private void JTFbusquedaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFbusquedaKeyTyped
        char variable=evt.getKeyChar();
        if(Character.isLetter(variable)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, " Ingrese números");
            JTFbusqueda.requestFocus();
        }
    }//GEN-LAST:event_JTFbusquedaKeyTyped

    private void JCBbusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCBbusquedaActionPerformed
         this.JTFbusqueda.setEnabled(true);
        this.JTFbusqueda.requestFocus();
    }//GEN-LAST:event_JCBbusquedaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDtablaLibros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDtablaLibros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDtablaLibros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDtablaLibros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDtablaLibros dialog = new JDtablaLibros();
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> JCBbusqueda;
    private javax.swing.JTextField JTFbusqueda;
    private javax.swing.JLabel Title1;
    private javax.swing.JPanel body;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTabla;
    // End of variables declaration//GEN-END:variables
}
