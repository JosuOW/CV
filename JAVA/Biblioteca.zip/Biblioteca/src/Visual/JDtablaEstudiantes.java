package Visual;

import BaseDatos.ConexionBD;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class JDtablaEstudiantes extends javax.swing.JDialog {
    
    DefaultTableModel modelo= new DefaultTableModel();
    Connection con = new ConexionBD().conexion();
    ResultSet rs;
    int codigoestudiante;
    String Nombre;
    
    public JDtablaEstudiantes() {
        initComponents();
   this.JTFbusqueda.setEnabled(false);
       modelo.addColumn("id Estudiante");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        modelo.addColumn("Fecha Nacimiento");
        modelo.addColumn("Cedula");
        modelo.addColumn("Direccion");
        modelo.addColumn("Telefono");
        mostrartabla();
    }

    public void mostrartabla(){
        modelo.setRowCount(0);
        String sql="SELECT * FROM estudiantes";     
        String datos[]=new String[7];
        try {
            rs = con.createStatement().executeQuery(sql);
            while(rs.next()==true){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                modelo.addRow(datos);
            }
            jTabla.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(JDtablaEstudiantes.class.getName()).log(Level.SEVERE, null, ex);
        }                   
    }
    
    public int getCodigoestudiante() {
        return codigoestudiante;
    }

    public String getNombre() {
        return Nombre;
    }
    
    
    
    public void buscar(String buscar){
        modelo.setRowCount(0);
        String sql = null;
        switch(this.JCBbuscar.getSelectedIndex()){
            case 0:
                sql="SELECT * FROM estudiantes WHERE codigo_e LIKE '%"+buscar+"%'";     
                break;
            case 1:
                sql="SELECT * FROM estudiantes WHERE nombre_e LIKE '%"+buscar+"%'";
                break;
            case 2:
                sql="SELECT * FROM estudiantes WHERE apellido_e LIKE '%"+buscar+"%'";
                break;
            case 3:
                sql="SELECT * FROM estudiantes WHERE fechaNacimiento_e LIKE '%"+buscar+"%'";
                break;
            case 4:
                sql="SELECT * FROM estudiantes WHERE cedula_e LIKE '%"+buscar+"%'";
                break;
            case 5:
                sql="SELECT * FROM estudiantes WHERE direccion LIKE '%"+buscar+"%'";
                break;     
                case 6:
                sql="SELECT * FROM estudiantes WHERE telefono LIKE '%"+buscar+"%'";
                break;
        } 
        
        String datos[]=new String[7];
        try {
            rs = con.createStatement().executeQuery(sql);
            while(rs.next()==true){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                modelo.addRow(datos);
            }
            jTabla.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(JDtablaEstudiantes.class.getName()).log(Level.SEVERE, null, ex);
        }                   
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        body = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        JTFbusqueda = new javax.swing.JTextField();
        JCBbuscar = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTabla = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(750, 430));
        jPanel1.setPreferredSize(new java.awt.Dimension(750, 430));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        body.setBackground(new java.awt.Color(255, 255, 255));
        body.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(body, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 153, 255));
        jSeparator2.setPreferredSize(new java.awt.Dimension(250, 10));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 470, 10));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Buscar:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 70, -1));

        JTFbusqueda.setBorder(null);
        JTFbusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                JTFbusquedaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTFbusquedaKeyTyped(evt);
            }
        });
        jPanel1.add(JTFbusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 470, 20));

        JCBbuscar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Codigo", "Nombres", "Apellidos", "Fecha Nacimiento", "Cedula", "Direccion", "Teléfono", " " }));
        JCBbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCBbuscarActionPerformed(evt);
            }
        });
        jPanel1.add(JCBbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 50, -1, -1));

        jTabla = new JTable(){
            public boolean isCellEditable(int row, int column)
            {
                for(int i =0;i<jTabla.getRowCount();i++){
                    if(row==i){
                        return false;
                    }
                }
                return true;
            }
        };
        jTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTabla);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 760, 320));

        jPanel2.setBackground(new java.awt.Color(21, 101, 192));

        Title.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Title.setForeground(new java.awt.Color(255, 255, 255));
        Title.setText("Estudiantes");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Title)
                .addContainerGap(623, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(Title)
                .addGap(0, 8, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 758, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablaMouseClicked
        if(evt.getClickCount()==2){
            int fila=jTabla.getSelectedRow();
            codigoestudiante= Integer.parseInt(jTabla.getValueAt(fila, 0).toString());
            Nombre=(String) jTabla.getValueAt(fila, 1);
            this.dispose();
        }
    }//GEN-LAST:event_jTablaMouseClicked

    private void JTFbusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFbusquedaKeyReleased
        buscar(this.JTFbusqueda.getText());
    }//GEN-LAST:event_JTFbusquedaKeyReleased

    private void JTFbusquedaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTFbusquedaKeyTyped
        switch(JCBbuscar.getSelectedIndex()){
            case 0,4,6:
                char variable=evt.getKeyChar();
        if(Character.isLetter(variable)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, " Ingrese números");
            JTFbusqueda.requestFocus();}
                break;
            case 3:
                 String fecha = "^(0?[1-9]|[12][0-9]|[3][01])(\\/)(0?[1-9]|1[012])(\\/)(\\d{4})";
        if( !Pattern.matches(fecha, this.JTFbusqueda.getText())){
            JOptionPane.showMessageDialog(null, " Fecha no valida. Recuerde formato fecha dd/mm/aaaa");
            this.JTFbusqueda.setText(null);
            this.JTFbusqueda.requestFocus();
        }
                break;
        }
    }//GEN-LAST:event_JTFbusquedaKeyTyped

    private void JCBbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCBbuscarActionPerformed
        this.JTFbusqueda.setEnabled(true);
        this.JTFbusqueda.requestFocus();
    }//GEN-LAST:event_JCBbuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDtablaEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDtablaEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDtablaEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDtablaEstudiantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDtablaEstudiantes dialog = new JDtablaEstudiantes();
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> JCBbuscar;
    private javax.swing.JTextField JTFbusqueda;
    private javax.swing.JLabel Title;
    private javax.swing.JPanel body;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTabla;
    // End of variables declaration//GEN-END:variables
}
