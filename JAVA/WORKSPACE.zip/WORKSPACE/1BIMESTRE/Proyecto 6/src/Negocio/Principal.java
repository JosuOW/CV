
package Negocio;

import Interfaz.EscritorioFondo;
import Interfaz.JFmenu;

/**
 *
 * @josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
        EscritorioFondo fondo= new EscritorioFondo();
         fondo.setVisible(true);
        JFmenu menu=new JFmenu();
        menu.setVisible(true);
    }
    
}
