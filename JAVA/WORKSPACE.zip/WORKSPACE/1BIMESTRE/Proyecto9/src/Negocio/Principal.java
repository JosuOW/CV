
package Negocio;

import Vista.EscritorioFondo;
import Vista.jFFEmpleado;

/**
 *
 * @josune.singaña
 */
public class Principal {
    public static void main(String[] args) {
      EscritorioFondo escritorio=new EscritorioFondo();
      escritorio.setVisible(true);
        jFFEmpleado jffempleado=new jFFEmpleado();
       jffempleado.setVisible(true);
    }
}
