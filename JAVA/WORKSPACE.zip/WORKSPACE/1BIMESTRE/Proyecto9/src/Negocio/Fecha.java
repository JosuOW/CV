
package Negocio;

import java.util.StringTokenizer;

/**
 *
 * @josune.singaña
 */
public class Fecha {
    private int dia, mes, anio;

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public Fecha(String fecha) {
        StringTokenizer token=new StringTokenizer(fecha,"/");
        this.dia=Integer.parseInt(token.nextToken());
        this.mes=Integer.parseInt(token.nextToken());
        this.anio=Integer.parseInt(token.nextToken());
    }

    @Override
    public String toString() {
        return  this.dia + " / " + this.mes + " / " + this.anio ;
    } 
}
