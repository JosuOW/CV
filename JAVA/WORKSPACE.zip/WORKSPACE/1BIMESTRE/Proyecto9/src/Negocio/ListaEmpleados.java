
package Negocio;

import java.util.ArrayList;

/**
 *
 * @josune.singaña
 */
public class ListaEmpleados {
   ArrayList <Empleado> listaEmpleados;
    public ListaEmpleados() {
        this.listaEmpleados=new ArrayList();
    }
   public void addEmpleadosLista(Empleado empleado){
       listaEmpleados.add(empleado);
   }

    @Override
    public String toString() {
        String salida="";
        for(Empleado aux:listaEmpleados)
        salida+=aux.toString();
            return salida;
                }
}
