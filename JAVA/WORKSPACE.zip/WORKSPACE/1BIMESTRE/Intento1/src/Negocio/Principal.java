package Negocio;

import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel Garcés 
 */
public class Principal {

   
    public static void main(String[] args) {
        int opcion;
        int contador=1;  
        String salida = "";
       Numeroimaginario num1= new Numeroimaginario();
       Numeroimaginario num2= new Numeroimaginario();
       Numeroimaginario sumaC;
       do{
         
       JOptionPane.showMessageDialog(null, "Numero "+contador);
       num1.setImaginaria();  
       contador++;
      JOptionPane.showMessageDialog(null, "Numero "+contador);
       num2.setImaginaria();
       
       opcion=JOptionPane.showConfirmDialog(null, "Desea continuar?", "Confirmacion ", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
       salida+=num1.toString()+"\n";
       salida+=num2.toString()+"\n";
       sumaC=num1.sumaimaginarios(num2);
       contador++;
       }while(opcion!=JOptionPane.NO_OPTION);
       salida+="El resultado de la suma es: "+"\n";
       salida+="  "+num1.getReal()+"; "+num1.getImaginaria()+"i"+"\n"+"+"+num2.getReal()+"; "+num2.getImaginaria()+"i"+"\n"+"--------------"+"\n";
       salida+=num1.sumaimaginarios(num2).resultadosuma()+"\n";
       salida+="El resultado de la resta es: \n";
       salida+="  "+num1.getReal()+"; "+num1.getImaginaria()+"i \n"+"-"+num2.getReal()+"; "+num2.getImaginaria()+"i\n"+"--------------"+"\n";
       salida+=num1.restaimaginarios(num2).resultadosuma()+"\n";
   
       JOptionPane.showMessageDialog(null, salida);
    }
    
}

