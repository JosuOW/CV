package Negocio;

import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author LabP4108
 */
public class Numeroimaginario {
    private double real,imaginaria;
   

    public Numeroimaginario() {
    }

    public Numeroimaginario(double real, double imaginaria) {
        this.real = real;
        this.imaginaria = imaginaria;
    }

    public double getReal() {
        return real;
    }

    public void setReal(double real) {
        this.real = real;
    }

    public double getImaginaria() {
        return imaginaria;
    }

    public void setImaginaria() {
        String linea;
        StringTokenizer token;
        double realAux,imaginariaAux;
        

        try{
           
            linea= JOptionPane.showInputDialog("Ingrese la parte real e imaginaria del numero separe con un espacio en blanco");
            token= new StringTokenizer(linea);
            
            realAux=Double.parseDouble(token.nextToken());
            imaginariaAux=Double.parseDouble(token.nextToken());
           this.real=((double)Math.round(realAux*100)/100);
           this.imaginaria=((double)Math.round(imaginariaAux*100)/100);
            
            
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Favor ingrese numeros");
            setImaginaria();
            
        }
     
        
    }
    public Numeroimaginario sumaimaginarios(Numeroimaginario num){
        Numeroimaginario imaginarioAux= new Numeroimaginario();
        imaginarioAux.real=this.real+num.real;
        imaginarioAux.imaginaria=this.imaginaria+num.imaginaria;
      return imaginarioAux;  
    }
    public Numeroimaginario restaimaginarios(Numeroimaginario num){
        Numeroimaginario imaginarioAux= new Numeroimaginario();
        imaginarioAux.real=this.real-num.real;
        imaginarioAux.imaginaria=this.imaginaria-num.imaginaria;
        return imaginarioAux;
    }

    @Override
    public String toString() {
        return "Numero imaginario{" + "real=" + real +  ", imaginario=" +imaginaria+"i" + '}'+"\n";
    }
    public String resultadosuma(){
        return "real="+ real+", imaginario="+imaginaria+"i";
    }
    
}
