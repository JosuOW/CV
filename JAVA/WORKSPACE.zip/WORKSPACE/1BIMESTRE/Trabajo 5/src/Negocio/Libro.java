
package Negocio;

/**
 *
 * @josune.singaña
 */
public class Libro {
  private Fecha fechaEdicion;
private Autor autor;
private String titulo;

    public Libro(String fechaEdición, Autor autor, String titulo) {
        this.fechaEdicion =new Fecha(fechaEdición) ;
        this.autor = autor;
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return "\nDATOS LIBROS:" + "\n Fecha Edicion= " + fechaEdicion + ",\nDATOS AUTOR:" + autor + "TITULO= " + titulo + "\n________________________";
    }
}
