
package Negocio;

import java.util.ArrayList;

/**
 *
 * josune.singaña
 */
public class ListaLibros {
  ArrayList <Libro> listaLibros;

    public ListaLibros() {
        this.listaLibros= new ArrayList();
        
    }
    public void addLibrosLista(Libro libro){
        listaLibros.add(libro);
    }

    @Override
    public String toString() {
       String salida="";
       for(Libro aux:listaLibros)
           salida+=aux.toString();     
        return salida;
    }
  
}
