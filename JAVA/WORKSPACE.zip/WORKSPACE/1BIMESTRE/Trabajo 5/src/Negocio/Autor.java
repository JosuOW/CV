
package Negocio;

/**
 *
 * josune.singaña
 */
public class Autor {
    private String nombres;
    private Fecha fechaNacimiento;

    public Autor(String nombres,String fechaNacimiento) {
        this.nombres = nombres;
        this.fechaNacimiento = new Fecha(fechaNacimiento);
    }

    @Override
    public String toString() {
        return "\n Autor= " + nombres + "\n Fecha Nacimiento= " + fechaNacimiento + '\n';
    }
}
