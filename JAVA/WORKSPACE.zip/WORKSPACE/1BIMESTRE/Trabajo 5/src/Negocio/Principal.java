
package Negocio;

import Vista.Fondo;
import Vista.jFFLibros;

/**
 *
 * @josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
        Fondo fondo=new Fondo();
        fondo.setVisible(true);
        jFFLibros jfflibros=new jFFLibros();
        jfflibros.setVisible(true);
    }
    
}
