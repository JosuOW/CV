package Negocio;


import Vista.EscritorioFondo;
import Vista.Login;

/**
 *
 * @josune.singaña
 */
public class Principal {
     public static void main(String[] args) {
         EscritorioFondo fondo= new EscritorioFondo();
         fondo.setVisible(true);
         Login login=new Login();
       login.setVisible(true);
    
    }
}
