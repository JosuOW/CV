package Negocio;

import javax.swing.JOptionPane;

/**
  * @author josune.singaña
 */
public class Numero {
    private int x;   // atributos
    // Constructores, pero si no se lo describe 
    //la clase asume un constructor por defecto
    // la función de un constructor es inicializar 
    //los atributos AL INSTANCIAR EL OBJETO
   // Se ejecuta solo 1 vez: ( AL instanciar el objeto )

    public Numero() {
     
    }
// Sobrecarga de constructores
    public Numero(int x) {
        this.x = x;
    }

    public void setNumero()
    {
        /// Ingreso dato
       // Scanner sc = new Scanner(System.in);
        try
                {
      //  System.out.println("Ingrese un número X=");
              // this.x= sc.nextInt(); 
           
                    this.x=Integer.parseInt(JOptionPane.showInputDialog(null,"Favor ingrese un número: "));
                }
        //catch(Exception e)
        catch(NumberFormatException e)
        {
            System.out.println("Favor ingrese números ");
        setNumero();
        } 
            }
    
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
    public boolean esPar(){
// if (this.x%2 ==0){
//     return true;
// }else{
//     return false;
// }
return this.x%2==0;//Metodo predicado
    }
    
    public boolean esPrimo()
    {
        int i=2;
        int div=0;
        while (i <=this.x)
        {
            if(this.x%i==0)
            {
             div+=1;   
            }
            i++;
        }
        return (div==2);
    }
    
    public boolean esPerfecto()
            {
            int per=1;
            for (int i=2;i<this.x;i++ )
            {
                if(this.x%i==0)
                {
                    per+=i;
                }
            }
           return (per==this.x);
            }
    
       public long sumaDigitos()
            {long suma=0;
             int aux=this.x;
            while(aux!=0)
            {
                suma+=aux%10;
                aux=aux/10;
            }
               return suma; 
            }
                
           public long suFactorial()
            {int fac=1;
            if(this.x!=0)
             {
               for (int i=1;i<=this.x;i++ )
                {
                  fac*=i;
                } 
             }
               return fac; 
            } 
    
 @Override
    public String toString() {
        return "Numero{" + "x=" + x + '}';
    }
    
    
}
