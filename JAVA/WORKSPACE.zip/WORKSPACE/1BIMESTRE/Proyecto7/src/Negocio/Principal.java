
package Negocio;

import Visual.JFManejoString;

/**
 *
 * @josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
        JFManejoString manejo= new JFManejoString();
        manejo.setVisible(true);
    } 
}
