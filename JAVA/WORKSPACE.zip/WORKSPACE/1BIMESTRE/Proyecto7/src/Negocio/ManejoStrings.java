
package Negocio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;
/**
 *
 * @josune.singaña
 */
public class ManejoStrings {
private String entrada;
ArrayList <String> lista;
   

    public ManejoStrings() {
    lista=new ArrayList<String>();
    }

    public void setString(String stringEntrada){
        this.entrada=stringEntrada;
    }
    public void setArrayList(){
         StringTokenizer st = new StringTokenizer(entrada,",");
         while(st.hasMoreElements()){
        agregarArrayList(st.nextToken());
    }
    }
    
    public void agregarArrayList(String dato){
        lista.add(dato);
    }

    public void convertirMayusculaPrimeraLetra(){
        ArrayList <String> listaAux=new ArrayList<String>();
        char[] caracteres;
        for(String aux:lista){
            caracteres=aux.toCharArray();
            caracteres[0]=Character.toUpperCase(caracteres[0]);
            listaAux.add(String.copyValueOf(caracteres));
        }
        lista=listaAux;
        return;
    }
   //desarrollado en clase
    public void cambiarMayuscula(){
       ArrayList <String> listaAux=new ArrayList();
       char[] caracteres;
       int i=0;
       for(String aux:lista){
           caracteres=aux.toCharArray();
           caracteres[0]=Character.toUpperCase(caracteres[0]);
           for(int x=0;x<caracteres.length;x++){
               if(caracteres[x]==' '){
                   caracteres[x+1]=Character.toUpperCase(caracteres[x+1]); 
               }
           }
            listaAux.add(String.copyValueOf(caracteres));
       }
       lista=listaAux;
        return;
    }

    public void ordenarArrays(){
       Collections.sort(this.lista); 
    }
    @Override
    public String toString() {
        String salida="";
        for(String aux:this.lista)
            salida+=aux+"\n";
        return salida; 
    }
}
