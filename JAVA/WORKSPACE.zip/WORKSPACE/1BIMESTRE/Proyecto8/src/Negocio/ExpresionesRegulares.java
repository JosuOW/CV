
package Negocio;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @josune.singaña
 */
public class ExpresionesRegulares {
    public void ejercicio1(){
        //1. Comprobar si el String cadena contiene exactamente el patrón(matches) "abc"
    String opcion;
            Pattern pat=Pattern.compile("abc");
          do{
              System.out.println("Ejercicio1: Ingrese una cadena");
              Scanner sc=new Scanner(System.in);
              String cadena=sc.nextLine();
              Matcher mat=pat.matcher(cadena);
              if(mat.matches()){
                  System.out.println("SI es exactamente la cadena abc");
              }else{
                   System.out.println("NO es exactamente la cadena abc");
              }
               System.out.println("continua? SI/NO");
               opcion=sc.nextLine();
          } while(opcion.equalsIgnoreCase("SI"));
    }
}
