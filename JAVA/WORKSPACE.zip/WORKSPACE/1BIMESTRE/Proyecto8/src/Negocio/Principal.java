
package Negocio;

import Vista.JFExpresionesRegulares;

/**
 *
 * @josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
     JFExpresionesRegulares jfexpresiones=new JFExpresionesRegulares();
     jfexpresiones.setVisible(true);
     ExpresionesRegulares expresionesregulares=new ExpresionesRegulares();
     expresionesregulares.ejercicio1();
    }
    
}
