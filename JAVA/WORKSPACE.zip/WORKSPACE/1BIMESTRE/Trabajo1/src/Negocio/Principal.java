
package Negocio;
import javax.swing.JOptionPane;

/**
 *
 * @author Josune.Singaña
 */
public class Principal {

    public static void main(String[] args) {
        int opcion;
        String salida="";
        Ecuacion ecuacion=new Ecuacion();
        do{
        ecuacion.setEcuacion();
        JOptionPane.showMessageDialog(null,ecuacion);
        salida+=(ecuacion+" Respuesta: "+ecuacion.operacionRaiz())+"\n";
        opcion=JOptionPane.showConfirmDialog(null, "Continua....", "Opciones", JOptionPane.YES_NO_OPTION);
        }while(opcion==JOptionPane.YES_OPTION);
       JOptionPane.showMessageDialog(null,salida, "Resultado ", JOptionPane.INFORMATION_MESSAGE);
    }
}
