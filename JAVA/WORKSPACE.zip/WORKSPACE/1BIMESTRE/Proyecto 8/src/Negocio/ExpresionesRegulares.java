
package Negocio;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @josune.singaña
 */
public class ExpresionesRegulares {
    private String patron;
    private String cadena;


   
 
    public void ejercicios(){  
         int num, opcion;
         
        num=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese una opción de patrón:"
                 + "\n1. Comprobar si el String cadena contiene exactamente el patrón (matches) “abc”"
                 + "\n2. Comprobar si el String cadena contiene “abc”"
                 + "\n3. Comprobar si el String cadena empieza por “abc”"
                + "\n4. Comprobar si el String cadena empieza por “abc” ó “Abc”"
                 + "\n5. Comprobar si el String cadena está formado por un mínimo de 5 letras mayúsculas o minúsculas y un máximo de 10."
                 + "\n6. Comprobar si el String cadena no empieza por un dígito"
                 + "\n7. Comprobar si el String cadena no acaba con un dígito"
                 + "\n8. Comprobar si el String cadena solo contienen los caracteres a ó b"
                + "\n9. Comprobar si el String cadena contiene un 1 y ese 1 no está seguido por un 2"
                 + "\n10. Comprobar correo"));
        if(num>10||num<1){
            JOptionPane.showMessageDialog(null, "Valor no valido", "Ingreso INCORRECTO", 0);
            ejercicios();
        }
        switch(num){
            case 1:
                this.patron="abc";
                case 2:
                this.patron=".*abc.*";
                case 3:
                this.patron="^abc.*";
                case 4:
                this.patron="^[aA]bc.*";
                case 5:
                this.patron="[a-zA-Z]{5,10}";
                case 6:
                this.patron="^[^\\d].*";
                case 7:
                this.patron=".*[^\\d]$";
                case 8:
                this.patron="(a|b)+";
                case 9:
                this.patron=".*1(?!2).*";
                case 10:
                this.patron="[\\w+]+(.[\\w+])*@epn+(.edu)*(.ec)$";
        }
        this.cadena = JOptionPane.showInputDialog(null,"Favor ingrese cadena a comprobar: ");
            Pattern pat=Pattern.compile(this.patron);
          do{
              Matcher mat=pat.matcher(cadena);
              if(num!=10){
               if(mat.matches()){
                  JOptionPane.showMessageDialog(null, "SI cumple patrón", "Resultado", 0);
              }else{
                  JOptionPane.showMessageDialog(null, "NO cumple patrón", "Resultado", 0);
              }   
              }else{
                 if(mat.matches()){
                  JOptionPane.showMessageDialog(null, "CORREO VALIDO", "Resultado", 0);
              }else{
                  JOptionPane.showMessageDialog(null, "CORREO NO VALIDO", "Resultado", 0);
              }    
              }
             opcion=JOptionPane.showConfirmDialog(null, "Continua....?", "Opciones", JOptionPane.YES_NO_OPTION);
          } while(opcion==JOptionPane.YES_OPTION);
    }
    
    
    
    
    
    
    
}
