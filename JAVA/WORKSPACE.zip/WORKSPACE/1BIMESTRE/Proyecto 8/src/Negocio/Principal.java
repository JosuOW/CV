
package Negocio;



/**
 *
 * @josune.singaña
 */
public class Principal {
    public static void main(String[] args) {
     ExpresionesRegulares expresionesregulares=new ExpresionesRegulares();
     expresionesregulares.ejercicios();
    }
    
}
