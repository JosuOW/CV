
package Negocio;

import javax.swing.JOptionPane;

/**
 *
 * @josune.singaña
 */
public class Principal3 {

    public static void main(String[] args) {
    int opcion;
    String salida="";
    String sum="";
   NumeroComplejo complejo1=new NumeroComplejo();
    NumeroComplejo complejo2=new NumeroComplejo();
    NumeroComplejo sumaC;
    do{
     // JOptionPane.showInputDialog("", sumaC, sum, opcion);
        complejo1.setImaginario();
         complejo2.setImaginario();
        salida+="                        Real   Imaginario \n";
        salida+="Complejo 1"+complejo1.toString()+"\n";
       salida+="+ \n";
        salida+="Complejo 2"+complejo2.toString()+"\n";
        salida+="______________________\n";
        sumaC=complejo1.sumarcomplejo(complejo2);
        sum=sumaC.toString();
        salida+="Suma:        "+sum+" \n";
        opcion=JOptionPane.showConfirmDialog(null, "Continua....", "¿Más datos?", JOptionPane.YES_NO_OPTION);
        }while(opcion==JOptionPane.YES_OPTION);
  //System.out.printf(“La suma es %d%n”, suma);
      JOptionPane.showMessageDialog(null, salida,"SUMA", JOptionPane.INFORMATION_MESSAGE);
       
       
    }
    
}
