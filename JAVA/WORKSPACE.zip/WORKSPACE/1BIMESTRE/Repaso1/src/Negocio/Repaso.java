
package Negocio;

/**
 *
 * @josune singaña
 */
public class Repaso {
    private String texto;

    public Repaso() {
    }

    public Repaso(String texto) {
        this.texto = texto;
    }

    @Override
    public String toString() {
        return "Repaso{" + "texto=" + texto + '}';
    }
    
}
