
package Negocio;

/**
 *
 * @josune singaña
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
Repaso repaso=new Repaso();
    }
    
}
