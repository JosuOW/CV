
package Negocio;
import Interfaces.JFVector;

/**
 *
 * @josune.singaña
 */

public class Principal {
    public static void main(String[] args) {
     /* String salida="";
      int n, pos;
        do{
           n=Integer.parseInt(JOptionPane.showInputDialog("Ingrese la dimension "));
          Arreglo vector1=new Arreglo(n);
          vector1.setVector();
           JOptionPane.showMessageDialog(null,vector1);
          vector1.sortAscending();
            JOptionPane.showMessageDialog(null,vector1);
          int datoBuscar=Integer.parseInt(JOptionPane.showInputDialog("Ingrese valor a buscar: "));
          pos=vector1.busquedaBinaria(datoBuscar);
          JOptionPane.showMessageDialog(null, "Elemento encontrado en la posicion [ "+pos+" ]");
          }
        }while(pos>-1);*/
      JFVector jfvector= new JFVector();
      jfvector.setVisible(true);
    } 
}
