
package Negocio;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @josune.singaña
 */
public class Arreglo {
    private int vector[];
    public Arreglo(int n){
        this.vector=new int[n];
    }
    
public void setVector(){
    Random rd=new Random();
    for (int i=0; i<this.vector.length;i++)
        this.vector[i]=1+rd.nextInt(9);
}

 public int[] getVector() {
        return vector;
    }

public void setVector(int[] vector) {
        this.vector = vector;
    }

public void sortAscending(){
    int aux=0;
    for(int i=0; i<this.vector.length;i++){
        for(int j=i+1; j<this.vector.length;j++){
            if(this.vector[i]>this.vector[j]){
                aux=this.vector[i];
                this.vector[i]=this.vector[j];
                this.vector[j]=aux;
            }
        }
    }
   
}

 public int sumarElementos(){
    int suma=0;
    for(int i=0; i<this.vector.length;i++){
      suma+=this.vector[i];
    }
    return suma;
}
 public int sumarPrimos(){
     int suma=0;
    for(int i=0; i<this.vector.length;i++){
      if(esPrimo(this.vector[i]))
        suma+=this.vector[i];
    }
    return suma;
}
 
public boolean esPrimo(int x)
    {
       int cont=0;
       for(int i=1;i<=x;i++){
           if(x%i==0){
               cont++;
           }
       }
        return (cont==2);
    }
 
 public int contarPerfectos(){
    int cont=0;
    for(int i=0; i<this.vector.length;i++){
      if(esPerfecto(this.vector[i]))
        cont++;
    }
    return cont;
}
 
public boolean esPerfecto(int x) {
    int per=1;
    for (int i=2;i<x;i++){
     if(x%i==0){
          per+=i;
       }
    }
 return (per==x);
  }
 
 
public void sortAscendingArrays(){
    Arrays.sort(vector);
}

public void sortDescending(){
    int aux=0;
    for(int i=0; i<this.vector.length;i++){
        for(int j=i+1; j<this.vector.length;j++){
            if(this.vector[i]<this.vector[j]){
                aux=this.vector[i];
                this.vector[i]=this.vector[j];
                this.vector[j]=aux;
            }
        }
    }
}

public int busquedaBinaria(int elementoBuscar){
    int medio=0, limSuper=this.vector.length, limInfer=0;
    while(limInfer<=limSuper){
        medio=(limInfer+limSuper-1)/2;
        if(elementoBuscar==vector[medio]){
            return medio;
        } else{
            if(elementoBuscar>this.vector[medio]){
                limInfer=medio;
            }else{
                limSuper=medio;
            }
        }
    }
   return medio-1; 
}
 
public int busquedaBinarioArray(int elemento){
    sortAscendingArrays();
    return Arrays.binarySearch(this.vector, elemento);
}

public int buscarMayor(){
    int mayor=this.vector[0];
    for(int i=0; i<this.vector.length;i++){
        if(this.vector[i]>= mayor){
            mayor=this.vector[i];
        }
    }
    return mayor;
}

public int buscarMenor(){
    int menor=this.vector[0];
    for(int i=0; i<this.vector.length;i++){
        if(this.vector[i]<= menor){
            menor=this.vector[i];
        }
    }
    return menor;
}

    @Override
    public String toString() {
        return Arrays.toString(this.vector);
    }
}
