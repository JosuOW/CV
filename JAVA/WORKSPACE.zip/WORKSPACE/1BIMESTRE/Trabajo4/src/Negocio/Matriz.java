
package Negocio;

import java.util.Random;

/**
 *
 * @josune.singaña
 */
public class Matriz {
    private int [][]matriz;

    public Matriz() {
    }

    public int[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(int[][] matriz) {
        this.matriz = matriz;
    }

 

    public Matriz(int f, int c) {
         matriz= new int [f][c];
    this.setMatriz();
    }

    public void setMatriz(){
        Random rd= new Random();
        for(int i=0; i<this.matriz.length;i++){
        for(int j=0; j<this.matriz[i].length;j++){
        this.matriz[i][j]=rd.nextInt(9)+1;
        }
     }
    }
      public void productoEscalar(int num){
       int aux=0;
        for(int i=0; i<this.matriz.length;i++){
        for(int j=0; j<this.matriz[i].length;j++){
        aux=this.matriz[i][j];
            this.matriz[i][j]=num*aux;
        }
     }
    }
public Matriz sumaMatrices(Matriz m2){
    Matriz matrizSuma= new Matriz(this.matriz.length,this.matriz[0].length);
    if(this.matriz.length!=m2.matriz.length &&
            this.matriz[0].length!=m2.matriz[0].length){
        matrizSuma=null;
    }else
    {
        for(int i=0; i<this.matriz.length;i++){
             for(int j=0; j<this.matriz[i].length;j++){
                 matrizSuma.matriz[i][j]=this.matriz[i][j]+m2.matriz[i][j];
             }
        }
    }
    return matrizSuma;
}

public Matriz productoMatrices(Matriz m2){
    Matriz matrizProducto= new Matriz(this.matriz.length,m2.matriz[0].length);
    if(this.matriz[0].length!= m2.matriz.length)
        matrizProducto=null;
    else{
    for(int i=0; i<this.matriz.length;i++){
        for(int j=0; j< m2.matriz[i].length;j++){
            for(int k=0; k< this.matriz[0].length;k++){
                matrizProducto.matriz[i][j]+=this.matriz[i][k]*m2.matriz[k][j];
            }
        }
    }
}
    return matrizProducto;
}

    @Override
    public String toString() {
       String salida="";
        for(int i=0; i<this.matriz.length;i++){
            salida+="      | ";
            for(int j=0; j<this.matriz[i].length;j++){
            salida+=this.matriz[i][j]+" ";
        }
            salida+="|\n";
        }
       return salida;
    }
}
