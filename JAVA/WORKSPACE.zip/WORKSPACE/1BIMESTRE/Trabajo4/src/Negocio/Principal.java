
package Negocio;

import Interfaz.JFOmatrices;

/**
 *
 * @josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
     JFOmatrices jfomatrices=new JFOmatrices();
     jfomatrices.setVisible(true);
    }
    
}
