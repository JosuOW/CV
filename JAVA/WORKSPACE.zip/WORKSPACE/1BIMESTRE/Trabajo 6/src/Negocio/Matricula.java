
package Negocio;

/**
 *
 * @josune.singaña
 */
public class Matricula {
    private Persona propietario;
    private Vehiculo vehiculo;
    private Fecha fechaMatricula;
    private double  valorSRI;
    private static double totalRecaudado=0;

    public Matricula(long cedula, String nombres, String numchasis,String color, String fecha, String valorSRI) {
        this.propietario=new Persona(cedula,nombres);
        this.vehiculo= new Vehiculo(numchasis,color);
        this.fechaMatricula=new Fecha(fecha);
        this.valorSRI=Double.parseDouble(valorSRI);
        totalRecaudado+=this.valorSRI;
    }
/*
    public Matricula(Persona propietario, Vehiculo vehiculo, Fecha fechaMatricula, double valorSRI) {
        this.propietario = propietario;
        this.vehiculo = vehiculo;
        this.fechaMatricula = fechaMatricula;
        this.valorSRI = valorSRI;
    }*/
public static double acumulaTotalSRI(){
    return totalRecaudado;
}
    @Override
    public String toString() {
        return "MATRÍCULA \nPROPIETARIO: " + propietario + "\nVehiculo= " + vehiculo + "\nFecha Matricula= " + fechaMatricula + "\nValor SRI= " + valorSRI;
    }  
}
