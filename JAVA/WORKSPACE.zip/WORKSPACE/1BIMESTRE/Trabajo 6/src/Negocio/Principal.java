
package Negocio;

import Vista.Fondo;
import Vista.jFMatriculas;

/**
 *
 * @josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
        Fondo fondo=new Fondo();
        fondo.setVisible(true);
        jFMatriculas jffmatricula=new jFMatriculas();
        jffmatricula.setVisible(true);
    }  
}
