
package Negocio;

import java.util.ArrayList;

/**
 *
 * @josune.singaña
 */
public class ListaMatriculas {
    private ArrayList <Matricula> ListaMatriculas;

    public ListaMatriculas() {
        this.ListaMatriculas = new ArrayList();
    }
    public void addMatricula(Matricula matricula){
        this.ListaMatriculas.add(matricula);
    }

    @Override
    public String toString() {
       String salida="";
       for(Matricula aux:ListaMatriculas)
           salida+=aux.toString();
        return salida;
    }  
}
