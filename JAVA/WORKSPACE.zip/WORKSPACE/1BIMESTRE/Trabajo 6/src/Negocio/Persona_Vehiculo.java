
package Negocio;

import java.util.ArrayList;

/**
 *
 * @josune.singaña
 */
public class Persona_Vehiculo {
    private ArrayList <Vehiculo> PersonaVehiculos;

    public Persona_Vehiculo() {
        this.PersonaVehiculos = new ArrayList();
    }

    public Persona_Vehiculo(ArrayList<Vehiculo> PersonaVehiculos) {
        this.PersonaVehiculos = PersonaVehiculos;
    }

   
    public void addVehiculo(Vehiculo vehiculo){
        this.PersonaVehiculos.add(vehiculo);
    }

    @Override
    public String toString() {
       String salida="";
       int i=1;
       for(Vehiculo aux:PersonaVehiculos)
           salida+=i++ + aux.toString();
        return salida;
    }
    
}
