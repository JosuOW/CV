
package Negocio;

import Visual.jFLibro;

/**
 *
 * @author josune.singaña
 */
public class Principal {
    public static void main(String[] args) {
   jFLibro    jflibro=new jFLibro();
   jflibro.setVisible(true);
    }
}
