
package Negocio;

import java.util.Comparator;

/**
 *
 * @author josune.singaña
 */
public class CompararPrecios implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
      Libro libro1=(Libro)o1;
      Libro libro2=(Libro)o2;   
   
       if( libro1.getPrecio()<libro2.getPrecio())
    return -1; 
       else
           if( libro1.getPrecio()==libro2.getPrecio())
         return 0; 
       else
         return 1;
    }
}
