
package Negocio;

/**
 *
 * @author Josune.Singaña y Boris.Garcés
 */
public abstract class Persona {
    protected double cedula;
    protected String nombre;

    public Persona(double cedula, String nombre) {
        this.cedula = cedula;
        this.nombre = nombre;
    }

    public double getCedula() {
        return cedula;
    }

    public void setCedula(double cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "\n Nombre:" + nombre +"\nCedula: " + cedula ;
    }
    
}
