
package Negocio;

import java.util.ArrayList;

/**
 *
 * @author Josune.Singaña y Boris.Garcés
 */
public class ListaPelicula {
    private ArrayList <PeliculaActor> listaPelicula;

    public ListaPelicula() {
        this.listaPelicula = new ArrayList<PeliculaActor>();
    }
    public void addPeliculaActor(PeliculaActor peliculaActor){
        listaPelicula.add(peliculaActor);
    }

    @Override
    public String toString() {
       String salida="";
       for(PeliculaActor aux:listaPelicula)    
           salida+=aux.toString()+"\n+--------------+\n";
       return salida;
           } 
}
