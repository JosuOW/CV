
package Negocio;

/**
 *
 * @author Josune.Singaña y Boris.Garcés
 */
public class Pelicula extends Multimedia {
    protected double duracion;
    protected String genero;
    protected double precio;

    public Pelicula(double duracion, String genero, double precio, String tipo) {
        super(tipo);
        this.duracion = duracion;
        this.genero = genero;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Pelicula:"+super.toString()+ "\nDuración: " + duracion + "\nGénero: " + genero + "\nPrecio: " + precio;
    }
    
}
