
package Negocio;

/**
 *
 * @author Josune.Singaña y Boris.Garcés
 */
public abstract class Multimedia {
    protected String tipo;

    public Multimedia(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "\nTipo: " + tipo;
    }
    
}
