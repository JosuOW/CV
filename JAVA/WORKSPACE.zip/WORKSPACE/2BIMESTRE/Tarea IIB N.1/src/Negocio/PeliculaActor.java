
package Negocio;

import java.util.ArrayList;

/**
 *
 * @author Josune.Singaña y Boris.Garcés
 */
public class PeliculaActor {
    protected Pelicula pelicula;
    protected ArrayList <Actor> listaActor;
public PeliculaActor(Pelicula pelicula) {
        this.pelicula = pelicula;
         this.listaActor= new ArrayList<Actor>();
    }
    
    public void addActor(Actor actor){
        this.listaActor.add(actor);
    }

    @Override
    public String toString() {
       String salida="";
       salida+=pelicula;
       for(Actor aux:listaActor)    
           salida+=aux.toString()+"\n__________________\n";
       return salida;
           } 

    
}
