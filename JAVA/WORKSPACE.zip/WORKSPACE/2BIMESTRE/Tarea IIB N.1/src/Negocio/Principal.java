
package Negocio;

import Visual.jFCine;

/**
 *
 * @author Josune.Singaña y Boris.Garcés
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    jFCine jfcine=new jFCine(); 
    jfcine.setVisible(true);
    }
    
}
