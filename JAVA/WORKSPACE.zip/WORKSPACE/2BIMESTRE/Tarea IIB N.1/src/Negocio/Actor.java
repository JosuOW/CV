
package Negocio;

/**
 *
 * @author Josune.Singaña y Boris.Garcés
 */
public class Actor extends Persona {
    protected double anioDebut;
    protected String interpretacion;
    public Actor(double anioDebut, double cedula, String nombre,String interpretacion) {
        super(cedula, nombre);
        this.anioDebut = anioDebut;
        this.interpretacion=interpretacion;
    }

    @Override
    public String toString() {
        return "\nActor"+super.toString()+"\nAño Debut: " + anioDebut+"\nPapel Interpreta: " + interpretacion;
    }
    
}
