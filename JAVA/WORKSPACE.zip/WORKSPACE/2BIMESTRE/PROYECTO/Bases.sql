#Eliminamos la base de datos si esta creada
DROP DATABASE IF EXISTS base_estudiantes;

#Creamos la base de datos a utilizar
CREATE DATABASE IF NOT EXISTS base_estudiantes;

#Indicamos que base de datos vamos a utilizar de ahora en adelante
USE base_estudiantes;

#Creamos la tabla estudiantes
CREATE TABLE IF NOT EXISTS estudiantes(
 codigo_e INT NOT NULL,
 nombre_e VARCHAR(45) NOT NULL,
 apellidos_e VARCHAR(45) NOT NULL,
 edad INT NOT NULL,
 direccion VARCHAR(65) NOT NULL,
 telefono VARCHAR(10) NOT NULL,
 PRIMARY KEY(codigo_e)
 )ENGINE = InnoDB;
 
 #Creamos tabla profesores
 CREATE TABLE IF NOT EXISTS profesores(
 codigo_p INT NOT NULL,
 nombre_p VARCHAR(45) NOT NULL,
 apellidos_p VARCHAR(45) NOT NULL,
 PRIMARY KEY(codigo_p)
 )ENGINE = InnoDB;
 
 #Creamos tabla materias
 CREATE TABLE IF NOT EXISTS materias(
 codigo_m INT NOT NULL,
 codigo_p INT NOT NULL,
 nombre VARCHAR(45) NOT NULL,
 num_horas INT NOT NULL,
 PRIMARY KEY(codigo_m),
 FOREIGN KEY(codigo_p)
   REFERENCES profesores(codigo_p)
 )ENGINE = InnoDB;
 
 #Creamos la tabla estudiantes_materias 
CREATE TABLE IF NOT EXISTS estudiantes_materias( 
codigo_m INT NOT NULL, 
codigo_e INT NOT NULL, 
PRIMARY KEY(codigo_m, codigo_e), 
FOREIGN KEY (codigo_m) 
REFERENCES materias(codigo_m), 
FOREIGN KEY (codigo_e) 
REFERENCES estudiantes(codigo_e) 
)ENGINE = InnoDB; 

  #Creamos tabla facultades
 CREATE TABLE IF NOT EXISTS facultades(
 codigo_f INT NOT NULL,
 codigo_p INT NOT NULL,
 nombre_f VARCHAR(45) NOT NULL,
Num_Edificio INT NOT NULL,
 PRIMARY KEY(codigo_f),
 FOREIGN KEY(codigo_p)
   REFERENCES profesores(codigo_p)
 )ENGINE = InnoDB;

#Insertamos los registros de estudiantes 
INSERT INTO estudiantes VALUES(202020472, "Juan Alberto", "Castillo Salcedo", 19, "Mitad del mundo", "0986543267"); 
INSERT INTO estudiantes VALUES(202098753, "Carla Maria", "Velastegui Lopez", 20, "Inca", "0995846840"); 


#Insertamos los registros de los profesores 
INSERT INTO profesores VALUES(201568483, "Agustin Fernando", "Perez Picho"); 
INSERT INTO profesores VALUES(201598763, "Carla Isabel", "Fernandez Pozo"); 

#Insertamos los registros de materias 
INSERT INTO materias VALUES(2021001,201568483, "Matemáticas",6); 
INSERT INTO materias VALUES(2021002, 201598763, "Física", 7); 

#Insertamos los registros de estudiantes_materias 
INSERT INTO estudiantes_materias VALUES(202020473, 2021001); 
INSERT INTO estudiantes_materias VALUES(202020473, 2021002); 
INSERT INTO estudiantes_materias VALUES(202098754, 2021001); 
INSERT INTO estudiantes_materias VALUES(202098754, 2021002); 

#Insertamos más registros de estudiantes 
INSERT INTO estudiantes VALUES(202098420, "Fernando Mateo", "Perez Enriquez", 19, "Carcelen", "0986543267"); 
INSERT INTO estudiantes VALUES(201846987, "Cristian José", "Gozales Lasso", 22, "Carapungo", "0900254984");  
INSERT INTO estudiantes VALUES(201907841, "Fernanda Soledad", "Benalcazar López", 18, "Centro", "0932001478");  
INSERT INTO estudiantes VALUES(2021165974, "Sandra Maria", "Ramírez Paucar", 17, "Floresta", "0913570594"); 

#Insertamos más registros de los profesores 
INSERT INTO profesores VALUES(201845910, "María carmen", "Padilla Pozo"); 
INSERT INTO profesores VALUES(202098461, "Ana Gabriela", "Mendez Puga"); 

#Insertamos más los registros de materias 
INSERT INTO materias VALUES(2021003,201845910, "Química",6); 
INSERT INTO materias VALUES(2021004, 202098461, "Ofimática", 4); 

#Insertamos más registros de estudiantes_materias 
INSERT INTO estudiantes_materias VALUES(2021001, 201846987); 
INSERT INTO estudiantes_materias VALUES(2021001, 202165974); 
INSERT INTO estudiantes_materias VALUES(2021001, 202098420); 
INSERT INTO estudiantes_materias VALUES(2021002, 201907841); 
INSERT INTO estudiantes_materias VALUES(2021002, 202165974); 
INSERT INTO estudiantes_materias VALUES(2021003, 202098754); 
INSERT INTO estudiantes_materias VALUES(2021003, 202098420); 
INSERT INTO estudiantes_materias VALUES(2021003, 202165974); 
INSERT INTO estudiantes_materias VALUES(2021004, 202020473); 
INSERT INTO estudiantes_materias VALUES(2021004, 202098420); 
INSERT INTO estudiantes_materias VALUES(2021004, 201846987);

 #Todos los estudiantes 
 SELECT * FROM estudiantes;
 