
package Negocio;

import Visual.JFFiguras;

/**
 *
 * @author josune.singaña
 */
public class Principal {
    public static void main(String[] args) {
        JFFiguras jtffiguras= new JFFiguras();
        jtffiguras.setVisible(true);
    }
    
}
