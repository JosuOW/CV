package Negocio;
import java.awt.Color;
import java.awt.Graphics;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
/**
 *
 * @author josune.singaña
 */
public class Cilindro extends Circulo {
    private double altura;

    public Cilindro(double altura, double radio, double x, double y) {
        super(radio, x, y);
        this.altura = altura;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    @Override
    public void dibujar(Graphics cilindro){
    cilindro.setColor(Color.black);
    cilindro.drawOval((int)super.getX(), (int)super.getY(),(int)super.getRadio()*2,(int)super.getRadio()*2);
    cilindro.drawRect((int)super.getX(),(int)super.getRadio(),(int)super.getRadio()*2, (int)this.altura);
    cilindro.drawOval((int)super.getX(),(int)this.altura, (int)super.getRadio()*2, (int)super.getRadio()*2);
    }

    @Override
    public double getArea() {
      DecimalFormatSymbols separadorPersonalizado=new DecimalFormatSymbols();
      separadorPersonalizado.setDecimalSeparator('.');
      DecimalFormat formato=new DecimalFormat("#.##", separadorPersonalizado);
      return Double.parseDouble(formato.format(super.getPerimetro()*(getRadio()+this.altura))) ;
    }

    @Override
    public double getPerimetro() {
      DecimalFormatSymbols separadorPersonalizado=new DecimalFormatSymbols();
      separadorPersonalizado.setDecimalSeparator('.');
      DecimalFormat formato=new DecimalFormat("#.##", separadorPersonalizado);
      return Double.parseDouble(formato.format(2*super.getArea()*this.altura+4*super.getArea()));
    }

    @Override
    public double getVolumen() {
      DecimalFormatSymbols separadorPersonalizado=new DecimalFormatSymbols();
      separadorPersonalizado.setDecimalSeparator('.');
      DecimalFormat formato=new DecimalFormat("#.##", separadorPersonalizado);
      return Double.parseDouble(formato.format(super.getArea()*this.altura));
    }

    @Override
    public String toString() {
        return "\nCilindro\nRadio: " + getRadio()+"\nAltura: " + getAltura()+"\nEl area es: "+getArea()+"\nEl perimetro es: "+getPerimetro()+"\nEl volumen es: "+getVolumen();
    }
    
}
