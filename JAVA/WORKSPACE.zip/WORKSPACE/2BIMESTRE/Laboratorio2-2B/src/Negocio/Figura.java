package Negocio;
/**
 *
 * @author josune.singaña
 */
public abstract class Figura {
    public abstract void dibujar();
    public abstract double getArea();
    public abstract double getPerimetro();
    public abstract double getVolumen();
}
