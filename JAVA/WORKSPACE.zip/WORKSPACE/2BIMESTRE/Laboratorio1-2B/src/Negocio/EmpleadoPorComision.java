
package Negocio;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import javax.swing.JOptionPane;

/**
 *
 * @josune.singaña
 */
public class EmpleadoPorComision extends Empleado {
    private double tarifaComision, ventasBrutas;

    public EmpleadoPorComision(double tarifaComision, double ventasBrutas, String fechaIngreso, String nombres, String fecha) {
        super(fechaIngreso, nombres, fecha);
        this.tarifaComision = tarifaComision;
        this.ventasBrutas = ventasBrutas;
    }

    @Override
    public double getSalarioTotal() {
     DecimalFormatSymbols separadorPersonalizado=new DecimalFormatSymbols();
      separadorPersonalizado.setDecimalSeparator('.');
       DecimalFormat formato=new DecimalFormat("#.##", separadorPersonalizado);
        return Double.parseDouble(formato.format(this.tarifaComision*this.ventasBrutas)) ;    
    }

    @Override
    public String toString() {
        return "\nEmpleado Por Comisión:"+super.toString()+ " \nTarifa Comisión:" + tarifaComision + "\nVentas Brutas: " + ventasBrutas + "\nSalario Total:" + getSalarioTotal();
    }
    
}
