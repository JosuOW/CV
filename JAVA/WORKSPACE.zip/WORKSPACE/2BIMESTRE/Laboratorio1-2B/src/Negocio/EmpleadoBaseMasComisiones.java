
package Negocio;

/**
 *
 * @josune.singaña
 */
public class EmpleadoBaseMasComisiones extends EmpleadoPorComision {
    private double salarioBase;

    public EmpleadoBaseMasComisiones(double salarioBase, double tarifaComision, double ventasBrutas, String fechaIngreso, String nombres, String fecha) {
        super(tarifaComision, ventasBrutas, fechaIngreso, nombres, fecha);
        this.salarioBase=salarioBase;
    }

    @Override
    public double getSalarioTotal() {
        return super.getSalarioTotal()+this.salarioBase;
    }

    @Override
    public String toString() {
        return "\nEmpleado Base Mas Comisiones: " + super.toString()+"\nSalario Base: " + salarioBase + "\nSalario Total:" + getSalarioTotal();
    }
    
}
