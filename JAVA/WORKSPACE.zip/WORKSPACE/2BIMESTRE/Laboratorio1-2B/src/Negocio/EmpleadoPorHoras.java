
package Negocio;

/**
 *
 * @josune.singaña
 */
public class EmpleadoPorHoras extends Empleado {
    private int horas;
    private double costoHoras;

    public EmpleadoPorHoras(int horas, double costoHoras, String fechaIngreso, String nombres, String fecha) {
        super(fechaIngreso, nombres, fecha);
        this.horas = horas;
        this.costoHoras = costoHoras;
    }
    @Override
    public double getSalarioTotal() {
      if(this.horas<=40)
          return this.horas*this.costoHoras;
      else 
          return(this.horas*1.50)*this.costoHoras;
    }
    @Override
    public String toString() {
        return "Empleado Por Horas:"+super.toString()+ "\nHoras:" + horas + "\nCosto Horas:" + costoHoras+ "\nSalario Total:" + getSalarioTotal();
    }
}
