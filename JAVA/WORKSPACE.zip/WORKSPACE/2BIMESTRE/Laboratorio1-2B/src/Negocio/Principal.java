
package Negocio;

import Visual.jFEmpleado;

/**
 *
 * @josune.singaña
 */
public class Principal {

    public static void main(String[] args) {
       jFEmpleado jfempleado=new jFEmpleado();
       jfempleado.setVisible(true);
    }
}
