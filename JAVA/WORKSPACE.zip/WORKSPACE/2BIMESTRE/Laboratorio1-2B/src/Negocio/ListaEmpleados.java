
package Negocio;

import java.util.ArrayList;

/**
 *
 * @author josuneSingaña
 */
public class ListaEmpleados {
    private ArrayList <Empleado> listaEmpleados;

    public ListaEmpleados() {
    listaEmpleados= new ArrayList<Empleado>();
    }
    public void addEmpleado(Empleado empleado){
        listaEmpleados.add(empleado);
    }

    @Override
    public String toString() {
       String salida="";
       for(Empleado aux:listaEmpleados)    
           salida+=aux.toString()+"\n__________________\n";
       return salida;
           }
}

