
package Negocio;

/**
 *
 * @josune.singaña
 */
public class EmpleadoAsalariado extends Empleado {
private double salarioSemanal;

    public EmpleadoAsalariado(double salarioSemanal, String fechaIngreso, String nombres, String fecha) {
        super(fechaIngreso, nombres, fecha);
        this.salarioSemanal = salarioSemanal;
    }

    @Override
    public double getSalarioTotal() {
    return salarioSemanal;   
    }

    @Override
    public String toString() {
        return "Empleado Asalariado: " +super.toString()+ "\nSalario Semanal: " + salarioSemanal;
    }

  

   

  
    
}
