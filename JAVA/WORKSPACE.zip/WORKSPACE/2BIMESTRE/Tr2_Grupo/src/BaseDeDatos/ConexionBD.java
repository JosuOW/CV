
package BaseDeDatos;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;

/**
 *
 * @author grupo5
 */
public class ConexionBD {
   
    Connection cn;
    String url;
    public ConexionBD() {
   this.url="jdbc:mysql://localhost:3306/base_estudiantes";     
    }
 
    public Connection conexion(String usuario,String password) {
        try{
            Class.forName("com.mysql.jdbc.driver");
            cn= DriverManager.getConnection(url,usuario,password);
        System.out.println("Se hizo la conexión de forma correcta");
    }catch(Exception e){
        System.out.println(e.getMessage());
    }return cn;
    }
   
Statement createStatement(){
    throw new UnsupportedOperationException("No soportado");
    
}
    
     
}
