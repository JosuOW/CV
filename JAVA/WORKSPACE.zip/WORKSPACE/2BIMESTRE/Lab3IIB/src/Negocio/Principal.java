
package Negocio;

import Visual.jFProvincia;

/**
 *
 * @author josune.singaña
 */
public class Principal {
    public static void main(String[] args) {
        jFProvincia jfprovincia=new jFProvincia();
        jfprovincia.setVisible(true);
    }
    
}
