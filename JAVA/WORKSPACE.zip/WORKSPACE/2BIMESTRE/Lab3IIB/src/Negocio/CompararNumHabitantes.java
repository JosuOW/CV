
package Negocio;

import java.util.Comparator;

/**
 *
 * @author josune.singaña
 */
public class CompararNumHabitantes implements Comparator {

    @Override
    public int compare(Object o1, Object o2) {
       Provincia provincia1=(Provincia)o1;
        Provincia provincia2=(Provincia)o2;
       if( provincia1.getNumHabitantes()<provincia2.getNumHabitantes())
    return -1; 
       else
           if( provincia1.getNumHabitantes()==provincia2.getNumHabitantes())
         return 0; 
       else
         return 1;
    }
    
}
