
package Negocio;

import java.util.Comparator;
/**
 *
 * @author josune.singaña
 */
public class CompararNombresProv implements Comparator {

    @Override
    public int compare(Object o1, Object o2) {
        Provincia provincia1=(Provincia)o1;
        Provincia provincia2=(Provincia)o2;
       if( provincia1.getNombre().compareTo(provincia2.getNombre())>0)
    return 1; 
       else
           if( provincia1.getNombre().compareTo(provincia2.getNombre())<0)
         return -1; 
       else
         return 0;
    }
    
}
