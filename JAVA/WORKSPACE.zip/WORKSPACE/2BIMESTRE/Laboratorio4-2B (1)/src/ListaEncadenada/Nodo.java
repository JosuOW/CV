
package ListaEncadenada;

import Negocio.Empleado;

/**
 *
 * @author LabP41014
 */
public class Nodo {
    private Empleado empleado;
    private Nodo enlace;

    public Nodo(Empleado empleado) {
        this.empleado = empleado;
        this.enlace=null;
    }

    public Nodo(Empleado empleado, Nodo enlace) {
        this.empleado = empleado;
        this.enlace = enlace;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Nodo getEnlace() {
        return enlace;
    }

    public void setEnlace(Nodo enlace) {
        this.enlace = enlace;
    }
   
    
}
