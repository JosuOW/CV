
package ListaEncadenada;

import Negocio.Empleado;

/**
 * @author josune.singaña
 */
public class ListaEncadenada {
    Nodo inicio;

    public ListaEncadenada() {
        this.inicio=null; //lista vacia
    }
    public boolean isEmpty(){
        return inicio==null;
    }
    public void addStart(Empleado empleado){
        if(isEmpty())
            inicio=new Nodo(empleado);
        else
            inicio=new Nodo(empleado,inicio);        
    }
  public boolean eliminarNodo(Empleado empleado){
       // String salida="";
        boolean bandera=false;
      Nodo p=inicio, q=inicio;
      if(isEmpty())
           bandera=false; //salida+= "La lista esta vacia";
      else{
        while(p!=null){
          if(q.getEmpleado().getNombres().equals(empleado.getNombres())){
             if(p==inicio){//borrar el primer nodo
                 this.inicio=p.getEnlace();
             }else{ //borrado intermedio o final
                 q.setEnlace(p.getEnlace());
                
             }
             bandera=true;
              break;
              
          }else{
             // salida+="El elemento a eliminar es"+p.getEmpleado().toString();
            
          }
            p=p.getEnlace();
            q=q.getEnlace();
        }
        inicio=q;
       // salida+="no encontrado";
      }
      return bandera;
  }    
      
        
    @Override
    public String toString() {
        String salida="";
        Nodo p=inicio;
        while(p!=null){
            salida+=p.getEmpleado()+"\n__________________\n";
            p=p.getEnlace();
        }
        return salida;
    }
    
}
