
package Negocio;

/**
 *
 * @josune.Singaña
 */
public abstract class Persona {
    private String nombres;
    private Fecha fechaNacimiento;

    public Persona(String nombres, String fecha) {
    this.nombres=nombres;
    this.fechaNacimiento=new Fecha(fecha);
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public Fecha getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Fecha fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    @Override
    public String toString() {
        return "\nNombres: " + nombres + "\nFecha Nacimiento: " + fechaNacimiento;
    } 
}
