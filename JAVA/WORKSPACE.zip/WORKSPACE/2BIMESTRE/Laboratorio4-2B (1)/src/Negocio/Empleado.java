
package Negocio;

/**
 *
 * @Josune.Singaña
 */
public abstract class Empleado extends Persona {
private Fecha fechaIngreso;
    public Empleado(String fechaIngreso, String nombres, String fecha) {
        super(nombres, fecha);
        this.fechaIngreso =new  Fecha(fechaIngreso);
    }


    public abstract double getSalarioTotal();
    
    @Override
    public String toString() {
        return super.toString()+"\nFecha Ingreso: " + fechaIngreso;
    }
}
