
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Arbusto extends Vegetal implements Actor {
    
}
