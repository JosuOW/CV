
package Negocio;

/**
 *
 * @author josune.singaña
 */
public abstract class Persona implements Actor {
    
}
