
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Arbol extends Vegetal implements Actor {
    
}
