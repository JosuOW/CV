package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Bicicleta extends Vehiculo {
    
}
