
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Estudiante extends Persona {
    
}
