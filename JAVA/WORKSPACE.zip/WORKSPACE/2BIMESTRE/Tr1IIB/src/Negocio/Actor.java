package Negocio;
/**
 *
 * @author josune.singaña
 */
public interface Actor {
    
}
