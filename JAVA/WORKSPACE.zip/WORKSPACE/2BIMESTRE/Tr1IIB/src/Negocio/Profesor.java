
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Profesor extends Persona {
    
}
