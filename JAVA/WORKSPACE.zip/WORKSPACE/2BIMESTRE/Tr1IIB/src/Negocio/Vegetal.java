
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Vegetal {
    
}
