
package Negocio;

/**
 *
 * @author josune.singaña
 */
public class Vehiculo implements Actor, ObjetoInerte {
    
}
