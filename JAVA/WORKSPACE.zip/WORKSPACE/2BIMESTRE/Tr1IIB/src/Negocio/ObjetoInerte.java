
package Negocio;

/**
 *
 * @author Josune.singaña
 */
public interface ObjetoInerte {
    
}
