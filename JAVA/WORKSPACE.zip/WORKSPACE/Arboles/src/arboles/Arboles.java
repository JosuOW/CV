/*CLASE MAIN*/
package arboles;

import java.util.Optional;
import javax.swing.JOptionPane;
import org.w3c.dom.Node;

/**
 *
 * @josune.singaña
 */
public class Arboles {

    public static void main(String[] args) {
        Node node=new Node(9);
        node.add(16);
        node.add(7);
        node.add(3);
        node.add(6);
        node.add(10);
        Optional<Node> result = node.find(10);
        if (result.isPresent()) {
            System.out.println(result.get());
        } else {
            System.out.println("Value not found");
        }
 
        result = node.find(3);
        if (result.isPresent()) {
            System.out.println(result.get());
        } else {
            System.out.println("Value not found");
        }
       JOptionPane.showConfirmDialog(null,"In order");
        node.printInOrder();
       JOptionPane.showConfirmDialog(null,"Pos order");
       
        node.printPosOrder();
        JOptionPane.showConfirmDialog(null,"Pre order");
        node.printPreOrder();
    }

    }
    
