/*TAREA EN CLASE 10/1/2023
CLASE Arboles*/

package arboles;
 import java.util.Optional;
public class Node {
  

/**
 * @author raidentrance
 *
 */

	private Integer value;
	private Node left;
	private Node right;
//Constructor
	public Node(Integer value) {
		this.value = value;
	}
//Métodos getter setter
	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node right) {
		this.right = right;
	}
//Agregar nodos
	public void add(Integer value) {
		if (value < this.value) {
			if (left != null) {
				left.add(value);
			} else {
				left = new Node(value);
			}
		} else {
			if (right != null) {
				right.add(value);
			} else {
				right = new Node(value);
			}
		}
	}
//Búsqueda de un elemento dentro del nodo
	public Optional<Node> find(Integer value) {
		if (value == this.value) {
			return Optional.of(this);
		} else if (value < this.value) {
			if (this.left != null) {
				return this.left.find(value);
			} else {
				return Optional.empty();
			}
		} else {
			if (this.right != null) {
				return this.right.find(value);
			} else {
				return Optional.empty();
			}
		}
	}
/*Despliegue de lista de nodos en inorden
        como se lee, de izquierda a derecha*/
        
	public void printInOrder() {
		if (left != null) {
			left.printInOrder();
		}
		System.out.println(value);
		if (right != null) {
			right.printInOrder();
		}
	}
/*Despliegue de lista de nodos en preorden
        De raíz, izquierda,derecha*/
	public void printPreOrder() {
		System.out.println(value);
		if (left != null) {
			left.printPreOrder();
		}
		if (right != null) {
			right.printPreOrder();
		}
	}

	public void printPosOrder() {
		if (left != null) {
			left.printPreOrder();
		}
		if (right != null) {
			right.printPreOrder();
		}
		System.out.println(value);
	}

	@Override
	public String toString() {
		return "Node [value=" + value + ", left=" + left + ", right=" + right + "]";
	}


}

