package Negocio;

import Vista.JFEcuacion;
/**
 *
 * @josune.singaña
 */
public class Principal {
     public static void main(String[] args) {
   JFEcuacion jfecuacion = new JFEcuacion();
        jfecuacion.setVisible(true);
    }
}
