
package Negocio;

import java.util.StringTokenizer;
import javax.swing.JOptionPane;
/**
 *
 * @josune.singaña
 */

public class Ecuacion {
    private double x2, x, c;

    public Ecuacion() {
    }

    public Ecuacion(double x2, double x, double c) {
        this.x2 = x2;
        this.x = x;
        this.c = c;
    }

    public double getX2() {
        return x2;
    }

    public void setX2(double x2) {
        this.x2 = x2;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }


    
    public void setEcuacion(String linea){
        //String linea;
        
        try{
            //linea=JOptionPane.showInputDialog( "Ingrese una ecuacion tipo x^2 + x + c; separe los terminos\ncon un espacio.");
            StringTokenizer tokens = new StringTokenizer(linea);
            this.x2=Double.parseDouble(tokens.nextToken());
            this.x=Double.parseDouble(tokens.nextToken());
            this.c=Double.parseDouble(tokens.nextToken());
        } catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Error, ingrese numeros.", "Ingreso INCORRECTO", 0);
            /*
            0: ERROR_MESSAGE
            1: INFORMATION_MESSAGE
            2: WARNING_MESSAGE
            3: QUESTION_MESSAGE
            4: PLAIN_MESSAGE */
            e.printStackTrace();
        }
    }
    
    public Ecuacion sumarEcuaciones(Ecuacion ecuacion2){
        Ecuacion ecuacionAux = new Ecuacion();
        ecuacionAux.x2=this.x2+ecuacion2.x2;
        ecuacionAux.x=this.x+ecuacion2.x;
        ecuacionAux.c=this.c+ecuacion2.c;

        return ecuacionAux;
    }
        @Override
    public String toString() {
        return " " + this.x2 + "x^2 + " + this.x + "x +" + this.c + "\n";
    }
    
}