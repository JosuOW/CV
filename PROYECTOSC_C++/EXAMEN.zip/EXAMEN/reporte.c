#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio2.h>
 /* autor: Josune Singaña */
	/* fecha:05-09-2022 */	
typedef struct Registros{
	char nombre[80];
		char materia[80][80];
			float notas[80][3];
			int num;
} Registro;
int existe(char *nombreFichero);
void mostrarFichero(char *nombreFichero);

int main()
{
	  char nombreFichero[30]; 
  char resp = 's';
   textbackground(WHITE);
	clrscr();
	textcolor(LIGHTRED);
 	gotoxy (10,2); printf("Nombre del fichero: ");
  gets(nombreFichero);
  	textcolor(BLUE);
  if (existe(nombreFichero))
    mostrarFichero(nombreFichero);
  else 
  	    printf("El fichero no existe.");
}

int existe(char *nombreFichero)
{
	FILE *pf = NULL;
	int exis = 0;
	if ((pf = fopen(nombreFichero, "r")) != NULL)
	{
		exis = 1;
		fclose(pf);
	}
	return exis;
}

void mostrarFichero(char *nombreFichero){
int x;
	float  prom;
  FILE *pf = NULL; 
    Registro reg; 
  if ((pf = fopen(nombreFichero, "rb")) == NULL)  {
    printf("*** El fichero no puede abrirse. ***");
    exit(1);
  }
  fread(&reg, sizeof(reg), 1, pf);
  while (!ferror(pf) && !feof(pf))
  {
    system("cls"); // limpiar la pantalla
	clrscr();
	textcolor(LIGHTRED);
 	gotoxy (5,2); printf("<<<<<<<<<<<<<<<<<<<<<<<<< REPORTE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	textcolor(6);gotoxy (5,3); printf("Estudiante: %s \n",reg.nombre );
		fflush(stdin);
	textcolor(0);gotoxy (5,4);  	  	printf("|       MATERIA          |   PROMEDIO      |    ESTADO   | \n" );
   	for( x=0; x<reg.num;x++){
  	textcolor(1);gotoxy (5,5+x);  printf("| %s ",reg.materia[x] );
    prom = (reg.notas[x][0] + reg.notas[x][1] + reg.notas[x][2])/3;
   	textcolor(8);gotoxy (30,5+x); printf("| %.2f ",prom);
   if(prom>=7){
   textcolor(2);gotoxy (48,5+x);printf("| APROBADO    |\n" );
   }else{
   	textcolor(4);gotoxy (48,5+x);printf("| REPROBADO    |\n" );
   }
}
	fflush(stdin);
    // Hacer una pausa
    printf("Pulse <Entrar> para continuar ");
    getchar(); fflush(stdin);
    fread(&reg, sizeof(reg), 1, pf);

  }

  if (ferror(pf))
    perror("Error durante la lectura");
  fclose(pf);
}



























