#include<stdio.h>
#include<conio2.h>
    /* autor: Josune Singaña 
	 fecha: 20-06-2022 */
int main() {
	int div, n, num;
    	textbackground(MAGENTA);
	clrscr();
	textcolor(LIGHTGRAY);
	gotoxy (25,2);printf(" APLICACION GENERA LOS NUMEROS PRIMOS ENTRE 1 Y N \n");
     textcolor(BROWN);
	gotoxy (28, 4);printf(" INGRESE EL LIMITE DE LA SERIE (N): ");
	scanf("%i",&n);
	num = 2;
	textcolor(LIGHTCYAN);
	gotoxy (28, 6);printf("Los numeros primos entre 1 y %i son: \n",n);
	textcolor(GREEN);
	gotoxy (15, 8);
	while (num<=n) {
		div = 2;
		while (div<num && num%div!=0) {
			div = div+1;
		}
		if (div>=num && num>1) {
			printf("%i ",num);
		}
		num = num+1;
	}
	printf("\n");
	return 0;
}

