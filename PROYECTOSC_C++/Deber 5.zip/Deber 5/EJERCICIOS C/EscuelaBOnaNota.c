#include<stdio.h>
#include<conio2.h>
    /* autor: Josune Singaña */
	/* fecha: 19-06-2022 */
int main() {
	textbackground(YELLOW);
	clrscr();
	textcolor(MAGENTA);
	int cont0=0, cont1=0, cont2=0, cont3=0, cont4=0, cont5=0, edad, grado;
	char resp;
	int suma0=0, suma1=0, suma2=0, suma3=0, suma4=0, suma5=0;
	/* autor: Josune Singana */
	/* fecha: 19-06-2022 */
     gotoxy (25,2);printf(" APLICACION CALCULA EL PROMEDIO DE EDAD POR GRADO ESCUELA BONANOTA\n");
	resp = 's';
	gotoxy (15,3);printf("CONSIDERANDO QUE: \n");
	gotoxy (15,4);printf("0 Transicion \n");
    gotoxy (15,5);printf("1 Primero de primaria \n");
	gotoxy (15,6);printf("2 Segundo de primaria \n");
	gotoxy (15,7);printf("3 Tercero de primaria \n");
	gotoxy (15,8);printf("4 Cuarto de primaria \n");
	gotoxy (15,9);printf("5 Quinto de primaria \n");
	while (resp=='s' || resp=='S') {
		textcolor(CYAN);
		printf("\nINGRESE EL GRADO DEL ESTUDIANTE: ");
		scanf("%i",&grado);
		printf("INGRESE LA EDAD DEL ESTUDIANTE: ");
		scanf("%i",&edad);
		switch (grado) {
			case 0:
				cont0 = cont0+1;
				suma0 = suma0+edad;
				break;
			case 1:
				cont1 = cont1+1;
				suma1 = suma1+edad;
				break;
			case 2:
				cont2 = cont2+1;
				suma2 = suma2+edad;
				break;
			case 3:
				cont3 = cont3+1;
				suma3 = suma3+edad;
				break;
			case 4:
				cont4 = cont4+1;
				suma4 = suma4+edad;
				break;
			case 5:
				cont5 = cont5+1;
				suma5 = suma5+edad;
				break;
		}
		printf("HAY MAS ALUMNOS: s o n ");
		resp = getch();
	}
	textcolor(LIGHTRED);
	printf("\nPROMEDIO DE TRANSICION:%6.2f\n",(float)suma0/cont0);
	printf("PROMEDIO DE GRADO 1: %6.2f\n",(float)suma1/cont1);
	printf("PROMEDIO DE GRADO 2: %6.2f\n",(float)suma2/cont2);
	printf("PROMEDIO DE GRADO 3: %6.2f\n",(float)suma3/cont3);
	printf("PROMEDIO DE GRADO 4: %6.2f\n",(float)suma4/cont4);
	printf("PROMEDIO DE GRADO 5: %6.2f\n",(float)suma5/cont5);
	return 0;
}

