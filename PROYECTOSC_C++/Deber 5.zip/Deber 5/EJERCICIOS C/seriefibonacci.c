#include<stdio.h>
#include<conio2.h>
    /* autor: Josune Singaña 
	fecha: 19-06-2022 */
int main() {
	textbackground(RED);
	clrscr();
	textcolor(YELLOW);
	int fibo, i, j, l, num;
		gotoxy(25,2);printf(" APLICACION GENERA SERIE DE NUMEROS DE FIBONACCI \n");
	gotoxy(32,5);printf("INGRESE EL LIMITE DE LA SERIE: ");
	scanf("%i",&l);
	num = 1;
	j = 0;
	fibo = 0;
	for (i=1;i<=l;i+=1) {
			textcolor(LIGHTGRAY);
		printf("%i  ",num);
		fibo = num+j;
		j = num;
		num = fibo;
	}
	return 0;
}

