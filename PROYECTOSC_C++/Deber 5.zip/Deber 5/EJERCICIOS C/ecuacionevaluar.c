#include<stdio.h>
#include<math.h>
#include<conio2.h>
    /* autor: Josune Singaña 
	 fecha: 20-06-2022 */
int main() {
	textbackground(BLUE);
	clrscr();
	textcolor(LIGHTCYAN);
	float fx, x;
	int i=4,j=0;
	textbackground(12);
	gotoxy (25,2);printf(" APLICACION EVALUA LA FUNCION f(x)=2x^2+3x-4 EN EL INTERVALO (-5,5)\n");
	getch();
	for (x=-5;x<=5;x+=0.5) {
		fx = 2*pow(x,2)+3*x-4;
			gotoxy (50,i++);printf("%.2f    %.2f\n",x,fx);
	    textbackground(j++);
	if (j==1) {j=4;} if (j==6) {j=8;} if (j==10) {j=14;} if (j==14) {j=0;}
	}
	return 0;	
}

