#include<stdio.h>
#include<conio2.h>
    /* autor: Josune Singaña 
	 fecha: 20-06-2022 */
int main() {
		textbackground(LIGHTGRAY);
	clrscr();
	textcolor(LIGHTCYAN);
	int i=2;
	float nota;
		textcolor(LIGHTRED);
	gotoxy (40,2);printf(" APLICACION VALIDA NOTA \n");
	 textcolor(LIGHTBLUE);
	gotoxy (32,4);printf(" INGRESE LA NOTA A SER VALIDADA: ");
	scanf("%f",&nota);
	
	while (nota<0 || nota>5) {
		
		textcolor(LIGHTMAGENTA);
			gotoxy (30,i+3);printf("Error la nota esta fuera del intervalo 0-5 \n");
		if (nota<0) {
			textcolor(GREEN);
			gotoxy (30,i+4);printf("La nota es menor a 0\n");
		} else {
			textcolor(GREEN);
			gotoxy (30,i+4);printf("La nota es mayor a 5.0\n");
		}
		textcolor(LIGHTBLUE);
		gotoxy (30,i+5);printf(" Vuelva a intentar: ");
		scanf("%f",&nota);
		i=i+4;
	}
	textcolor(BROWN);
	gotoxy (30,i+2);printf("NOTA VALIDA. GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

