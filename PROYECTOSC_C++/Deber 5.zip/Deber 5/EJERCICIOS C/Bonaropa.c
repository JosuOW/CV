#include<stdio.h>
#include<conio2.h>
    /* autor: Josune Singaña */
	/* fecha: 20-06-2022 */
int main() {
	int i, ma = 0, mayor = 0, mb = 0, menor = 0, vm, pm = 0;
	char opc;
	float tm = 0;
	textbackground(YELLOW);
	clrscr();
	textcolor(LIGHTRED);
	gotoxy (10,2);printf(" APLICACION CALCULA EL PROMEDIO DE VENTAS MENSUALES, EL MES CON MAS VENTAS Y EL MES CON MENOS VENTAS \n");
	i = 0;
	opc = 's';
	while (opc =='s' || opc=='S') {
		i = i+1;
		textcolor(LIGHTBLUE);
	gotoxy (15,i+3);	printf("INGRESE LAS VENTAS DEL MES %i : ",i);
		textcolor(DARKGRAY);
		scanf("%i",&vm);
		if (vm>ma) {
			mayor = i;
			ma = vm;
		} else {
			mb = vm;
			if (vm<=mb) {
				menor = i;
			}
		}
		pm = (pm+vm);
		textcolor(LIGHTGREEN);
		gotoxy (15,i+4); printf("DESEA AGREGAR OTRO MES: s o n ");
		textcolor(DARKGRAY);
		opc = getch();
	}
	tm = pm/i;
	textcolor(BLUE);
	gotoxy (25,i+5);printf("EL MES %i TIENE MAS VENTAS :%i\n",mayor,ma);
	gotoxy (25,i+6);printf("EL MES %i TIENE MENOS VENTAS :%i\n",menor,mb);
	gotoxy (25,i+7);printf("EL PROMEDIO DE LOS %i MESES ES: %.2f\n",i,tm);
	return 0;
}

