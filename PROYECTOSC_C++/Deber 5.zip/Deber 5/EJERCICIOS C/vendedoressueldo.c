
#include<stdio.h>
#include<conio2.h>
	/* autor: Josune Singana */
	/* fecha: 18-06-2022 */
int main() {
	float comisiones;
	float comisionestotales;
	int contv;
	int i;
	int n;
	int numv;
	float sueldo;
	float sueldototal;
	float tcomisiones;
	float tsueldo;
	float vv;
		textbackground(YELLOW);
	clrscr();
		textcolor(LIGHTRED);
	gotoxy (25,2);printf(" APLICACION CALCULA LA COMISION Y SUELDO TOTAL DE VENDEDORES \n");
	textcolor(MAGENTA);
	gotoxy (8,3);printf("INGRESE EL NUMERO DE VENDEDORES: ");
	scanf("%i",&n);
	printf("INGRESE SUELDO BASE: ");
	scanf("%f",&sueldo);
	tsueldo = 0;
	tcomisiones = 0;
	for (i=1;i<=n;i+=1) {
			textcolor(BLUE);
		printf("CUANTAS VENTAS HA REALIZADO EL VENDEDOR %i :",i);
		scanf("%i",&numv);
		contv = 1;
		sueldototal = 0;
		comisionestotales = 0;
		comisiones = 0;
		do {
			vv = 0;
			textcolor(LIGHTBLUE);
			printf("INGRESE EL VALOR DE LA VENTA %i DEL VENDEDOR %i :",contv,i);
			scanf("%f",&vv);
			comisiones = vv*0.10;
			comisionestotales = comisiones+comisionestotales;
			contv = contv+1;
		} while (contv<=numv);
		sueldototal = comisionestotales+sueldo;
			textcolor(CYAN);
		printf("EL VALOR TOTAL DE LAS COMISIONES DEL VENDEDOR %i es: %f\n",i,comisionestotales);
		printf("EL SUELDO TOTAL DEL VENDEDOR %i es: %f\n",i,sueldototal);
		tsueldo = sueldototal+tsueldo;
		tcomisiones = comisionestotales+tcomisiones;
	}
		textcolor(LIGHTGREEN);
	printf("EL TOTAL A PAGAR DE LA COMPANIA POR SUELDOS ES: %f\n",tsueldo);
	printf("EL TOTAL A PAGAR DE LA COMPANIA POR COMISIONES ES: %f\n",tcomisiones);
	return 0;
}

