#include<stdio.h>
#include<math.h>
#include<conio2.h>
    /* autor: Josune Singaña */
	/* fecha: 19-06-2022 */
int main() {
	textbackground(BLUE);
	clrscr();
	int num, resp;
	textcolor(LIGHTGRAY);
     gotoxy (25,2);	printf(" APLICACION CALCULA EL CUBO DE LOS POSITIVOS Y CUADRADO DE LOS NEGATIVOS\n");
	textcolor(YELLOW);
		 gotoxy (15,5);printf("INGRESE UN ENTERO POSITIVO O NEGATIVO, PARA TERMINAR EL CERO:          ");
	gotoxy (76,5);scanf("%i",&num);
	while (num!=0) {
	     textcolor(LIGHTCYAN);
		if (num>0) {
			resp = pow(num,3);
			gotoxy (55,7);printf("POSITIVO AL CUBO:             ");
		} else {
			resp = pow(num,2);
			gotoxy (55,7);printf("NEGATIVO AL CUADRADO:            ");	
			
		}
		
		gotoxy (76,7);printf("%i\n",resp);
		textcolor(YELLOW);
		gotoxy (15,5); printf("INGRESE UN ENTERO POSITIVO O NEGATIVO, PARA TERMINAR EL CERO:           ");
		gotoxy (76,5);	scanf("%i",&num);
	}
			gotoxy (55,7);printf("                       ");
	return 0;
}

