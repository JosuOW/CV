#include<conio2.h>
#include<stdio.h>
#include<math.h>
/* autor: Josune Singana */
	/* fecha 20- Junio-2022 */
int main() {
	int cen, cmillo, dec, dmillo,  mcen,  mdec, mil, millo, milmillo, num, suma, uni;
	
	textbackground(LIGHTGRAY);
	clrscr();
	textcolor(MAGENTA);
	gotoxy (25,2);printf("APLICACION SUMA LOS DIGITOS DE UN NUMERO\n");
	textcolor(LIGHTBLUE);
		gotoxy (15,4);printf("INGRESA UN NUMERO ENTERO CUALQUIERA: ");
	scanf("%i",&num);
	while (num<-9999999999 || num>9999999999) {
		textcolor(CYAN);
		gotoxy (15,5);printf("Fuera del rango, intente de nuevo: ");
		scanf("%i",&num);
	}
	uni = num%10;
     num= trunc(num/10);
	dec = num%10;
	num= trunc(num/10);
	cen = num%10;
	num= trunc(num/10);
	mil = num%10;
	num= trunc(num/10);
	mdec = num%10;
	num= trunc(num/10);
	mcen = num%10;
    num= trunc(num/10);
	millo = num%10;
	num= trunc(num/10);
	dmillo = num%10;
	num= trunc(num/10);
	cmillo = num%10;
	num= trunc(num/10);
	milmillo = num;
	suma = mil+cen+dec+uni+mcen+mdec+millo+dmillo+cmillo+milmillo;
	textcolor(LIGHTRED);
	gotoxy (25,6);printf("LA SUMA DE LOS DIGITOS ES: %i\n",suma);
	return 0;
}

