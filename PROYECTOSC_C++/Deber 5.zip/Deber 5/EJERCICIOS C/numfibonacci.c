#include<stdio.h>
#include<conio2.h>
    /* autor: Josune Singaña 
	fecha: 19-06-2022 */
int main() {
	textbackground(GREEN);
	clrscr();
	textcolor(WHITE);
	int fibo, i, j, nesi, num;
	gotoxy(25,2);printf(" APLICACION GENERA EL N-ESIMO NUMERO DE LA SERIE FIBONACCI \n");
	gotoxy(32,5);printf("INGRESE EL N-ENESIMO NUMERO QUE DESEA: ");
	scanf("%i",&nesi);
	num = 1;
	j = 0;
	fibo = 0;
	for (i=1;i<=nesi-1;i+=1) {
		fibo = num+j;
		j = num;
		num = fibo;
	}
	textcolor(YELLOW);
	gotoxy(52,7);printf("%i\n",num);
	return 0;
}

