#include<stdio.h>
#include<math.h>
#include<conio2.h>
int main() {
		textbackground(BLACK);
	clrscr();
	textcolor(LIGHTCYAN);
	float a, b, r;
	char dat, resp;
	int f, num;
	/* Autor:  Josune Singana */
	/* Fecha: 20-Junio-2022 */
	resp = 's';
	while ( resp=='s' || resp=='S' ) {
		gotoxy (40,2);printf("APLICACION SIMULA UNA CALCULADORA\n");
		textcolor(LIGHTGREEN);
		printf("CONSIDERANDO QUE: \n");
		printf("1 Suma \n");
		printf("2 Resta \n");
		printf("3 Producto \n");
		printf("4 Division \n");
		printf("5 Potencia \n");
		printf("6 Porcentaje \n");
		printf("0 Salir \n");
		printf("INGRESE LA OPCION A ESCOGER: ");
		scanf("%i",&num);
		textcolor(LIGHTRED);
		if (num==1 || num==2 || num==3) {
			printf("INGRESE EL PRIMER VALOR: ");
			scanf("%f",&a);
			printf("INGRESE EL SEGUNDO VALOR: ");
			scanf("%f",&b);
		}
		switch (num) {
		case 1:
			printf("LA SUMA ES:%.2f\n",a+b);
			break;
		case 2:
			printf("LA RESTA ES:%.2f\n",a-b);
			break;
		case 3:
			printf("EL PRODUCTO ES:%.2f\n",a*b);
			break;
		case 4:
			printf("INGRESE EL VALOR DEL DIVIDENDO: ");
			scanf("%f",&a);
			printf("INGRESE EL VALOR DEL DIVISOR: ");
			scanf("%f",&b);
			while (b==0) {
				printf("No se puede efectuar una division para cero\n");
				printf("Intente de nuevo: ");
				scanf("%f",&b);
			}
			printf("LA DIVISION ENTRE %.2f y %.2f ES: %.2f\n",a,b,a/b);
			break;
		case 5:
			printf("INGRESE EL VALOR DE LA BASE: ");
			scanf("%f",&a);
			printf("INGRESE EL VALOR DE LA POTENCIA: ");
			scanf("%f",&b);
			printf("EL NUMERO %.2f ELEVADO A %.2f ES: %.2f\n",a,b,pow(a,b));
			break;
		case 6:
			printf("INGRESE EL VALOR TOTAL: ");
			scanf("%f",&b);
			printf("INGRESE EL VALOR DE PORCENTAJE QUE QUIERE: ");
			scanf("%f",&a);
			r = (a*100)/b;
			printf(" %.2f REPRESENTA EL %.2f PORCIENTO DE: %.2f\n",a,r,b);
			break;
		case 0:
			printf("Salir\n");
			if(num==0){
			break; /* En el caso de que n sea un cero, el bucle se interrumpe.*/
			
		default:
			printf("ERROR ENTERO FUERA DE RANGO\n");
		}
		}
		textcolor(LIGHTMAGENTA);
		printf("DESEA BORRAR LOS DATOS OBTENIDOS: s o n ");
		dat = getch();
		if (dat=='s' || dat=='S' ) { clrscr();	}
		textcolor(LIGHTGRAY);
		printf("\nDESEA REALIZAR UN CALCULO NUEVO: s o n ");
		resp = getch();
		clrscr();
    }
	return 0;
textcolor(LIGHTBLUE);
printf("GRACIAS POR USAR LA APLICACION\n");
}
