#include<stdio.h>
#include <stdlib.h> 
#include<conio2.h>
 /* autor: Josune Singaña */
	/* fecha: 30-08-2022 */
typedef struct Fechas{
	int mes;
	int dia;
	int anno;
} Fecha;

typedef struct Registros{
	char nombre[80];
	char calle[80];
	char ciudad[80];
	int no_cuenta;
	int tipo_cuenta;
	float anteriorsaldo;
	float nuevosaldo;
	float pago;
	Fecha ultimopago;
} Registro;

int existe(char *nombreFichero); 
void crearFichero(char *nombreFichero);
main(){
	textbackground(YELLOW);
	clrscr();
	textcolor(LIGHTRED);
	gotoxy (10,2);
	printf("PROGRAMA CREA UN ARCHIVO CON REGISTRO DE CLIENTES");
		textcolor(BLUE);
	char nombreFichero[30]; // nombre del fichero 
 char resp = 's'; 
 // Solicitar el nombre del fichero 
 printf("\nNombre del fichero: "); 
 gets(nombreFichero); 

 // Verificar si el fichero existe 
 if (existe(nombreFichero)) 
 { 
 printf("\n El fichero existe ¿desea sobrescribirlo? (s/n) "); 
 resp = getchar(); 
 fflush(stdin); 
 } 
 if (resp == 's') 
 { 
 crearFichero(nombreFichero); 
 } 
} 
int existe(char *nombreFichero) 
{ 
 FILE *pf = NULL; 
 // Verificar si el fichero existe 
 int exis = 0; // no existe 
 if ((pf = fopen(nombreFichero, "r")) != NULL) 
 { 
 exis = 1; // existe 
 fclose(pf); 
 } 
 return exis; 
}
void crearFichero(char *nombreFichero) 
{ 
 FILE *pf = NULL; // identificador del fichero 
Registro  reg; // definir un registro 
 char resp; 
 // Abrir el fichero nombreFichero para escribir "w" 
 if ((pf = fopen(nombreFichero, "wb")) == NULL) 
 { 
 printf("El fichero no puede abrirse."); 
 exit(1); 
 } 
 // Leer datos de la entrada estándar y escribirlos 
 // en el fichero 
  int i=0;
 do 
 { 
 printf("\nIngrese el nombre del cliente[%d]: ",i+1); gets(reg.nombre);
	printf("\nIngrese la direccion: "); gets(reg.calle);
	printf("\nIngrese la ciudad : "); gets(reg.ciudad);
		fflush(stdin); 
	printf("\nIngrese el numero de cuenta: ");;scanf("%d",&reg.no_cuenta);
	printf("\nIngrese el tipo de cuenta, 1-ahorro, 2-corriente: "); scanf("%d",&reg.tipo_cuenta);
	printf("\nIngrese el saldo anterior: "); scanf("%f",&reg.anteriorsaldo);
	printf("\nIngrese el nuevo saldo: "); 	scanf("%f",&reg.nuevosaldo);
	printf("\nIngrese el pago: ");	scanf("%f",&reg.pago);
	fflush(stdin); 
	printf("\nIngrese la fecha de ultimo pago (dia): ");	scanf("%d",&reg.ultimopago.dia);
	printf("\nIngrese la fecha de ultimo pago (mes): "); scanf("%d",&reg.ultimopago.mes);
	printf("\nIngrese la fecha de ultimo pago (anno): ");	scanf("%d",&reg.ultimopago.anno); 
 fflush(stdin); 
 fwrite(&reg, sizeof(reg), 1, pf); 
 if (ferror(pf)) 
 { 
 perror("Error durante la escritura"); 
 exit(2); 
 } 
 printf("¿desea escribir otro registro? (s/n) "); 
 resp = getchar(); 
 fflush(stdin); 
 i++;
 } 
 while (resp == 's'); 
} 
