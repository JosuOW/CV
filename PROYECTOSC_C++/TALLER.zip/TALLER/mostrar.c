/*** Leer datos de un fichero registro a registro ***/
/* fread.c
 */
#include <stdio.h>
#include <stdlib.h>
#include<conio2.h>
 /* autor: Josune Singaña */
	/* fecha: 30-08-2022 */
typedef struct Fechas{
	int mes;
	int dia;
	int anno;
} Fecha;

typedef struct Registros{
	char nombre[80];
	char calle[80];
	char ciudad[80];
	int no_cuenta;
	int tipo_cuenta;
	float anteriorsaldo;
	float nuevosaldo;
	float pago;
	Fecha ultimopago;
} Registro;

int existe(char *nombreFichero);
void mostrarFichero(char *nombreFichero);
void modificarReg(FILE *pf, int nreg); 
main()
{
  char nombreFichero[30]; // nombre del fichero
  char resp = 's';
   textbackground(WHITE);
	clrscr();
	textcolor(LIGHTRED);
  // Solicitar el nombre del fichero
 	gotoxy (10,2); printf("Nombre del fichero: ");
  gets(nombreFichero);
  	textcolor(BLUE);
  // Verificar si el fichero existe
  if (existe(nombreFichero))
    mostrarFichero(nombreFichero);
  else 
  	    printf("El fichero no existe.");
}

  
int existe(char *nombreFichero){
  FILE *pf = NULL;

  // Verificar si el fichero existe
  int exis = 0; // asume no existe
  if ((pf = fopen(nombreFichero, "r")) != NULL)
  {
    exis = 1;   // existe
    fclose(pf);
  }
  return exis;
}

void mostrarFichero(char *nombreFichero)
{

  FILE *pf = NULL;   // identificador del fichero
       // definir un registro

Registro reg; 
  // Abrir el fichero nombreFichero para leer "r"
  if ((pf = fopen(nombreFichero, "rb")) == NULL)
  {
    printf("*** El fichero no puede abrirse. ***");
    exit(1);
  }

  // Leer datos del fichero y mostrarlos en la salida estándar
  fread(&reg, sizeof(reg), 1, pf);

  while (!ferror(pf) && !feof(pf))
  {
    system("cls"); // limpiar la pantalla
	 printf("Nombre del cliente:  %s\n ", reg.nombre);
	printf("Direccion: %s\n ", reg.calle);
	printf("Ciudad : %s\n ",reg.ciudad);
	 fflush(stdin);
	printf("Numero de cuenta: %d\n",reg.no_cuenta);
	printf("Tipo de cuenta, 1-ahorro, 2-corriente: %d\n",reg.tipo_cuenta);
	fflush(stdin);
	printf("Saldo anterior: %f.2\n",reg.anteriorsaldo);
	printf("Nuevo saldo: %.2f\n", reg.nuevosaldo);
	printf("Pago: %f\n",reg.pago);
	 fflush(stdin);
	printf("Fecha de ultimo pago (dia): %d\n",reg.ultimopago.dia);
	printf("Fecha de ultimo pago (mes): %d\n",reg.ultimopago.mes);
	printf("Fecha de ultimo pago (anno): %d\n",reg.ultimopago.anno); 
	fflush(stdin);
    // Hacer una pausa
    printf("Pulse <Entrar> para continuar ");
    getchar(); fflush(stdin);
/*reg[i]=reg;*/
    // Leer el siguiente registro del fichero 
    fread(&reg, sizeof(reg), 1, pf);

  }

  if (ferror(pf))
    perror("Error durante la lectura");
  fclose(pf);
}


