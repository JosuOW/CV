
/* fread.c
 */
#include <stdio.h>
#include <stdlib.h>
#include<conio2.h>
 /* autor: Josune Singaña */
	/* fecha: 30-08-2022 */
typedef struct Fechas{
	int mes;
	int dia;
	int anno;
} Fecha;

typedef struct Registros{
	char nombre[80];
	char calle[80];
	char ciudad[80];
	int no_cuenta;
	int tipo_cuenta;
	float anteriorsaldo;
	float nuevosaldo;
	float pago;
	Fecha ultimopago;
}Registro;

void mostrarReg(FILE *pf, int nreg); 
void modificarReg(FILE *pf, int nreg); 
main()
{ 
  textbackground(LIGHTGRAY);
	clrscr();
	textcolor(LIGHTRED);
 FILE *pf = NULL; // puntero a un flujo 
 int totalreg = 0; // número total de registros 
 int nreg = 0; // número de registro 
 char nombreFichero[30]; // nombre del fichero 
 int c = 0, respuesta = 0; 
  // Solicitar el nombre del fichero
   	gotoxy (10,2);printf("Nombre del fichero: ");
  gets(nombreFichero);
	// Abrir el fichero para leer y escribir "r+" 
 if ((pf = fopen(nombreFichero, "r+b")) == NULL) 
 { 
 printf("Error: no se puede abrir el fichero\n"); 
 exit(1); 
 } 
 // Calcular el nº total de registros del fichero 
 textcolor(BLUE);
 fseek(pf, 0L, SEEK_END); 
 totalreg = (int)ftell(pf)/sizeof(Registro); 
 // Presentar un registro en pantalla y modificarlo si procede 
 do 
 { 
 printf("Nº registro entre 1 y %d (0 para salir): ", totalreg); 
 c = scanf("%d", &nreg); 
 fflush(stdin); 
 if (c && (nreg >= 1) && (nreg <= totalreg)) 
 { 
 mostrarReg(pf, nreg); 
 // Preguntar si se desea modificar el registro seleccionado 
 do 
 { 
 printf ("¿Desea modificar este registro? (s/n) "); 
 respuesta = getchar(); 
 fflush(stdin); 
 } 
 while (tolower(respuesta != 's') && tolower(respuesta) != 'n'); 
	  if (respuesta == 's') 
 modificarReg(pf, nreg); 
 } 
 } 
 while (nreg); 
 fclose(pf); 
} 

void mostrarReg(FILE *pf, int nreg) 
{ 
 long desp = 0; // desplazamiento en bytes 
 Registro reg; // variable de tipo registro 
 int bytesPorReg = sizeof(Registro); 
 // Visualizar un registro 
 desp = (long)(nreg - 1) * bytesPorReg; 
 fseek(pf, desp, SEEK_SET); 
 fread(&reg, bytesPorReg, 1, pf); 
 if (ferror(pf)) 
 { 
 printf("Error al leer un registro del fichero.\n"); 
 return; 
 } 
   system("cls"); // limpiar la pantalla
	 printf("Nombre del cliente:  %s\n ", reg.nombre);
	printf("Direccion: %s\n ", reg.calle);
	printf("Ciudad : %s\n ",reg.ciudad);
	 fflush(stdin);
	printf("Numero de cuenta: %d\n",reg.no_cuenta);
	printf("Tipo de cuenta, 1-ahorro, 2-corriente: %d\n",reg.tipo_cuenta);
	printf("Saldo anterior: %f\n",reg.anteriorsaldo);
	printf("Nuevo saldo: %f\n", reg.nuevosaldo);
	printf("Pago: %f\n",reg.pago);
	 fflush(stdin);
	printf("Fecha de ultimo pago (dia): %d\n",reg.ultimopago.dia);
	printf("Fecha de ultimo pago (mes): %d\n",reg.ultimopago.mes);
	printf("Fecha de ultimo pago (anno): %d\n",reg.ultimopago.anno);
}

void modificarReg(FILE *pf, int nreg) 
{ 
 long desp = 0; // desplazamiento en bytes 
 Registro reg; // variable de tipo registro 
 int bytesPorReg = sizeof(Registro); 
  system("cls"); // limpiar la pantalla
	 printf("\nIngrese el nombre del cliente: "); gets(reg.nombre);
	printf("\nIngrese la direccion: "); gets(reg.calle);
	printf("\nIngrese la ciudad : "); gets(reg.ciudad);
		fflush(stdin); 
	printf("\nIngrese el numero de cuenta: ");;scanf("%d",&reg.no_cuenta);
	printf("\nIngrese el tipo de cuenta, 1-ahorro, 2-corriente: "); scanf("%d",&reg.tipo_cuenta);
	printf("\nIngrese el saldo anterior: "); scanf("%f",&reg.anteriorsaldo);
	printf("\nIngrese el nuevo saldo: "); 	scanf("%f",&reg.nuevosaldo);
	printf("\nIngrese el pago: ");	scanf("%f",&reg.pago);
	fflush(stdin); 
	printf("\nIngrese la fecha de ultimo pago (dia): ");	scanf("%d",&reg.ultimopago.dia);
	printf("\nIngrese la fecha de ultimo pago (mes): "); scanf("%d",&reg.ultimopago.mes);
	printf("\nIngrese la fecha de ultimo pago (anno): ");	scanf("%d",&reg.ultimopago.anno); 
 fflush(stdin); 
 // Escribir un registro en el fichero 
 fseek(pf, -bytesPorReg, SEEK_CUR); 
 fwrite (&reg, bytesPorReg, 1, pf); 
 if (ferror(pf)) 
 { 
 printf("Error al escribir un registro en el fichero.\n"); 
 return; 
 } 
} 
