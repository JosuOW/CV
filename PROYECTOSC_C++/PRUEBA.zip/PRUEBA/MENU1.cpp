/*** Leer y ordenar datos ***/

#include<iostream>
#include<cmath>
#include<cstdlib>
#include<conio2.h>
#include<sstream>
void ordeninsercion(int v[], int n, int *niter);
void escribirvector(int vect[], int ne, char titulo[]);
/*void buscarsecuencialmente(string nombre[], string nl, int np, int &telefonof);*/
void buscabinaria(int lst[], int ne, int val, int &pos, int &nc);
int menu();

int existe(char *nombreFichero);
 /* autor: Josune Singaña */
	/* fecha: 05-09-2022 */
typedef struct Fechas{
	int mes;
	int dia;
	int anno;
} Fecha;

typedef struct Registros{
	char nombre[80];
	Fecha nac;
} Registro;

typedef struct Fechas2{
	int mes;
	int dia;
	int anno;
} Fecha2;

typedef struct Registros2{
	char nombre2[80];
	Fecha2 nac2;
} Registro2[100];


main()
{
	int opc;
 	char nombreFichero[30]; // nombre del fichero
  char resp = 's';
   textbackground(WHITE);
	clrscr();
	textcolor(LIGHTRED);
  // Solicitar el nombre del fichero
 	gotoxy (10,2); printf("Nombre del fichero: ");
  gets(nombreFichero);
  	textcolor(BLUE);
  // Verificar si el fichero existe
  if (existe(nombreFichero))
  int  i = 0;

  int totalreg = 0;
  FILE *pf = NULL;   // identificador del fichero
   Registro reg; // definir un registro
    fseek(pf, 0L, SEEK_END); 
 totalreg = (int)ftell(pf)/sizeof(Registro); 
    Registro2 reg2[totalreg-1]; 
  // Abrir el fichero nombreFichero para leer "r"
  if ((pf = fopen(nombreFichero, "rb")) == NULL)
  {
    printf("*** El fichero no puede abrirse. ***");
    exit(1);
  }

  // Leer datos del fichero y mostrarlos en la salida estándar
  fread(&reg, sizeof(reg), 1, pf);

  while (!ferror(pf) && !feof(pf))
  {
    system("cls"); // limpiar la pantalla
    	 printf("\nIngrese el nombre del usuario: %s ", reg.nombre); 
    	 	 reg2[i].nombre2=reg.nombre;
			fflush(stdin); 
		printf("\nIngrese la fecha de nacimiento (dia): %d");	scanf("%d",&reg.nac.dia);
		printf("\nIngrese la fecha de nacimiento (mes): %d"); scanf("%d",&reg.nac.mes);
		printf("\nIngrese la fechade nacimiento (anno): %d");	scanf("%d",&reg.nac.anno); 
	 fflush(stdin);
   
	fflush(stdin);
	cout << "Fecha de nacimiento (dia): " << reg.nac.dia << endl;
	reg2[i].nac2.dia=reg.nac.dia;
	cout << "Fecha de nacimiento (mes): " << reg.nac.mes << endl;
		reg2[i].nac2.mes=reg.nac.mes;
		cout << "Fecha de nacimiento pago (anio): " << reg.nac.anno << endl;
		reg2[i].nac2.anno=reg.nac.anno;
	fflush(stdin);
    // Hacer una pausa
    printf("Pulse <Entrar> para continuar ");
    getchar(); fflush(stdin);
/*reg[i]=reg;*/
    // Leer el siguiente registro del fichero 
    fread(&reg, sizeof(reg), 1, pf);
i++;
  }

  if (ferror(pf)){
  	perror("Error durante la lectura");
  fclose(pf);
  }
    
		do {
	opc = menu();
		switch (opc) {
		case 1:
			textcolor(7);
			ordeninsercionnombres(reg2,totalreg-1,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR INSERCION");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 2:
			textcolor(8);
				ordeninsercionfechas(reg2,totalreg,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR INSERCION");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 3:
			textcolor(11);
				cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++ BUSQUEDA SECUENCIAL DE ++++++++++++++ " << endl;
		textcolor(5);cout << "NOMBRE QUE QUIERES BUSCAR: ";
		textcolor(1);cin >> nl;
		/*	buscarsecuencialmente(personan,ap,nl,np,telefonof);**/
			break;
		case 4:
			textcolor(12);
		
			cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++++++++++++++++ BUSQUEDA BINARIA DE FECHA ++++++++++++++++++ " << endl;
		textcolor(11);
		cout << "QUE FECHA QUIERES BUSCAR: ";
		cin >> nf;
		
		buscabinaria(numfac,nft,nf,resp, numcomp);
	textcolor(9);
		if (resp>=0) {
			cout << "FACTURA CLIENTE: " << endl;
			cout << cliente[resp] << endl;
			cout << " NUMERO DE FACTURA: " << numfac[resp] << " NUMERO DE COMPARACIONES: " << numcomp << endl;
		} else {
			cout << nf << " NUMERO DE FACTURA NO ENCONTRADO" << endl;
		}
			break;
		
	
		case 5:
				textcolor(5);
			cout << ">>>>>>>>>> GRACIAS POR USAR ESTA APLICACION <<<<<<<<<<<<<<<" << endl;
			break;
		}
		if (opc<5) {
				textcolor(15);
			cout << "<<<<<<<<< PRESIONA CUALQUIER TECLA PARA CONTINUAR >>>>>>>>>>>>>>>" << endl;
		getch();
			clrscr();
		}
	} while (opc<5);
	return 0;
	
	
  else {
  
  	     cout << "El fichero no existe. " << endl;
}
}
  
int existe(char *nombreFichero){
  FILE *pf = NULL;

  // Verificar si el fichero existe
  int exis = 0; // asume no existe
  if ((pf = fopen(nombreFichero, "r")) != NULL)
  {
    exis = 1;   // existe
    fclose(pf);
  }
  return exis;
}


  
void ordeninsercionnombres(int v[], int n, int *niter) {
		int aux, i, j;
	int letra[n];
	for (i=0;i<n;i++){
	letra[i] =stoi(v[i].nombre.substr(0,1));
	}
	(*niter) = 0;
	for (i=1;i<n;i++) {
		j = i-1;
		aux = letra[i];
		while (j>=0 && letra[j]>aux) {
		letra[j+1] = letra[j];
			j = j-1;
			(*niter) = (*niter)+1;
		}
	letra[j+1] = aux;
	v[j+1] = aux;
	}
}


void escribirvector(int vect[], int ne, char titulo[]) {
	int i;
	cout << " " << titulo << ": { ";
	for (i=0;i<=ne-1;i++) {
		cout << vect[i] << " ";
	}
	cout << " }" << endl;
}






int menu() {
	int opc;
    		textcolor(14);
		cout << " ------------------------------------------ " << endl;
	cout << "  MENU PRINCIPAL  " << endl;
		textcolor(7);cout << " 1    Ordenar por nombres de la z a la a" << endl;
		textcolor(8);cout << " 2   Ordenar por fechanac descendente como anio, mes, dia" << endl;
		textcolor(11);cout << " 3  BUscar secuencialmente por nombre" << endl;
		textcolor(12);cout << " 4   Buscar binariamente por fechanac" << endl;
		textcolor(15);cout << " 5   SALIR" << endl;
	   cout << " " << endl;
		textcolor(4);cout << " INGRESAR OPCION:";
		textcolor(14);cin >> opc;
		textcolor(14);cout << " ------------------------------------------ " << endl;
	return opc;
}
/*

void buscarsecuencialmente(string apellido[], string nombre[], string ap, string nl, int np, int &telefonof) {
	int cont1a, cont1n, cont2a, cont2n, conta, contn, j, k, w, x;
	string letra1a[10];
	string letra1n[10];
	string letra2a[10];
	string letra2n[10];
	for (j=0;j<=ap.size()-1;j++) {
		letra1a[j] = ap.substr(j,j-j+1);
	}
	for (x=0;x<=nl.size()-1;x++) {
		letra1n[x] = nl.substr(x,x-x+1);
	}
	cont1a = j;
	cont1n = x;
	telefonof = -1;
	k = 0;
	do {
		cont2a = 0;
		cont2n = 0;
		for (x=0;x<=apellido[k].size()-1;x++) {
			letra2a[x] = apellido[k].substr(x,x-x+1);
		}
		cont2a = x;
		for (j=0;j<=nombre[k].size()-1;j++) {
			letra2n[j] = nombre[k].substr(j,j-j+1);
		}
		cont2n = j;
		if (cont1a==cont2a) {
			conta = 0;
			for (w=0;w<=cont1a-1;w++) {
				if (letra1a[w]==letra2a[w]) {
					conta = conta+1;
				}
			}
		}
		if (cont2n==cont1n) {
			contn = 0;
			for (w=0;w<=cont1n-1;w++) {
				if (letra1n[w]==letra2n[w]) {
					contn = contn+1;
				}
			}
		}
		if (contn==cont1n && cont2a==conta) {
			telefonof = k;
		}
		k = k+1;
	} while (!(telefonof!=-1 || k==np));
}

*/

void buscabinaria(int lst[], int ne, int val, int &pos, int &nc) {
	int centro, inf, sup;
	nc = 0;
	pos = -1;
	inf = 0;
	sup = ne-1;
	while (inf<=sup && pos<0) {
		centro = int((inf+sup)/2);
		if (lst[centro]==val) {
			pos = centro;
		} else {
			if (val>lst[centro]) {
				inf = centro+1;
			} else {
				sup = centro-1;
			}
		}
		nc = nc+1;
	}
}




