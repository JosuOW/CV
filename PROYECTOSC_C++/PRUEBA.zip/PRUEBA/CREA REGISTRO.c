/*CREAR REGISTRO BINARIO*/
#include<stdio.h>
#include <stdlib.h> 
#include<conio2.h>
 /* autor: Josune Singaña */
	/* fecha:05-09-2022 */
typedef struct Fechas{
	int mes;
	int dia;
	int anno;
} Fecha;

typedef struct Registros{
	char nombre[80];
	Fecha nac;
} Registro;

int existe(char *nombreFichero); 
void crearFichero(char *nombreFichero);
main(){
	textbackground(YELLOW);
	clrscr();
	textcolor(LIGHTRED);
	gotoxy (10,2);
	printf("PROGRAMA CREA UN ARCHIVO CON REGISTRO DE NOMBRE Y FECHA DE AL MENOS 10 USUARIOS");
		textcolor(MAGENTA);
	char nombreFichero[30]; // nombre del fichero 
 char resp = 's'; 
 // Solicitar el nombre del fichero 
 printf("\nNombre del fichero: "); 
 gets(nombreFichero); 

 // Verificar si el fichero existe 
 if (existe(nombreFichero)) 
 { 
 printf("\n El fichero existe ¿desea sobrescribirlo? (s/n) "); 
 resp = getchar(); 
 fflush(stdin); 
 } 
 if (resp == 's') 
 { 
 crearFichero(nombreFichero); 
 } 
} 
int existe(char *nombreFichero) 
{ 
 FILE *pf = NULL; 
 // Verificar si el fichero existe 
 int exis = 0; // no existe 
 if ((pf = fopen(nombreFichero, "r")) != NULL) 
 { 
 exis = 1; // existe 
 fclose(pf); 
 } 
 return exis; 
}
void crearFichero(char *nombreFichero) 
{ 
      	textcolor(CYAN);
	 FILE *pf = NULL; // identificador del fichero 
	Registro  reg; // definir un registro 
	 char resp; 
	 // Abrir el fichero nombreFichero para escribir "w" 
	 if ((pf = fopen(nombreFichero, "wb")) == NULL)  { 
		 printf("El fichero no puede abrirse."); 
		 exit(1); 
		 } 
	 // Leer datos de la entrada estándar y escribirlos 
	 // en el fichero 
	  int i=0;
	 do 
	 { 
	 printf("\nIngrese el nombre del usuario[%d]: ",i+1); gets(reg.nombre);
			fflush(stdin); 
		printf("\nIngrese la fecha de nacimiento (dia): ");	scanf("%d",&reg.nac.dia);
		printf("\nIngrese la fecha de nacimiento (mes): "); scanf("%d",&reg.nac.mes);
		printf("\nIngrese la fechade nacimiento (anno): ");	scanf("%d",&reg.nac.anno); 
	 fflush(stdin); 
	 fwrite(&reg, sizeof(reg), 1, pf); 
	 if (ferror(pf)) 
	 { 
	 perror("Error durante la escritura"); 
	 exit(2); 
	 } 
	 printf("¿desea escribir otro registro? (s/n) "); 
	 resp = getchar(); 
	 fflush(stdin); 
	 i++;
	 } 
 while (resp == 's'); 
} 
