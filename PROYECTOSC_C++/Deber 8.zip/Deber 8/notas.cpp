#include<stdio.h>
#include<conio2.h>
int main() {
	char estudiante[100][100], materias[5][100];
	int i, j, m, nume, numm, x, numd[3];
	float notafinale[30][5], notas[30][6][30][5], prom, suma;
	/* autor: Josune Singaña */
	/* fecha:07-08-2022 */
	char evaluacion[3][13]= { "DEBERES", "TRABAJOS", "PRUEBAS"}; 
	textbackground(14);
	clrscr();
	textcolor(0);gotoxy (25,2);printf("EJERCICIO CALCULO TOTAL DEL PROMEDIO DE NOTAS DE LOS ESTUDIANTE \n");
	do {
		textcolor(1);
	   gotoxy (15,4);printf("CUANTAS MATERIAS VA A INGRESAR (LIMITE 5): ");
	 gotoxy (58,4);	scanf("%i",&numm);
		if (numm>5) {
			textcolor(4);gotoxy (10,5);printf("<<<<<<<<<<<<SUPERA EL LIMITE DE MATERIAS. INTENTE DE NUEVO>>>>>>>>>>>\n");
		gotoxy (58,4);	printf("    ");
		}else{
			gotoxy (10,5);	printf("                                                                            \n");
		}
	} while (!(numm>0 && numm<=5));

	for (i=0;i<=numm-1;i+=1) {
			textcolor(8); gotoxy (16,i+5);printf("NOMBRE DE LA MATERIA [%i] : ",i+1);
		textcolor(5);scanf("%s",materias[i]);
	}
	for (i=0;i<=2;i+=1) {
		do {
				textcolor(12);printf("CUANTAS NOTAS VA A EVALUAR EN %s (LIMITE 5): ",evaluacion[i]);
			scanf("%i",&numd[i]);
			if (numd[i]>5) {
				textcolor(4);	printf("<<<<<<<<<<<<SUPERA EL LIMITE DE NOTAS A EVALUAR. INTENTE DE NUEVO>>>>>>>>>>>\n");
			}
		} while (!(numd[i]>0 && numd[i]<=5));
	}
		textcolor(1);printf("CUANTOS ESTUDIANTES VA A INGRESAR (LIMITE 30): ");
	scanf("%i",&nume);
	for (m=1;m<=nume;m+=1) {
		textcolor(5);	printf("NOMBRE DEL ESTUDIANTE [%i] A INGRESAR LAS NOTAS (para ingresar espacio utilice _ ) : ",m);
			textcolor(9); scanf("%s",estudiante[m-1]);
		for (i=0;i<=numm-1;i+=1) {
			textcolor(0);	printf("\n  [%s] \n",materias[i]);
			for (j=0;j<=2;j+=1) {
					textcolor(4); printf(" NOTAS [%s] : \n",evaluacion[j]);
				for (x=0;x<=numd[j]-1;x+=1) {
					textcolor(1);	printf("ESTUDIANTE [%i]  NOTA [%i] : ",(m),(x+1));
					textcolor(9);scanf("%f",&notas[m][i][j][x]);
				}
				suma = 0;
				for (x=0;x<=numd[j]-1;x+=1) {
					suma = notas[m][i][j][x]+suma;
				}
				prom = (suma)/numd[j];
				if (j==0) {
					notafinale[m][j] = prom*0.40;
				} else {
					notafinale[m][j] = prom*0.30;
				}
			}
			notas[m][5][m][i] = notafinale[m][0]+notafinale[m][1]+notafinale[m][2];
				clrscr();
		}
	}
	textcolor(0);printf("                     <<<<<<<<<<<<<<<<<<<<<<<<<<< MATERIAS >>>>>>>>>>>>>>>>>>>>>>>>> \n");
    printf("N | NOMBRE:         ");
	for (i=0;i<=numm-1;i++) {
		printf("|  %s",materias[i]);
		printf(" ");
	}
	printf(" \n");
	for (i=0;i<=nume-1;i++) {
	  textcolor(0);  printf("%i|",i+1);
	textcolor(1);	printf("%s",estudiante[i]);
		for (j=0;j<=numm-1;j++) {
	textcolor(1);	printf("    |  %.2f",notas[i+1][5][i+1][j]);
		}
		printf(" \n");
	}
	getch();
	return 0;
}
