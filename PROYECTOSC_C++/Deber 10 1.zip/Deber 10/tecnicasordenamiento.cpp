#include<iostream>
#include<cmath>
#include<cstdlib>
#include<conio2.h>
using namespace std;
#define ARREGLO_MAX 100
#define SIN_TIPO string
void ordenintercambio(int vector[], int ne, int &niter);
void ordenseleccion(int vector[], int ne, int &niter);
void ordenburbuja(int vector[], int ne, int &niter);
void ordeninsercion(int v[], int n, int &niter);
void ordenshell(int v[], int n, int &nshell);
void ordenquicksort(int v[], int inf, int sup, int &nquick);
void ordenfusionar(int a[], int b[], int v[], int m, int ns, int &nifu);
void llenarvector(int vector[], int ne);
void igualarvector(int vect1[], int vect2[], int ne);
void escribirvector(int vect[], int ne, char titulo[]);
int menu();

void ordenintercambio(int vector[], int ne, int &niter) {
	int aux, i, j;
	niter = 0;
	// ciclo va haste el penultimo elemento
	for (i=0;i<=ne-2;i++) {
		for (j=i+1;j<=ne-1;j++) {
			// para orden ascendente > para orden descendente <
			if (vector[i]>vector[j]) {
				aux = vector[i];
				vector[i] = vector[j];
				vector[j] = aux;
				niter = niter+1;
			}
		}
	}
}

void ordenseleccion(int vector[], int ne, int &niter) {
	int aux, i, j, pos;
	niter = 0;
	// ciclo va haste el penultimo elemento
	for (i=0;i<=ne-2;i++) {
		pos = i;
		for (j=i+1;j<=ne-1;j++) {
			// para orden ascendente > para orden descendente <
			if (vector[pos]>vector[j]) {
				pos = j;
			}
		}
		aux = vector[i];
		vector[i] = vector[pos];
		vector[pos] = aux;
		niter = niter+1;
	}
}

void ordenburbuja(int vector[], int ne, int &niter) {
	int aux, i, j;
	bool cambio;
	niter = 0;
	i = 1;
	cambio = true;
	// ciclo va haste el penultimo elemento
	while (i<ne-1 && cambio==true) {
		cambio = false;
		for (j=0;j<=ne-i-1;j++) {
			// para orden ascendente > para orden descendente <
			if (vector[j]>vector[j+1]) {
				aux = vector[j];
				vector[j] = vector[j+1];
				vector[j+1] = aux;
				cambio = true;
				niter = niter+1;
			}
		}
		i = i+1;
	}
}

void ordeninsercion(int v[], int n, int &niter) {
	int aux, i, j;
	niter = 0;
	for (i=1;i<=n-1;i++) {
		j = i-1;
		aux = v[i];
		while (j>=0 && v[j]>aux) {
			v[j+1] = v[j];
			j = j-1;
			niter = niter+1;
		}
		v[j+1] = aux;
	}
}

void ordenshell(int v[], int n, int &nshell) {
	int aux, i, j, salto;
	bool seguir;
	nshell = 0;
	salto = int(n/2);
	while (salto>0) {
		for (j=(salto);j<=n-1;j++) {
			i = j-salto;
			aux = v[j];
			seguir = true;
			while (i>=0 && seguir==true) {
				if (aux<v[i]) {
					v[i+salto] = v[i];
					i = i-salto;
					nshell = nshell+1;
				} else {
					seguir = false;
				}
			}
			v[i+salto] = aux;
		}
		salto = int(salto/2);
	}
}

void ordenquicksort(int v[], int inf, int sup, int &nquick) {
	int aux, m, n, pivote;
	m = inf;
	n = sup;
	pivote = int((v[m]+v[n])/2);
	while (m<n) {
		while (v[m]<pivote) {
			m = m+1;
		}
		while (v[n]>pivote) {
			n = n-1;
		}
		if (m<=n) {
			aux = v[m];
			v[m] = v[n];
			v[n] = aux;
			m = m+1;
			n = n-1;
			nquick = nquick+1;
		}
	}
	if (inf<n) {
		ordenquicksort(v,inf,n,nquick);
	}
	if (sup>m) {
		ordenquicksort(v,m,sup,nquick);
	}
}

void ordenfusionar(int a[], int b[], int v[], int m, int ns, int &nifu) {
	int i = 0;
	int j = 0;
	int k = 0;
	int x = 0;
	while (i<=m-1 && j<=ns-1) {
		if (a[i]<=b[j]) {
			v[k] = a[i];
			i = i+1;
		} else {
			v[k] = b[j];
			j = j+1;
			nifu = nifu+1;
		}
		k = k+1;
	}
	if (i<=m-1) {
		for (x=i;x<=m-1;x++) {
			v[k] = a[x];
			k = k+1;
			nifu = nifu+1;
		}
	}
	if (j<=ns) {
		for (x=j;x<=ns-1;x++) {
			v[k] = b[x];
			k = k+1;
			nifu = nifu+1;
		}
	}
}

void llenarvector(int vector[], int ne) {
	int i;
	for (i=0;i<=ne-1;i++) {
		vector[i] = (rand()%100)+1;
	}
}

void igualarvector(int vect1[], int vect2[], int ne) {
	int i;
	for (i=0;i<=ne-1;i++) {
		vect2[i] = vect1[i];
	}
}

void escribirvector(int vect[], int ne, char titulo[]) {
	int i;
	cout << " " << titulo << ": { ";
	for (i=0;i<=ne-1;i++) {
		cout << vect[i] << " ";
	}
	cout << " }" << endl;
}

int menu() {
	int opc;
		textcolor(14);
	cout << " ------------------------------------------ " << endl;
	cout << "  MENU PRINCIPAL TECNICAS DE ORDENAMIENTO " << endl;
		textcolor(7);cout << " 1   INTERCAMBIO" << endl;
		textcolor(8);cout << " 2   SELECCION" << endl;
		textcolor(11);cout << " 3   BURBUJA" << endl;
		textcolor(12);cout << " 4   INSERCION" << endl;
		textcolor(13);cout << " 5   SHELL" << endl;
		textcolor(5);cout << " 6   QUICK SORT" << endl;
		textcolor(1);cout << " 7   FUSION" << endl;
		textcolor(15);cout << " 8   SALIR" << endl;
	   cout << " " << endl;
		textcolor(4);cout << " INGRESAR OPCION:";
		textcolor(14);cin >> opc;
		textcolor(14);cout << " ------------------------------------------ " << endl;
	return opc;
}

int main() {
		textbackground(3);
	clrscr();
	textcolor(14);
	int dim, i, lim, mitad, ni, opc;
	int v2[ARREGLO_MAX];
	int v3[ARREGLO_MAX];
	// autor= Singaña Josune
	// fecha= 15-agosto-2022
	opc = 0;
	 gotoxy (30,2);	cout << "ALGORITMOS DE ORDENAMIENTO " << endl;
		textcolor(0);
	   gotoxy (15,4);cout << "CUANTOS DATOS DESEA ORDENAS: ";
	cin >> lim;
	ni = 0;
		int listades[lim];
	int listaord[lim];
	llenarvector(listades,lim);
	do {
		ni = 0;
			textcolor(15);
		escribirvector(listades,lim,"VECTOR DATOS DESORDENADOS ");
		igualarvector(listades,listaord, lim);
		opc = menu();
		switch (opc) {
		case 1:
			textcolor(7);
			ordenintercambio(listaord,lim,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR INTERCAMBIO");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 2:
			textcolor(8);
			ordenseleccion(listaord,lim,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR SELECCION");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 3:
			textcolor(11);
			ordenburbuja(listaord,lim,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR BURBUJA");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 4:
			textcolor(12);
			ordeninsercion(listaord,lim,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR INSERCION");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 5:
			textcolor(13);
			ordenshell(listaord,lim,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR SHELL");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 6:
			textcolor(5);
			ordenquicksort(listaord,0,lim-1,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR QUICK SORT");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 7:
			textcolor(1);
			mitad = int(lim/2);
			for (i=0;i<=mitad-1;i++) {
				v2[i] = listaord[i];
			}
			dim = lim-mitad;
			for (i=0;i<=dim-1;i++) {
				v3[i] = listaord[i+mitad];
			}
			ordenseleccion(v2,mitad,ni);
			ordenseleccion(v3,dim,ni);
			ordenfusionar(v2,v3,listaord,mitad,dim,ni);
			escribirvector(listaord,lim,"VECTOR DATOS ORDENADOS POR FUSION");
			cout << "NUMERO DE INTERCAMBIOS: " << ni << endl;
			break;
		case 8:
				textcolor(5);
			cout << ">>>>>>>>>> GRACIAS POR USAR ESTA APLICACION <<<<<<<<<<<<<<<" << endl;
			break;
		}
		if (opc<8) {
				textcolor(15);
			cout << "<<<<<<<<< PRESIONA CUALQUIER TECLA PARA CONTINUAR >>>>>>>>>>>>>>>" << endl;
		getch();
			clrscr();
		}
	} while (opc<8);
	return 0;
}

