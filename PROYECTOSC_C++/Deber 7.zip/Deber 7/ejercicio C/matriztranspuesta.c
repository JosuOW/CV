
#include<stdio.h>
#include<stdlib.h>
#include<conio2.h>
/* autor: Josune Singaña */
/* fecha:31-07-2022 */
int main() {
	int dim, i,  j, mat[100][100];
		textbackground(0);
	clrscr();
	textcolor(14);
	 gotoxy (25,2);printf(" APLICACION GENERA LA MATRIZ TRANSPUESTA DE UNA MATRIZ CUADRADA\n");
	 	textcolor(10);
	gotoxy (15,5);printf("INGRESE LA DIMENSION DE LA MATRIZ: ");
	scanf("%i",&dim);
	for (i=1;i<=dim;i+=1) {
		for (j=1;j<=dim;j+=1) {
			mat[i][j] = (rand()%9)+1;
		}
	}	textcolor(9);
     printf("MATRIZ GENERADA ES: \n");
	for (i=1;i<=dim;i+=1) {
		printf("| ");
		for (j=1;j<=dim;j+=1) {
			printf("%i ",mat[i][j]);
		}
		printf(" |\n");
	}
	printf("\n");
		textcolor(11);
	printf(" MATRIZ TRANSPUESTA\n");
	for (j=1;j<=dim;j+=1) {
		printf("| ");
		for (i=1;i<=dim;i+=1) {
			printf("%i ",mat[i][j]);
		}
		printf(" |\n");
	}
		getch();
	return 0;
}
