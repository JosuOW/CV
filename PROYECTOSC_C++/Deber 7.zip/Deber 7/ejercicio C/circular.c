#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<conio2.h>
int main() {
	int lim,n, numelem;
	char lista[15][10];
	char resp, temp[15];
	/* autor: Josune Singaña */
	/* fecha:01-08-2022 */
	textbackground(7);
	clrscr();
	textcolor(5);
	   gotoxy (25,2);printf("ALGORITMO REALIZA UN DESPLAZAMIENTO CIRCULAR\n");
	lim = 10;
	for (n=0;n<lim;n++) {
		strcpy( lista[n], "");
	}
		textcolor(1);
	gotoxy (15,4); printf("INGRESE EL NUMERO DE ELEMENTOS DE LA LISTA: ");
	scanf("%i",&numelem);
		textcolor(3);
	for (n=0;n<numelem;n++) {
		printf("INGRESA NOMBRE %i  :",n+1);
		scanf("%s",lista[n]);
	}
	resp = 's';
	while (tolower(resp)=='s') {
		strcpy(temp,lista[lim-1]);
		for (n=lim-2;n>=0;n--) {
			strcpy( temp , lista[lim-1]);
			for (n=lim-2;n>=0;n--) {
			strcpy(	lista[n+1],lista[n]);
			}
		}
		strcpy(	lista[0],temp);
			textcolor(12);
		printf("\n LISTA CIRCULAS ES: \n");
		for (n=0;n<lim;n++) {
			printf("%s  ",lista[n]);
		}
		printf(" \n");
			textcolor(2);
		printf(" Realizar otro recorrido s/n");
		resp=getch();
	}
	getch();
	return 0;
}








