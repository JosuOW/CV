#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio2.h>

void arreglo2(int vec1, int vec2);
void resultados(int vec1, int vector1[], int vec2, int vector2[], int num[]);
void arreglo1(int vec1, int vec2);
/* autor: Josune Singaña */
/* fecha:31-07-2022 */
int main() {
	char resp;
	int vec1, vec2;
	textbackground(YELLOW);
	clrscr();
	textcolor(MAGENTA);
	   gotoxy (25,2);printf(" APLICACION COMPARA LOS ELEMENTOS DE DOS VECTORES \n");
	   	textcolor(CYAN);
		gotoxy (15,4);printf("INGRESE EL NUMERO DE ELEMENTOS DEL PRIMER VECTOR: ");
	scanf("%i",&vec1);
		gotoxy (15,5);printf("INGRESE EL NUMERO DE ELEMENTOS DEL SEGUNDO VECTOR: ");
	scanf("%i",&vec2);
	textcolor(BLUE);
		gotoxy (15,7);printf("DESEA QUE LOS ELEMENTOS SE GENEREN ALEATORIAMENTE DEL 1 AL 10: s o n ");
	resp = getch();
	if  (resp=='s' || resp=='S')  {
		if (vec1<=vec2) {
			arreglo1(vec1,vec2);
		} else {
			arreglo1(vec2,vec1);
		}
	} else {
		if (vec1<=vec2) {
			arreglo2(vec1,vec2);
		} else {
			arreglo2(vec2,vec1);
		}
	}
	getch();
	return 0;
}

void arreglo2(int vec1, int vec2) {
		textcolor(6);
	int i, j, x, n, num[100], vector1[100], vector2[100];
		for (n=1;n<100;n++) {
		num[n]=0;
	}gotoxy (1,9);
	for (x=1;x<=vec1;x++) {
		printf("Ingrese el elemento [%i] del primer vector: ",x);
		scanf("%i",&vector1[x]);
		j = vector1[x];
	}
	for (i=1;i<=vec2;i++) {
		printf("Ingrese el elemento [%i] del segundo vector: ",i);
		scanf("%i",&vector2[i]);
	}
	for (x=1;x<=vec1;x++) {
		j = vector1[x];
		for (i=1;i<=vec2;i++) {
			if (j==vector2[i]) {
				num[x] = j;
			}
		}
	}
	resultados(vec1,vector1,vec2,vector2,num);
}

void resultados(int vec1, int vector1[], int vec2, int vector2[], int num[]) {
int i;
	textcolor(8);
	printf("\n El PRIMER VECTOR ES: { ");
	for (i=1;i<=vec1;i++) {
		printf("%i ",vector1[i]);
	}
	printf(" }\n");
	printf("El SEGUNDO VECTOR ES: { ");
	for (i=1;i<=vec2;i++) {
		printf("%i ",vector2[i]);
	}
	printf(" }\n");
	printf("LOS VALORES QUE SE REPITEN SON: { ");
	for (i=1;i<=vec1;i++) {
		if (num[i]!=0) {
			printf("%i ",num[i]);
		}
		printf(" ");
	}
	printf(" }\n");
}

void arreglo1(int vec1, int vec2) {
	int i, j, x, t, n, num[100];  
	 int vector1[100], vector2[100];
	for (n=1;n<100;n++) {
		num[n]=0;
	}
	for (x=1;x<=vec1;x++) {
		vector1[x] = (rand()%10)+1;
		j = vector1[x];
	}
	for (t=1;t<=vec2;t++) {
		vector2[t] = (rand()%10)+1;
	}
	for (x=1;x<=vec1;x++) {
		j = vector1[x];
		for (i=1;i<=vec2;i++) {
			if (j==vector2[i]) {
				num[x] = j;
			}
		}
	}
	resultados(vec1,vector1,vec2,vector2,num);
}


