#include<stdio.h>
#include<stdlib.h>
#include<conio2.h>
/* autor: Josune Singaña */
/* fecha:31-07-2022 */
int main() {
	int dim, h, i, j, mat[100][100], mat2[100][100], num[100], p, x;
		textbackground(1);
	clrscr();
	textcolor(15);
	 gotoxy (25,2);printf(" APLICACION DETERMINA SI DOS MATRICES CONTIENEN LOS MISMOS ELEMENTOS\n");
	textcolor(11);
	 gotoxy (15,4);printf("INGRESE LA DIMENSION DE LAS MATRICES: ");
	scanf("%i",&dim);
	for (i=1;i<=dim;i+=1) {
		for (j=1;j<=dim;j++) {
			mat[i][j] = (rand()%9)+1;
		}
	}
		textcolor(7);
	printf("MATRIZ 1 GENERADA ES: \n");
	for (i=1;i<=dim;i++) {
		printf("| ");
		for (j=1;j<=dim;j++) {
			printf("%i ",mat[i][j]);
		}
		printf(" |\n");
	}
	for (i=1;i<=dim;i++) {
		for (j=1;j<=dim;j++) {
			mat2[i][j] = (rand()%9)+1;
		}
	}
		textcolor(14);
	printf("MATRIZ 2 GENERADA ES: \n");
	for (i=1;i<=dim;i++) {
		printf("| ");
		for (j=1;j<=dim;j++) {
			printf("%i ",mat2[i][j]);
		}
		printf(" |\n");
	}
	for (x=1;x<=dim;x++) {
		for (p=1;p<=dim;p++) {
			h = mat[x][p];
			for (i=1;i<=dim;i++) {
				for (j=1;j<=dim;j++) {
					if (h==mat2[j][i]) {
						num[x] = h;
					}
				}
			}
		}
	}
	p=dim*dim;
		textcolor(15);
	printf("LOS ELEMENTOS SIMILARES SON: { ");
	for (i=1;i<=p;i++) {
		if (num[i]!=0) {
			printf("%i ",num[i]);
		}
	}
	printf(" }\n");
	getch();
	return 0;
}

