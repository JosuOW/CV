#include<stdio.h>
#include<conio2.h>
int main() {
	float costkwh;
	int i, lecact[10], lecant[10],  numus;
	char lstusuarios[40][40];
	/* autor: Josune Singaña */
	/* fecha:01-08-2022 */
	costkwh = 0.23;
		textbackground(14);
	clrscr();
	textcolor(12);
	   gotoxy (25,2);printf("EJERCICIO CALCULO TOTAL A PAGAR SERVICIO ELECTRICO\n");
textcolor(1);
	   gotoxy (15,4);	printf("CUANTOS USUARIOS VA A FACTURAR: ");
	scanf("%i",&numus);
	for (i=1;i<=numus;i++) {
	lecant[i]=0;
	lecact[i]=0;
	}
	textcolor(0);
	for (i=1;i<=numus;i++) {
		printf("\nNOMBRE DE USUARIO %i : ",i);
		scanf("%s",lstusuarios[i]);
		printf("VALOR LECTURA ANTERIOR %i : ",i);
		scanf("%i",&lecant[i]);
		printf("VALOR LECTURA ACTUAL%i : ",i);
		scanf("%i",&lecact[i]);
	}
	/* CALCULO CONSUMO Y VALOR A PAGAR */
	textcolor(4);
	for (i=1;i<=numus;i++) {
		printf("\nNOMBRE DE USUARIO: %s\n",lstusuarios[i]);
		printf("VALOR DEL CONSUMO EN KWH: %i\n",lecact[i]-lecant[i]);
		printf("VALOR A PAGAR: %.2f\n",(lecact[i]-lecant[i])*costkwh);
	}
	getch();
	return 0;
}

