#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio2.h>
/* autor: Josune Singaña */
/* fecha:31-07-2022 */
int main() {
	int i, j, num, resul[10], vector[10];
	char resp;
		textbackground(4);
	clrscr();
	textcolor(14);
	 gotoxy (25,2);printf(" APLICACION CALCULA EL PRODUCTO DE UN NUMERO POR UN VECTOR \n");
	 textcolor(7);
	 gotoxy (15,4);printf("INGRESE EL NUMERO QUE DESEA MULTIPLICAR: ");
	scanf("%i",&num);
	textcolor(11);
	 gotoxy (15,6);printf("DESEA QUE LOS ELEMENTOS SE GENEREN ALEATORIAMENTE DEL 1 AL 10: s o n ");
	resp = getch();
	if  (resp=='s' || resp=='S') {
		for (i=0;i<=9;i++) {
			vector[i] = (rand()%10)+1;
			j = vector[i];
			resul[i] = num*j;
		}
	} else {
		for (i=0;i<=9;i++) {
			textcolor(14);
			printf("\n Ingrese el elemento [%i] del primer vector: ",i+1);
			scanf("%i",&vector[i]);
			j = vector[i];
			resul[i] = num*j;
		
		}
	}
		textcolor(15);
	printf("\n\n      El VECTOR A SER MULTIPLICADO ES: { ");
	for (i=0;i<=9;i++) {
		printf("%i ",vector[i]);
	}
	printf(" }\n");
	printf("\n     El VECTOR RESULTANTE DEL PRODUCTO ES: { ");
	for (i=0;i<=9;i++) {
		printf("%i ",resul[i]);
	}
	printf(" }\n");
		getch();
	return 0;
}


