#include<stdio.h>
#include<stdlib.h>
#include<conio2.h>
void generarmatriz(int nf, int nc, int m[10][10]);
void productomatriz(int nf1, int nc1, int m1[10][10], int nf2, int nc2, int m2[10][10], int *nfr, int *ncr, int mr[20][20]);
void escribirmatriz(int nf, int nc, int m[10][10], char nommat);

void generarmatriz(int nf, int nc, int m[10][10]) {
	int i, j;
	for (i=0;i<=nf-1;i++) {
		for (j=0;j<=nc-1;j++) {
			m[i][j] = (rand()%9)+1;
		}
  	}
}

void productomatriz(int nf1, int nc1, int m1[10][10], int nf2, int nc2, int m2[10][10], int *nfr, int *ncr, int mr[20][20]) {
	int i, j, k;
	if (nf1==nc2) {
		(*nfr) = nf1;
		(*ncr) = nc2;
		for (i=0;i<=(*nfr)-1;i+=1) {
			for (j=0;j<=(*ncr)-1;j+=1) {
				mr[i][j] = 0;
				for (k=0;k<=nc1-1;k+=1) {
					mr[i][j] = mr[i][j]+m1[i][k]*m2[k][j];
				}
			}
		}
	} else {
		printf("******MULTIPLICACIÓN MATRICIAL NO DEFINIDA*****\n");
	}
}
void escribirmatriz(int nf, int nc, int m[10][10], char nommat) {
	int i, j;
	printf("MATRIZ: %i\n",nommat);
	for (i=0;i<=nf-1;i+=1) {
		printf("| ");
		for (j=0;j<=nc-1;j+=1) {
			printf("%i ",m[i][j]);
		}
		printf("| \n");
	}
}
	

int main() {
	int i, j, k, nca, ncb, ncc, nfa, nfb, nfc;
	int ma[10][10], mb[10][10], mc[20][20];
	/* autor: Josune Singaña */
	/* fecha:01-08-2022 */
		textbackground(0);
	clrscr();
	textcolor(12);
	 gotoxy (25,2);printf("ALGORITMO MULTIPLICACION DE MATRICES \n");
	 textcolor(14);
      printf("NUMERO DE FILAS MATRIZ A: ");
     scanf("%i",&nfa);
	printf("NUMERO DE COLUMNAS MATRIZ A: ");
	scanf("%i",&nca);
	generarmatriz(nfa,nca,ma);
	escribirmatriz(nfa,nca,ma,"MATRIZ A");
		textcolor(11);
	 printf("NUMERO DE FILAS MATRIZ B: ");
	scanf("%i",&nfb);
	 printf("NUMERO DE COLUMNAS MATRIZ B: ");
	scanf("%i",&ncb);
	generarmatriz(nfb,ncb,mb);
	escribirmatriz(nfb,ncb,mb,"MATRIZ B");
	productomatriz(nfa,nca,ma,nfb,ncb,mb,nfc,ncc,mc);
	escribirmatriz(nfc,ncc,mc,"MATRIZ PRODUCTO");
   getch();
	return 0;
}
