#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<conio2.h>
/* autor: Josune Singaña */
/* fecha:31-07-2022 */
int main() {
	int dim, i, j,x, n;
	char vector[20][40],  ultimo[20];
		textbackground(MAGENTA);
	clrscr();
	textcolor(14);
	   gotoxy (25,2);	printf(" APLICACION PERMITE INSERTAR UN DATO EN UNA POSICION DEL VECTOR DESEADO\n");
		textcolor(7);
	gotoxy (15,4);printf("INGRESE EL NUMERO DE ELEMENTOS DEL VECTOR: ");
	scanf("%i",&dim);
		for (n=0;n<=dim;n++) {
		strcpy( vector[n], "");
	}
	textcolor(11);
	printf("\n ");
	for (j=1;j<=dim;j++) {
		printf("INGRESE LA POSICION DEL DATO [ %i ]: ",j);
		scanf("%i",&i);
		while (i>dim) {
			printf("INGRESE DE NUEVO LA POSICION DEL DATO  [ %i ]: ",j);
			scanf("%i",&i);
		}
			strcpy(ultimo, vector[dim-1]);
		if (i==x) {
			for (n=dim-2;n>=0;n--) {
				strcpy( ultimo , vector[dim]);
				for (n=dim-1;n>=0;n--) {
					strcpy(	vector[n+1],vector[n]);
				}
			}
				strcpy(	vector[0], ultimo);
		
		}
		printf("INGRESE EL DATO [ %i ]: ",j);
		scanf("%s",vector[i]);
		x = i;
	}
	textcolor(14);
	printf("<<<<<<<<<< NO SE ACEPTAN MAS DATOS VECTOR LLENO >>>>>>>>>>>>>>>\n");
	textcolor(11);
	printf("El VECTOR ES: { ");
	for (i=0;i<=dim;i++) {
		printf("%s ",vector[i]);
	}
	printf(" }\n");
	getch();
	return 0;
}

