#include<conio2.h>
#include<stdio.h>
/* autor: Josune Singaña */
/* fecha:31-07-2022 */
int main() {
	int dim, ele, h, i, j, mat[100][100], tele;
	ele=0;
	textbackground(3);
	clrscr();
	textcolor(1);
	 gotoxy (25,2);printf(" APLICACION DETERMINA SI UNA MATRIZ CUADRADA ES SIMETRICA\n");
	textcolor(5);
	 gotoxy (15,4);printf("INGRESE LA DIMENSION DE LA MATRIZ: ");
	scanf("%i",&dim);
	tele = dim*dim;
	textcolor(7);
	for (i=1;i<=dim;i+=1) {
		for (j=1;j<=dim;j+=1) {
			printf("Ingrese el elemento [%i%i]:",i,j);
			scanf("%i",&mat[i][j]);
		}
	}
	textcolor(12);
	printf("MATRIZ GENERADA ES: \n");
	for (i=1;i<=dim;i+=1) {
		printf("| ");
		for (j=1;j<=dim;j+=1) {
			printf("%i ",mat[i][j]);
		}
		printf(" |\n");
	}
	printf("\n");
	textcolor(13);
	printf(" MATRIZ TRANSPUESTA\n");
	for (j=1;j<=dim;j+=1) {
		printf("| ");
		for (i=1;i<=dim;i+=1) {
			printf("%i ",mat[i][j]);
		}
		printf(" |\n");
	}
	for (i=1;i<=dim;i+=1) {
		for (j=1;j<=dim;j+=1) {
			h = mat[i][j];
			if (h==mat[j][i]) {
				ele = ele+1;
			}
		}
	}
	textcolor(1);
	if (ele==tele) {
		printf(" LA MATRIZ ES SIMETRICA \n");
	} else {
		printf(" LA MATRIZ NO ES SIMETRICA \n");
	}
	getch();
	return 0;
}


