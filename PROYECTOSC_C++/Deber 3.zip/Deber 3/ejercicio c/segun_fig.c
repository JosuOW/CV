#include<stdio.h>
#include<math.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	  textbackground(CYAN);
   clrscr();
	float a, area, b, d1, d2, h, pi, r;
	int opc;
		 textcolor(BLUE);
     gotoxy (15,2);
	printf(" APLICACION CALCULA AREA DE LAS PRINCIPALES FIGURAS GEOMETRICAS 2D \n");
	textcolor( MAGENTA);
    gotoxy (30,3);
	printf(" 1   Triangulo\n");
	gotoxy (30,4);
	printf(" 2   Rectangulo\n");
	gotoxy (30,5);
	printf(" 3   Circulo\n");
	gotoxy (30,6);
	printf(" 4   Rombo\n");
	gotoxy (30,7);
	printf(" 5   Trapecio\n");
	gotoxy (30,8);
	printf(" 6   Salir\n");
	textcolor(LIGHTMAGENTA);
	gotoxy (20,9);
	printf(" Ingresar Opcion:");
	scanf("%i",&opc);
	switch (opc) {
	case 1:
			textcolor(YELLOW);
    gotoxy (30,10);
		printf("  CALCULO AREA DE UN TRIANGULO\n");
		printf("  INGRESAR EL VALOR DE LA BASE:\n");
		scanf("%f",&b);
		printf("  INGRESAR EL VALOR DE LA ALTURA:\n");
		scanf("%f",&h);
		area = (b*h)/2;
		break;
	case 2:
		printf("   CALCULO AREA DE UN RECTANGULO\n");
		printf("  INGRESAR EL VALOR DE LA BASE:\n");
		scanf("%f",&b);
		printf("  INGRESAR EL VALOR DE LA ALTURA:\n");
		scanf("%f",&h);
		area = b*h;
		break;
	case 3:
		printf("   CALCULO AREA DE UN CIRCULO\n");
		printf("  INGRESAR EL RADIO:\n");
		scanf("%f",&r);
		area = M_PI*pow(r,2);
		break;
	case 4:
		printf("   CALCULO AREA DE UN ROMBO\n");
		printf("  INGRESAR LA DIAGONAL MAYOR:\n");
		scanf("%f",&d1);
		printf("  INGRESAR LA DIAGONAL MENOR:\n");
		scanf("%f",&d2);
		area = (d1*d2)/2;
		break;
	case 5:
		printf("   CALCULO AREA DE UN TRAPECIO\n");
		printf("  INGRESAR EL VALOR DE LA BASE MENOR:\n");
		scanf("%f",&b);
		printf("  INGRESAR EL VALOR DE LA BASE MAYOR:\n");
		scanf("%f",&a);
		printf("  INGRESAR EL VALOR DE LA ALTURA:\n");
		scanf("%f",&h);
		area = h*((a+b)/2);
		break;
	case 6:
		printf(" GRACIAS POR USAR EL PROGRAMA\n");
		break;
	default:
		printf("   OPCION NO VALIDA INTENTE DE NUEVO\n");
	}
	printf(" EL AREA DE LA FIGURA ES: %f\n",area);
	printf(" GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

