#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(BROWN);
    clrscr();
	float c, d,tp;
     textcolor(RED);
     gotoxy (25,2);
	printf("ALGORITMO QUE CALCULA EL VALOR A PAGAR CON DESCUENTO \n");
	 textcolor(RED);
     gotoxy (10,3);
	printf("INGRESA EL VALOR DE LA COMPRA: ");
	scanf("%f",&c);
	if (c>1000000) {
		d = c*0.08;
	} else {
		if (c>=500000) {
			d = c*0.05;
		} else {
				 textcolor(BLUE);
                 gotoxy (15,5);
			printf("NO TIENE DESCUENTO \n");
			d = 0;
		}
	}
	tp = c-d;
		 textcolor(GREEN);
     gotoxy (15,6);
	printf("EL VALOR DE SU DESCUENTO ES:%.2f\n",d);
		 textcolor(BLACK);
     gotoxy (16,7);
	printf("EL VALOR A PAGAR CON DECUENTO ES:%.2f\n",tp);
		 textcolor(LIGHTMAGENTA);
     gotoxy (17,8);
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

