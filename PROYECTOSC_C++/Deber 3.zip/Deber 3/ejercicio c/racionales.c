#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(BLACK);
    clrscr();
	int a, b, d, e;
	float div1, div2;
     textcolor(CYAN);
     gotoxy (15,2);
	printf("ALGORITMO QUE DETERMINA SI 2 NUMEROS SON EQUIVALENTES Y SI NO, CUAL ES MAYOR \n");
     textcolor(LIGHTGREEN);
     gotoxy (5,3);
	printf("EL PRIMER NUMERO RACIONAL ES a/b \n");
	textcolor(MAGENTA);
     gotoxy (5,4);
	printf("INGRESA EL VALOR ENTERO DE a: ");
	scanf("%i",&a);
	printf("INGRESA EL VALOR ENTERO DE b: ");
	scanf("%i",&b);
	textcolor(LIGHTCYAN);
	printf("EL SEGUNDO NUMERO RACIONAL ES d/e \n");
	printf("INGRESA EL VALOR ENTERO DE d: ");
	scanf("%i",&d);
	printf("INGRESA EL VALOR ENTERO DE e: ");
	scanf("%i",&e);
	div1 = a/b;
	div2 = d/e;
	if (div1==div2) {
		printf("SON EQUIVALENTES\n");
		printf("EL VALOR ES: %f\n",div1);
	} else {
		printf("NO SON EQUIVALENTES\n");
		if (div1>div2) {
			textcolor(YELLOW);
			printf("EL PRIMER NUMERO RACIONAL a/b: %f.2 ES MAYOR QUE EL SEGUNDO NUMERO RACIONAL d/e: %f.2\n",div1,div2);
		} else {
			printf("EL SEGUNDO NUMERO RACIONAL d/e: %f.2 ES MAYOR QUE EL PRIMER NUMERO RACIONAL a/b: %f.2\n",div2,div1);
		}
	}
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

