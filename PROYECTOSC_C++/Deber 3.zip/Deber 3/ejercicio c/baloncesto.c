#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
textbackground(LIGHTGRAY);
clrscr();
	float e;
	int r;
  textcolor(CYAN);
  gotoxy (25,2);
	printf("ALGORITMO QUE INDICA SI PUEDE SER PARTE DE LA SELECCION DE BALONCESTO ");
	/* Entrada de datos */
	textcolor( LIGHTGREEN);
  gotoxy (30,4);
	printf("INGRESA SI=1 O NO=0. ES UN BUEN JUGADOR DE BALONCESTO\? ");
	scanf("%i",&r);
	if (r==1) {
		textcolor( DARKGRAY );
         gotoxy (30,6);
		printf("POR FAVOR, INGRESE SU ALTURA EN METROS: ");
		scanf("%f",&e);
		if (e>=1.70) {
			textcolor( BLUE );
         gotoxy (33,8);
			printf("FELICIDADES, ES APTO. \n");
		} else {
				textcolor( BLUE );
             gotoxy (33,8);
			printf("NO ES APTO ");
		}
	} else {
		textcolor( BLUE );
         gotoxy (32,6);
		printf("NO PUEDE INGRESAR AL EQUIPO");
	}
	textcolor( BLUE );
         gotoxy (35,10);
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

