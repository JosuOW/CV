#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	   textbackground(BLUE);
   clrscr();
	float num1,  num2, num3;
	 textcolor(LIGHTGRAY);
  gotoxy (25,2);
	printf("ALGORITMO QUE ORDENA 3 NUMEROS DE FORMA ASCENDENTE \n");
	textcolor( YELLOW);
  gotoxy (30,4);
	printf("INGRESA EL VALOR DEL PRIMER NUMERO: ");
	scanf("%f",&num1);
		textcolor( LIGHTCYAN);
		gotoxy (30,5);
	printf("INGRESA EL VALOR DEL SEGUNDO NUMERO: ");
	scanf("%f",&num2);
		textcolor( LIGHTBLUE);
		gotoxy (30,6);
	printf("INGRESA EL VALOR DEL TERCER NUMERO: ");
	scanf("%f",&num3);
		textcolor( WHITE);
		gotoxy (35,8);
	if (num1>num2) {
		if (num2>num3) {
			printf("EL ORDEN ES:%.2f < %.2f < %.2f\n",num3,num2,num1);
		} else {
			if (num2==num3) {
				printf("EL ORDEN ES:%.2f = %.2f < %.2f\n",num2,num3,num1);
			} else {
				if (num1>num3) {
					printf("EL ORDEN ES:%.2f < %.2f < %.2f\n",num2,num3,num1);
				} else {
					if (num1==num3) {
						printf("EL ORDEN ES:%.2f < %f = %.2f\n",num2,num3,num1);
					} else {
						printf("EL ORDEN ES:%.2f < %.2f < %.2f\n",num2,num1,num3);
					}
				}
			}
		}
	} else {
		if (num1==num2) {
			if (num2>num3) {
				printf("EL ORDEN ES:%.2f < %.2f = %.2f\n",num3,num2,num1);
			} else {
				if (num2==num3) {
					printf("EL ORDEN ES:%.2f = %.2f = %.2f\n",num2,num3,num1);
				} else {
					printf("EL ORDEN ES:%.2f = %.2f < %.2f\n",num1,num2,num3);
				}
			}
		} else {
			if (num1>num3) {
				printf("EL ORDEN ES:%.2f < %.2f < %.2f\n",num3,num1,num2);
			} else {
				if (num1==num3) {
					printf("EL ORDEN ES:%.2f = %.2f < %.2f\n",num1,num3,num2);
				} else {
					if (num2<num3) {
						printf("EL ORDEN ES:%.2f < %.2f < %.2f\n",num1,num2,num3);
					} else {
						if (num2==num3) {
							printf("EL ORDEN ES:%.2f < %.2f = %.2f\n",num1,num2,num3);
						} else {
							printf("EL ORDEN ES:%.2f < %.2f < %.2f\n",num1,num2,num3);
						}
					}
				}
			}
		}
	}
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

