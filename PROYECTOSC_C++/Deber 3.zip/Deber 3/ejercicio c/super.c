#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(LIGHTGRAY);
     clrscr();
	float c, d, pa, tc;
	int u;
   textcolor( LIGHTGREEN);
     gotoxy (10,2);
	printf("ALGORITMO QUE CALCULA EL VALOR A PAGAR POR UNA COMPRA SI TIENE DESCUENTO EN UN SUPERMERCADO\n");
	 textcolor(CYAN);
	 gotoxy (30,4);
	printf("INGRESA EL PRECIO DE UN ARTICULO: ");
	scanf("%f",&pa);
	 textcolor(MAGENTA);
	 gotoxy (30,5);
	printf("INGRESA LAS UNIDADES QUE SE LLEVA DEL ARTICULO: ");
	scanf("%i",&u);
	c = pa*u;
	if (u>=10) {
		d = c*0.1;
		textcolor(LIGHTMAGENTA);
	 gotoxy (30,6);
		printf("SU DESCUENTOS ES %f\n",d);
	} else {
		d = 0;
	}
	tc = c-d;
	textcolor( BLUE );
	gotoxy (33,8);
	printf("SU TOTAL A PAGAR ES:%f\n",tc);
	textcolor( LIGHTBLUE );
	gotoxy (33,9);
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

