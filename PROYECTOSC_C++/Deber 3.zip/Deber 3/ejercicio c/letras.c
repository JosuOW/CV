#include <stdio.h>
#include <stdlib.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main(){
		textbackground(RED);
	clrscr();
	int num, mil, cen, dec, uni ;
	textcolor(LIGHTGRAY);
     gotoxy (15,1);
		printf("APLICACION QUE ESCRIBE NUMEROS DE 1 A 9999 EN PALABRAS\n");
		textcolor(YELLOW);
	gotoxy(25,2);printf("CONVERTIR UN NUMERO A LETRAS (1 A 9999)");
	gotoxy(2,4);printf("INGRESE UN NUMERO ENTERO: "); scanf("%i",&num);
	
	if (num >= 0 && num<=9999){
		uni=num%10;  num=num/10;
		dec=num%10;  num=num/10;
		cen=num%10;  num=num/10;
		mil=num%10;
		 switch (mil) {
		 	case 0:printf("");break;
		 	case 1: printf("mil "); break;
		 	case 2: printf("dos mil "); break;
		 	case 3: printf("tres mil "); break;
		 	case 4: printf("cuatro mil "); break;
		 	case 5: printf("cinco mil "); break;
		 	case 6: printf("seis mil "); break;
		 	case 7: printf("siete mil "); break;
		 	case 8: printf("ocho mil "); break;
		 	case 9: printf("nueve mil "); break;
		 }
		 switch (cen) {
		 	case 0:printf("");break;
			case 1: if (dec==0&& uni==0){
				printf("cien ");
			 }else{
			 	printf("ciento ");
			 }break;
		 	case 2: printf("docientos "); break;
		 	case 3: printf("trecientos "); break;
		 	case 4: printf("cuatrocientos "); break;
		 	case 5: printf("quinentos ");break;
		 	case 6: printf("seiscientos "); break;
		 	case 7: printf("setecientos "); break;
		 	case 8: printf("ochocientos "); break;
		 	case 9: printf("novecientos "); break;
		}
     	switch (dec) {
		 	case 1: switch (uni){
				case 0: printf("diez");break;
		 		case 1: printf("once "); break;
		 		case 2: printf("doce "); break;
		 		case 3: printf("trece "); break;
		 		case 4: printf("catorce "); break;
		 		case 5: printf("quience "); break;
		 		case 6: printf("dieciseis "); break;
		 		case 7: printf("diecisiete "); break;
		 		case 8: printf("dieciocho "); break;
		 		case 9: printf("diecinueve "); break;
			 }break;
			
		 	case 2: switch (uni){
		 		case 1: printf("veinte "); break;
		 		case 2: printf("ventiuno "); break;
		 		case 3: printf("ventidos "); break;
		 		case 4: printf("venticuatro "); break;
		 		case 5: printf("veinticinco "); break;
		 		case 6: printf("veintiseis "); break;
		 		case 7: printf("veintisiete "); break;
		 		case 8: printf("veintiocho "); break;
		 		case 9: printf("ventiinueve "); break;
			 }break;
			 
		 	case 3: if (uni==0){
				printf("treinta ");
			 }else{
			 	printf("treinta y ");
			 }break;
			 
		 	case 4: if (uni==0){
				printf("cuarenta ");
			 }else{
			 	printf("cuarenta y ");
			 }break;
		 	case 5: if (uni==0){
				printf("cincuenta ");
			 }else{
			 	printf("cincuenta y ");
			 }break;
		 	case 6: if (uni==0){
				printf("sesenta ");
			 }else{
			 	printf("sesenta y ");
			 }break;
		 	case 7: if (uni==0){
				printf("setenta ");
			 }else{
			 	printf("setenta y ");
			 }break;
		 	case 8: if (uni==0){
				printf("ochenta ");
			 }else{
			 	printf("ochenta y ");
			 }break;
		 	case 9: if (uni==0){
				printf("noventa ");
			 }else{
			 	printf("noventa y ");
			 }break;
		 }  
		 switch (uni){
		 	case 0: if (mil==0 && cen==0 && dec==0){
				printf("cero");
				}else{
			 	printf("");
				}break;
			case 1: if(mil==0&&cen==0&&dec==0){
					printf("uno");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("uno");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("uno");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("uno");
				}else {
					printf("");
				}break;
			case 2: if(mil==0&&cen==0&&dec==0){
					printf("dos");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("dos");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("dos");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("dos");
				}else {
					printf("");
				}break;
			case 3: if(mil==0&&cen==0&&dec==0){
					printf("tres");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("tres");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("tres");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("tres");
				}else {
					printf("");
				}break;
			case 4: if(mil==0&&cen==0&&dec==0){
					printf("cuatro");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("cuatro");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("cuatro");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("cuatro");
				}else {
					printf("");
				}break;
			case 5:if(mil==0&&cen==0&&dec==0){
					printf("cinco");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("cinco");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("cinco");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("cinco");
				}else {
					printf("");
				}break;
			case 6: if(mil==0&&cen==0&&dec==0){
					printf("seis");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("seis");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("seis");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("seis");
				}else {
					printf("");
				}break;
			case 7: if(mil==0&&cen==0&&dec==0){
					printf("siete");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("siete");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("siete");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("siete");
				}else {
					printf("");
				}break;
			case 8: if(mil==0&&cen==0&&dec==0){
					printf("ocho");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("ocho");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("ocho");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("ocho");
				}else {
					printf("");
				}break;
			case 9: if(mil==0&&cen==0&&dec==0){
					printf("nueve");
				}else if (mil==0&&cen==0&&dec>=3){
					printf("nueve");
				}else if (mil==0&&cen>=1&&dec>=3 || dec==0){
					printf("nueve");
				}else if (mil>=1&&cen>=0&&dec>=3 || dec==0){
					printf("nueve");
				}else {
					printf("");
				}break;
		 }
		 
	}else {
	 gotoxy (15,5);
		printf("NUMERO FUERA DEL INTERVALO\n");
	}
	textcolor(LIGHTCYAN);
	gotoxy (15,6);
		printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}
