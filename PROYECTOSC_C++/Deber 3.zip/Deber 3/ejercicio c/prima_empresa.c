#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(LIGHTGRAY);
clrscr();
	int h;
	float p, s;
 textcolor(CYAN);
  gotoxy (25,2);
	printf("APLICACION CALCULA EL SUELDO FINAL ADEMAS DE LA PRIMA ESPECIAL\n");
	textcolor( LIGHTGREEN);
  gotoxy (30,4);
	printf(" INGRESE SU SUELDO: ");
	scanf("%f",&s);
	textcolor( DARKGRAY );
         gotoxy (30,6);
	printf(" INGRESE EL NUMERO DE HIJOS QUE TIENE:");
	scanf("%i",&h);
	switch (h) {
	case 0:
		p = 0;
			textcolor( BLUE );
         gotoxy (33,8);
		printf("NO TIENE PRIMA ESPECIAL\n");
		break;
	case 1:
		p = s*0.05;
		break;
	case 2:
		p = s*0.08;
		break;
	case 3:
		p = s*0.1;
		break;
	case 4:
		p = s*0.12;
		break;
	default:
		p = s*0.15;
	}
	textcolor( BLUE );
             gotoxy (33,9);
	printf("SU SUELDO FINAL ES: %f EL VALOR DE SU PRIMA ESPECIAL ES: %f\n",s+p,p);
		textcolor( LIGHTMAGENTA);
	gotoxy (33,10);
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

