#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(BLACK);
     clrscr();
	float d, m1, m2, m3, m4, msa, mt, prom;
    textcolor(LIGHTGRAY);
     gotoxy (15,2);
	printf("ALGORITMO QUE CALCULA LA MATRÍCULA PARA EL SIGUIENTE SEMESTRE A PARTIR DE LAS NOTAS \n");
	textcolor( YELLOW);
    gotoxy (30,3);
	printf("INGRESAR LAS NOTAS CONSIDERANDO QUE SE EVALUAN DE 0 A 5 \n");
	textcolor( LIGHTCYAN);
	gotoxy (30,4);
	printf("INGRESE LA NOTA DE LA MATERIA 1: ");
	scanf("%f",&m1);
	textcolor( LIGHTBLUE);
	gotoxy (30,5);
	printf("INGRESE LA NOTA DE LA MATERIA 2: ");
	scanf("%f",&m2);
	textcolor( WHITE);
	gotoxy (30,6);
	printf("INGRESE LA NOTA DE LA MATERIA 3: ");
	scanf("%f",&m3);
	textcolor( MAGENTA);
	gotoxy (30,7);
	printf("INGRESE LA NOTA DE LA MATERIA 4: ");
	scanf("%f",&m4);
	textcolor( YELLOW);
    gotoxy (20,8);
	printf("INGRESE EL VALOR QUE PAGO DE MATRICULA DEL SEMESTRE ANTERIOR: ");
	scanf("%f",&msa);
	prom = (m1+m2+m3+m4)/4;
		textcolor( LIGHTCYAN);
	gotoxy (20,9);
	printf("SU PROMEDIO ES: %.2f\n",prom);
	if (prom>=4.8) {
		textcolor( BLUE);
		gotoxy (15,10);
		printf("NO DEBE PAGAR MATRICULA\n");
		mt = 0;
	} else {
		if (prom>=4.5) {
			d = msa*0.5;
			textcolor( BLUE);
			gotoxy (15,10);
			printf("SU DESCUENTOS ES: %.2f\n",d);
			mt = msa-d;
		} else {
			if (prom>=4) {
				textcolor( BLUE);
				gotoxy (15,10);
				printf("SE MATIENE EL VALOR\n");
				mt = msa;
			} else {
				d = msa*0.1;
				textcolor( BLUE);
				gotoxy (15,10);
				printf("SU INCREMENTO ES %.2f\n",d);
				mt = msa+d;
			}
		}
	}
	textcolor( LIGHTGREEN);
	gotoxy (15,11);
	printf("SU TOTAL A PAGAR ES: %.2f PARA EL SIGUIENTE SEMESTRE\n",mt);
	textcolor( LIGHTMAGENTA);
	gotoxy (15,12);
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

