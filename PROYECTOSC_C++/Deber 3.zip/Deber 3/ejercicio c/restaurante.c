#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(RED);
   clrscr();
	int i;
	float tp, vs;
	 textcolor(CYAN);
  gotoxy (25,2);
	printf("ALGORITMO QUE CALCULA EL VALOR A CANCELAR DE UN PEDIDO A DOMICILIO\n");
		textcolor( WHITE);
  gotoxy (30,4);
	printf("INGRESAR EL VALOR DEL SERVICIO: ");
	scanf("%f",&vs);
	if (vs>20000) {
		     textcolor( BROWN);
         gotoxy (30,5);
		printf("NO TIENE NINGUN COSTO ADICIONAL \n");
		i = 0;
	} else {
		if (vs>=10000) {
			i = 2000;
		} else {
			i = 4000;
		}
	}
	tp = vs+i;
	textcolor( LIGHTGREEN);
		gotoxy (25,6);
	printf("SU TOTAL A PAGAR ES: %.2f SU COSTO ADICIONAL ES: %i\n",tp,i);
	textcolor( YELLOW);
		gotoxy (25,7);
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

