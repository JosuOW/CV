#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(BLACK);
     clrscr();
	int nd, tv;
	float v, t;
	textcolor(LIGHTGRAY);
     gotoxy (15,2);
	printf(" APLICACION CALCULA EL VALOR DE CADA UNO DE LOS PRÉSTAMOS\n");
	textcolor( YELLOW);
    gotoxy (30,3);
	printf(" ESCOJA EL TIPO DE VEHICULO: \n");
	textcolor( LIGHTCYAN);
	gotoxy (30,4);
	printf(" 1   Automovil\n");
	gotoxy (30,5);
	printf(" 2   Campero\n");
	gotoxy (30,6);
	printf(" 3   Microbus\n");
	gotoxy (30,7);
	printf(" 4   Camioneta\n");
	gotoxy (30,8);
	printf(" 5   Salir\n");
	textcolor( MAGENTA);
	gotoxy (20,9);
	printf(" Ingresar Opcion:");
	scanf("%i",&tv);
		textcolor( BLUE);
		gotoxy (15,10);
	printf("  INGRESAR LOS DIAS DE PRESTAMO: ");
	scanf("%i",&nd);
	switch (tv) {
	case 1:
		v = 20000;
		break;
	case 2:
		v = 30000;
		break;
	case 3:
		v = 50000;
		break;
	case 4:
		v = 40000;
		break;
	case 5:
		textcolor( LIGHTGREEN);
	gotoxy (15,11);
		printf(" GRACIAS POR USAR EL PROGRAMA\n");
		break;
	default:
		textcolor( LIGHTGREEN);
	gotoxy (15,11);
		printf("   OPCION NO VALIDA INTENTE DE NUEVO\n");
	}
	t=v*nd;
	textcolor( LIGHTMAGENTA);
	gotoxy (15,12);
	printf(" EL VALOR DEL PRESTAMO ES: %.2f\n",t);
	textcolor( LIGHTRED);
	gotoxy (15,13);
	printf(" GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

