#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(BROWN);
   clrscr();
	int tm1, tm2;
	float tp;
textcolor(LIGHTGRAY);
     gotoxy (35,2);
	printf(" APLICACION DETERMINA SI UN ATLETA ES PATROCINADO \n");
	textcolor( LIGHTMAGENTA);
  gotoxy (30,3);
	printf(" DE ACUERDO CON LAS MARCAS DE ENTRENAMIENTO DEL ULTIMO MES \n");
		textcolor(LIGHTRED );
    gotoxy (30,4);
	printf("  INGRESAR SU TIEMPO MAYOR EN MINUTOS: ");
	scanf("%i",&tm1);
	  gotoxy (30,5);
	printf("  INGRESAR SU TIEMPO MENOR EN MINUTOS: ");
	scanf("%i",&tm2);
	tp = (tm1+tm2)/2;
	textcolor( BLUE);
    gotoxy (30,7);
	printf(" SU PROMEDIO DE TIEMPO ES: %.2f\n",tp);
	if (tm1<40 && tm2<30 && tp<35) {
		textcolor( CYAN);
    gotoxy (30,8);
		printf(" FELICIDADES ES PATROCINADO\n");
	} else {
		textcolor( CYAN);
    gotoxy (30,8);
		printf("  NO ES PATROCINADO\n");
	}
	textcolor( WHITE);
    gotoxy (30,9);
	printf(" GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

