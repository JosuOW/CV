#include<stdio.h>
#include<conio2.h>
	/* autora: Josune Singana */
	/* fecha: 3-Junio-2022 */
int main() {
	textbackground(CYAN);
     clrscr();
	int ec, ed, ef, pe, pec, pef, pte;
	 textcolor(BLUE);
     gotoxy (15,2);
	printf("APLICACION CALCULA EL PUNTAJE TOTAL PARA UNA ENTREVISTA\n");
	textcolor( MAGENTA);
    gotoxy (30,3);
	printf("INGRESE SU EDAD: ");
	scanf("%i",&ed);
		textcolor(BROWN );
    gotoxy (30,4);
	printf(" OPCIONES PARA EDUCACION FORMAL:\n");
	printf(" 1   Estudio bachillerato\n");
	printf(" 2   Tecnico\n");
	printf(" 3   Profesional\n");
	printf(" 4   Postgrado\n");
	printf(" Ingresar Opcion:");
	scanf("%i",&ef);
		textcolor(RED);
    gotoxy (30,10);
	printf(" OPCIONES PARA ESTADO CIVIL:\n");
	printf(" 1   Soltero\n");
	printf(" 2   Casado\n");
	printf(" 3   Union libre\n");
	printf(" 4   Separado\n");
	printf(" Ingresar Opcion:");
	scanf("%i",&ec);
	textcolor(BLUE);
    gotoxy (30,16);
	if (ed<18) {
		pe = 0;
	} else {
		if (ed<25) {
			pe = 10;
		} else {
			if (ed<31) {
				pe = 20;
			} else {
				if (ed<=40) {
					pe = 15;
				} else {
					pe = 8;
				}
			}
		}
	}
	switch (ef) {
	case 1:
		pef = 5;
		break;
	case 2:
		pef = 8;
		break;
	case 3:
		pef = 10;
		break;
	case 4:
		pef = 15;
		break;
	default:
		printf(" OPCION NO VALIDA\n");
	}
	switch (ec) {
	case 1:
		pec = 20;
		break;
	case 2:
		pec = 15;
		break;
	case 3:
		pec = 12;
		break;
	case 4:
		pec = 18;
		break;
	default:
		printf(" OPCION NO VALIDA\n");
	}
	pte = pe+pef+pec;
	printf("SU PUNTAJE TOTAL EN LA ENTREVISTA ES: %i\n",pte);
	printf("GRACIAS POR USAR EL PROGRAMA\n");
	return 0;
}

