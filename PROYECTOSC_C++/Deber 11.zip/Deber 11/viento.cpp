#include<iostream>
#include<cstdlib>
#include<conio2.h>
using namespace std;
#define SIN_TIPO string
// una estación de control realiza mediciones de la velocidad
// del viento tres veces por día y
// transmite a la base los datos tomados, los cuales son guardados en 
// un arreglo, hasta ser procesado para obtener la siguiente información:
// la mayor y la menor velocidad del viento por semana, mes y año,
// así como el promedio por semana, mes y año
// velocidad viento varia entre 0.5 a 6.89 km/h
// ¿Qúe arreglo podrá almacenar los datos?
// datos[#leedia][día+3][semana+3][mes]--> datos[3][10][7][15]
// llenarDatos(azar(64)+5)/10
void llenardatos(float datos[3][7][4][12]);
void escribirdatos(float datos[3][7][4][12]);
void escribirrespuesta(float mat[5][12], string titulo, string tit1);
void menordatos(float datos[3][7][4][12], float min[5][12]);
void mayordatos(float datos[3][7][4][12], float max[5][12]);
void promdatos(float datos[3][7][4][12], float prom[5][12]);

void llenardatos(float datos[3][7][4][12]) {
	int dia, mes, nl,  nld, sem;
	for (nld=0;nld<=2;nld++) {
		for (dia=0;dia<=6;dia++) {
			for (sem=0;sem<=3;sem++) {
				for (mes=0;mes<=11;mes++) {
					datos[nld][dia][sem][mes] = ((rand()%64)+5)/10;
				}
			}
		}
	}
}

void escribirdatos(float datos[3][7][4][12]) {
		int dia, mes, nl,  nld, sem;
	for (mes=0;mes<=11;mes++) {
		cout << "MES: " << mes+1 << " " << endl;
		for (sem=0;sem<=3;sem++) {
			cout << "SEMANA: " << sem+1 << " " << endl;
			for (dia=0;dia<=6;dia++) {
				cout << "DIA: " << dia+1 << "...... ";
				for (nld=0;nld<=2;nld++) {
					cout << datos[nld][dia][sem][mes] << " ";
				}
			}
			cout << " " << endl;
		}
		cout << " " << endl;
	}
}

void escribirrespuesta(float mat[5][12], string titulo, string tit1) {
	int mes, sem;
	cout << titulo << endl;
	for (mes=0;mes<=11;mes++) {
		cout << "MES: " << mes+1 << " " << tit1 << " ES: " << mat[4][mes] << endl;
		for (sem=0;sem<=3;sem++) {
			cout << "SEMANA " << sem+1 << " : ";
			cout << mat[sem][mes] << "  ";
		}
		cout << " " << endl;
	}
}

void menordatos(float datos[3][7][4][12], float min[5][12]) {
	int dia, mes, nl,  nld, sem;
	float menor;
	for (mes=0;mes<=11;mes++) {
		min[4][mes] = 999;
		for (sem=0;sem<=3;sem++) {
			menor = 999;
			for (dia=0;dia<=6;dia++) {
				for (nld=0;nld<=2;nld++) {
					if (menor>datos[nld][dia][sem][mes]) {
						menor = datos[nld][dia][sem][mes];
					}
				}
			}
			min[sem][mes] = menor;
			if (min[4][mes]>menor) {
				min[4][mes] = menor;
			}
		}
	}
}

void mayordatos(float datos[3][7][4][12], float max[5][12]) {
int dia, mes, nl,  nld, sem;
	float mayor;
	for (mes=0;mes<=11;mes++) {
		max[4][mes] = -1;
		for (sem=0;sem<=3;sem++) {
			mayor = -1;
			for (dia=0;dia<=6;dia++) {
				for (nld=0;nld<=2;nld++) {
					if (mayor<datos[nld][dia][sem][mes]) {
						mayor = datos[nld][dia][sem][mes];
					}
				}
			}
			max[sem][mes] = mayor;
			if (max[4][mes]<mayor) {
				max[4][mes] = mayor;
			}
		}
	}
}

void promdatos(float datos[3][7][4][12], float prom[5][12]) {
	int dia, mes, nl,  nld, sem;
	float promedio;
	for (mes=0;mes<=11;mes++) {
		prom[4][mes] = 0;
		for (sem=0;sem<=3;sem++) {
			promedio = 0;
			for (dia=0;dia<=6;dia++) {
				for (nld=0;nld<=2;nld++) {
					promedio = promedio+datos[nld][dia][sem][mes];
				}
				prom[sem][mes] = promedio/3;
			}
			prom[sem][mes] = prom[sem][mes]/7;
			prom[4][mes] = prom[4][mes]+prom[sem][mes];
		}
		prom[4][mes] = prom[4][mes]/4;
	}
}

int main() {
	float mayor[5][12];
	float menor[5][12];
	float prom[5][12];
	float viento[3][7][4][12];
	textbackground(1);
	clrscr();
	textcolor(14);
	llenardatos(viento);
		cout << "------------------------------------ VELOCIDAD DEL VIENTO ------------------------------" << endl;
	escribirdatos(viento);
	textcolor(15);
			cout << "<<<<<<<<< PRESIONA CUALQUIER TECLA PARA CONTINUAR >>>>>>>>>>>>>>>" << endl;
		getch();
			clrscr();
	menordatos(viento,menor);	
	escribirrespuesta(menor,"VALORES MENORES SEMANAL, MENSUAL","MENOR");
cout << "<<<<<<<<< PRESIONA CUALQUIER TECLA PARA CONTINUAR >>>>>>>>>>>>>>>" << endl;
		getch();
			clrscr();
				textbackground(11);
					textcolor(15);
	mayordatos(viento,mayor);
	escribirrespuesta(mayor,"VALORES MAYOR SEMANAL, MENSUAL","MAYOR");
	cout << "<<<<<<<<< PRESIONA CUALQUIER TECLA PARA CONTINUAR >>>>>>>>>>>>>>>" << endl;
		getch();
			clrscr();
				textbackground(10);
					textcolor(0);
	promdatos(viento,prom);
	escribirrespuesta(prom,"VALORES PROMEDIO SEMANAL, MENSUAL","PROMEDIO");
		getch();
	return 0;
}
