#include<iostream>
#include<cmath>
#include<cstdlib>
#include<sstream>
#include<conio2.h>
using namespace std;
string convertiratexto(float f);
#define ARREGLO_MAX 100
#define SIN_TIPO string
void buscabinaria(int lst[], int ne, int val, int &pos, int &nc);

void buscabinaria(int lst[], int ne, int val, int &pos, int &nc) {
	int centro, inf, sup;
	nc = 0;
	pos = -1;
	inf = 0;
	sup = ne-1;
	while (inf<=sup && pos<0) {
		centro = int((inf+sup)/2);
		if (lst[centro]==val) {
			pos = centro;
		} else {
			if (val>lst[centro]) {
				inf = centro+1;
			} else {
				sup = centro-1;
			}
		}
		nc = nc+1;
	}
}

int main() {
textbackground(0);
	clrscr();
	textcolor(14);
	string apellido[10];
	string cliente[ARREGLO_MAX];
	string fecha[ARREGLO_MAX];
	int i, j, k, nf, nft, x, cedulaf,num[10],  numcomp, resp ;
	int numfac[ARREGLO_MAX];
	int v[ARREGLO_MAX] ;
	string l;
	string nombre[10];
	string valorf[ARREGLO_MAX];
	nombre[0] = "ARLENE";
	nombre[1] = "NIURKA";
	nombre[2] = "TOMAS";
	nombre[3] = "DAVID";
	nombre[4] = "ESTEBAN";
	nombre[5] = "HERNAN";
	nombre[6] = "CESIA";
	nombre[7] = "LUCIA";
	nombre[8] = "MARCEL";
	nombre[9] = "PAOLA";
	apellido[0] = "EZQUIBEL";
	apellido[1] = "MORENO";
	apellido[2] = "AYALA";
	apellido[3] = "TOAPANTA";
	apellido[4] = "CAMINO";
	apellido[5] = "TARCO";
	apellido[6] = "MONTA";
	apellido[7] = "SERRANO";
	apellido[8] = "VASQUEZ";
	apellido[9] = "BASTIDAS";
	// autor=Singaña Josune
	// fecha=19-Agosto-2022
	 gotoxy (25,2);	cout << "APLICACION MUESTRA BUSQUEDA BINARIA EN FACTURAS " << endl;
	textcolor(11);
	   gotoxy (15,4);	cout << "CUANTAS FACTURAS QUIERE GENERAR: ";
	cin >> nft;
	for (i=0;i<=nft-1;i++) {
		numfac[i] = 2*i+1;
		j = (rand()%100)%10;
		k = (rand()%100)%5;
		num[i] = (rand()%31)+1;
		l = convertiratexto(num[i]);
		fecha[i] = fecha[i]+l;
		v[i] = (rand()%100000)+1;
		valorf[i] = convertiratexto(v[i]);
		cliente[i] = "            "+convertiratexto(numfac[i])+" | "+apellido[k]+" "+nombre[j]+" | "+fecha[i]+"-"+convertiratexto((rand()%12)+1)+"-2022"+" | "+valorf[i];
	}
		textcolor(13);
		cout << "<<<<<<<<<<<<<<<<<<<< LISTADO DE FACTURAS >>>>>>>>>>>>>>>>>>>" << endl;
	cout << "NUMERO FACTURA |  NOMBRE CLIENTE|   FECHA |   VALOR  " << endl;
	textcolor(9);
	for (i=0;i<=nft-1;i++) {
		cout << " " << cliente[i] << endl;
	}
	do {
			textcolor(14);
			cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++++++++++++++++ BUSQUEDA BINARIA DE FACTURA ++++++++++++++++++ " << endl;
		textcolor(11);
		cout << "QUE NUMERO DE FACTURA QUIERES BUSCAR: ";
		cin >> nf;
		buscabinaria(numfac,nft,nf,resp, numcomp);
	textcolor(9);
		if (resp>=0) {
			cout << "FACTURA CLIENTE: " << endl;
			cout << cliente[resp] << endl;
			cout << " NUMERO DE FACTURA: " << numfac[resp] << " NUMERO DE COMPARACIONES: " << numcomp << endl;
		} else {
			cout << nf << " NUMERO DE FACTURA NO ENCONTRADO" << endl;
		}
	} while (resp!=-1);
	getch();
	return 0;
}


string convertiratexto(float f) {
	stringstream ss;
	ss << f;
	return ss.str();
}

