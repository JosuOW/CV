#include<iostream>
#include<cstdlib>
#include<sstream>
#include<conio2.h>
using namespace std;
string convertiratexto(float f);
#define ARREGLO_MAX 100
void buscarsecuencialmente(string apellido[], string nombre[], string ap, string nl, int np, int &telefonof);
void buscarsecuencialmente(string apellido[], string nombre[], string ap, string nl, int np, int &telefonof) {
	int cont1a, cont1n, cont2a, cont2n, conta, contn, j, k, w, x;
	string letra1a[10];
	string letra1n[10];
	string letra2a[10];
	string letra2n[10];
	for (j=0;j<=ap.size()-1;j++) {
		letra1a[j] = ap.substr(j,j-j+1);
	}
	for (x=0;x<=nl.size()-1;x++) {
		letra1n[x] = nl.substr(x,x-x+1);
	}
	cont1a = j;
	cont1n = x;
	telefonof = -1;
	k = 0;
	do {
		cont2a = 0;
		cont2n = 0;
		for (x=0;x<=apellido[k].size()-1;x++) {
			letra2a[x] = apellido[k].substr(x,x-x+1);
		}
		cont2a = x;
		for (j=0;j<=nombre[k].size()-1;j++) {
			letra2n[j] = nombre[k].substr(j,j-j+1);
		}
		cont2n = j;
		if (cont1a==cont2a) {
			conta = 0;
			for (w=0;w<=cont1a-1;w++) {
				if (letra1a[w]==letra2a[w]) {
					conta = conta+1;
				}
			}
		}
		if (cont2n==cont1n) {
			contn = 0;
			for (w=0;w<=cont1n-1;w++) {
				if (letra1n[w]==letra2n[w]) {
					contn = contn+1;
				}
			}
		}
		if (contn==cont1n && cont2a==conta) {
			telefonof = k;
		}
		k = k+1;
	} while (!(telefonof!=-1 || k==np));
}

int main() {
	textbackground(14);
	clrscr();
	textcolor(12);
	string ap;
	string apellido[50];
	int i, j, k, np, x, telefonof;
	int num[10];
	string l;
	string nl;
	string nombre[50];
	string persona[ARREGLO_MAX];
	string personaa[50];
	string personan[50];
	string telefono[ARREGLO_MAX];
	string total[ARREGLO_MAX];
	nombre[0] = "ANA";
	nombre[1] = "VICENTE";
	nombre[2] = "RENATA";
	nombre[3] = "ROBIN";
	nombre[4] = "DEREK";
	nombre[5] = "KOUSUKE";
	nombre[6] = "DIANA";
	nombre[7] = "MELODY";
	nombre[8] = "SIMON";
	nombre[9] = "LUCAS";
	apellido[0] = "LARA";
	apellido[1] = "SOTO";
	apellido[2] = "ORTIZ";
	apellido[3] = "JIMENEZ";
	apellido[4] = "PEREZ";
	apellido[5] = "ALVAREZ";
	apellido[6] = "PARK";
	apellido[7] = "SANCHEZ";
	apellido[8] = "ESTRADA";
	apellido[9] = "RUIZ";
	// autor=Singaña Josune
	// fecha=19-Agosto-2022
	 gotoxy (25,2);cout << "APLICACION MUESTRA BUSQUEDA SECUENCIAL EN DIRECTORIO TELEFONICO " << endl;
textcolor(1);
	   gotoxy (15,4);	cout << "CUANTOS USUARIOS QUIERE GENERAR: ";
	cin >> np;
	for (x=0;x<=np-1;x++) {
		telefono[x] = "09";
		for (i=0;i<=7;i++) {
			num[i] = (rand()%9)+1;
			l = convertiratexto(num[i]);
			telefono[x] = telefono[x]+l;
		}
		j = (rand()%100)%10;
		k = (rand()%9)+1;
		personaa[x] = apellido[j];
		personan[x] = nombre[k];
		persona[x] = " | "+personaa[x]+" "+personan[x]+" | "+telefono[x];
	}
	textcolor(12);
	cout << "  <<<<<<<<<<<<<<<< DIRECTORIO TELEFONICO >>>>>>>>>>>>>>>>>>" << endl;
	cout << "    |    APELLIDO NOMBRE     |     NUMERO TELEFONICO  |" << endl;
		textcolor(0);
	for (i=0;i<=np-1;i++) {
		cout << " " << i+1 << " " << persona[i] << endl;
	}
	do {
		textcolor(1);
		cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++ BUSQUEDA SECUENCIAL DE DIRECTORIO TELEFONICO ++++++++++++++ " << endl;
		textcolor(5);cout << "APELLIDO QUE QUIERES BUSCAR USE LETRAS MAYUSCULA: ";
		textcolor(1);cin >> ap;
		textcolor(5);cout << "NOMBRE QUE QUIERES BUSCAR USE LETRAS MAYUSCULA: ";
		textcolor(1);cin >> nl;
		buscarsecuencialmente(personaa,personan,ap,nl,np,telefonof);
		textcolor(4);
		if (telefonof!=-1) {
			cout << "TELEFONO: " << telefono[telefonof] << endl;
		} else {
			cout << ap << " " << nl << " NO ENCONTRADO" << endl;
		}
	} while (telefonof!=-1);
	getch();
	return 0;
}


string convertiratexto(float f) {
	stringstream ss;
	ss << f;
	return ss.str();
}

