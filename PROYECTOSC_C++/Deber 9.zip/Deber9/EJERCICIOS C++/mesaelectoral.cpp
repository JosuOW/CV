#include<iostream>
#include<cstdlib>
#include<sstream>
#include<conio2.h>
using namespace std;
string convertiratexto(float f);
#define ARREGLO_MAX 100
void buscarsecuencialmente(string cedula[], string ced, float nl, int &cedulaf);

void buscarsecuencialmente(string cedula[], string ced, float nl, int &cedulaf) {
		int cont, cont1, cont2, j, k, w, x;
	string letra1[50];
	string letra2[50];
	for (j=0;j<=ced.size()-1;j++) {
		letra1[j] = ced.substr(j,j-j+1);
	}
	cont1 = j;
	cedulaf = -1;
	for (k=0;k<=nl-1;k++) {
		cont2 = 0;
		for (x=0;x<=cedula[k].size()-1;x++) {
			letra2[x] = cedula[k].substr(x,x-x+1);
		}
		cont2 = x;
		if (cont2==cont1) {
			cont = 0;
			for (w=0;w<=cont1-1;w++) {
				if (letra1[w]==letra2[w]) {
					cont = cont+1;
				}
			}
			if (cont2==cont) {
				cedulaf = k;
			}
		}
	}
}

int main() {
textbackground(0);
	clrscr();
	textcolor(15);
	string apellido[50];
	string ced;
	string cedula[ARREGLO_MAX];
	int i, j, k, np, x, cedulaf;
	string l;
	string nombre[50];
	int num[10];
	string persona[ARREGLO_MAX];
	nombre[0] = "ISAAC";
	nombre[1] = "VANESA";
	nombre[2] = "ROBERT";
	nombre[3] = "NANDO";
	nombre[4] = "KEIRA";
	nombre[5] = "SHARON";
	nombre[6] = "ALISA";
	nombre[7] = "MARLON";
	nombre[8] = "OMAR";
	nombre[9] = "LEOPOLDO";
	apellido[0] = "PAUKER";
	apellido[1] = "ROMERO";
	apellido[2] = "GARCIA";
	apellido[3] = "CARRERA";
	apellido[4] = "ZAMBONINO";
	apellido[5] = "TAPIA";
	apellido[6] = "PADILLA";
	apellido[7] = "SALAZAR";
	apellido[8] = "UVIDIA";
	apellido[9] = "IZA";
	// autor=Singaña Josune
	// fecha=19-Agosto-2022
 gotoxy (25,2);	cout << "APLICACION MUESTRA BUSQUEDA SECUENCIAL EN LISTADO DE MESA ELECCIONES " << endl;
		textcolor(10);
	   gotoxy (15,4);cout << "CUANTOS VOTANTES QUIERE GENERAR: ";
	cin >> np;
	for (x=0;x<=np-1;x++) {
		cedula[x] = "05";
		for (i=0;i<=7;i++) {
			num[i] = (rand()%9)+1;
			l = convertiratexto(num[i]);
			cedula[x] = cedula[x]+l;
		}
		j = (rand()%9)+1;
		k = (rand()%100)%10;
		persona[x] = " "+apellido[k]+" "+nombre[j]+" | "+cedula[x];
	}
		textcolor(15);
	cout << "<<<<<< MESA 1 PROVINCIA COTOPAXI >>>>>>>" << endl;
	cout << "  APELLIDO NOMBRE  | CEDULA" << endl;
		textcolor(9);
	for (i=0;i<=np-1;i++) {
		cout << " " << i+1 << " | " << persona[i] << endl;
	}
	do {
			textcolor(11);
			cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++ BUSQUEDA SECUENCIAL DE VOTANTE CON SU CEDULA ++++++++++++++ " << endl;
		cout << "CEDULA QUE QUIERES BUSCAR: ";
		cin >> ced;
		buscarsecuencialmente(cedula,ced,np,cedulaf);
	textcolor(14);
		if (cedulaf!=-1) {
			cout << persona[cedulaf] << "| PUEDE SUFRAGAR EN ESTA MESA " << endl;
		} else {
			cout << "LA PERSONA CON CEDULA " << ced << " NO PUEDE SUFRAGAR EN ESTA MESA " << endl;
		}
	} while (cedulaf!=-1);
	getch();
	return 0;
}


string convertiratexto(float f) {
	stringstream ss;
	ss << f;
	return ss.str();
}


