#include<iostream>
#include<cstdlib>
#include<sstream>
#include<conio2.h>
using namespace std;
string convertiratexto(float f);
#define ARREGLO_MAX 100
void buscarsecuencialmente(string cedula[], string ced, float nl, int &cedulaf);

void buscarsecuencialmente(string cedula[], string ced, float nl, int &cedulaf) {
	int cont, cont1, cont2, j, k, w, x;
	string letra1[50];
	string letra2[50];
	for (j=0;j<=ced.size()-1;j++) {
		letra1[j] = ced.substr(j,j-j+1);
	}
	cont1 = j;
	cedulaf = -1;
	for (k=0;k<=nl-1;k++) {
		cont2 = 0;
		for (x=0;x<=cedula[k].size()-1;x++) {
			letra2[x] = cedula[k].substr(x,x-x+1);
		}
		cont2 = x;
		if (cont2==cont1) {
			cont = 0;
			for (w=0;w<=cont1-1;w++) {
				if (letra1[w]==letra2[w]) {
					cont = cont+1;
				}
			}
			if (cont2==cont) {
				cedulaf = k;
			}
		}
	}
}

int main() {
	textbackground(4);
	clrscr();
	textcolor(15);
	string apellido[50];
	string ced;
	string cedula[ARREGLO_MAX];
	int deduccion[ARREGLO_MAX];
	string escritod[ARREGLO_MAX];
		int i, j, k, np, x, cedulaf,num[10];
	string l;
	string neto[ARREGLO_MAX];
	string nombre[50];
	string persona[ARREGLO_MAX];
	nombre[0] = "ARLENE";
	nombre[1] = "NIURKA";
	nombre[2] = "TOMAS";
	nombre[3] = "DAVID";
	nombre[4] = "ESTEBAN";
	nombre[5] = "HERNAN";
	nombre[6] = "CESIA";
	nombre[7] = "LUCIA";
	nombre[8] = "MARCEL";
	nombre[9] = "PAOLA";
	apellido[0] = "EZQUIBEL";
	apellido[1] = "MORENO";
	apellido[2] = "AYALA";
	apellido[3] = "TOAPANTA";
	apellido[4] = "CAMINO";
	apellido[5] = "TARCO";
	apellido[6] = "MONTA";
	apellido[7] = "SERRANO";
	apellido[8] = "VASQUEZ";
	apellido[9] = "BASTIDAS";
	// autor=Singaña Josune
	// fecha=19-Agosto-2022
	 gotoxy (25,2);	cout << "APLICACION MUESTRA BUSQUEDA SECUENCIAL EN LISTADO DE SALARIO " << endl;
		textcolor(14);
	   gotoxy (15,4);cout << "CUANTOS TRABAJADORES QUIERE GENERAR: ";
	cin >> np;
	for (x=0;x<=np-1;x++) {
		cedula[x] = "05";
		for (i=0;i<=7;i++) {
			num[i] = (rand()%9)+1;
			l = convertiratexto(num[i]);
			cedula[x] = cedula[x]+l;
		}
		for (i=0;i<=2;i++) {
			deduccion[x] = (rand()%100)+1;
			escritod[x] = convertiratexto(deduccion[x]);
		}
		neto[x] = convertiratexto(1200-deduccion[x]);
		j = (rand()%9)+1;
		k = (rand()%100)%10;
		persona[x] = " "+apellido[k]+" "+nombre[j]+" | "+cedula[x]+"| "+"1200"+"| "+escritod[x]+"| "+neto[x];
	}
		textcolor(15);
		cout << "<<<<<<<<<<<<<<<<<<<< LISTA DE EMPLEADOS >>>>>>>>>>>>>>>>>>>" << endl;
	cout << " | APELLIDO NOMBRE |  CEDULA  |  SALARIO |  DEDUCCION | NETO  A PAGAR| " << endl;
	textcolor(14);
	for (i=0;i<=np-1;i++) {
		cout << " " << i+1 << " " << persona[i] << endl;
	}
	do {
			textcolor(15);
			cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++ BUSQUEDA SECUENCIAL DE EMPLEADO ++++++++++++++ " << endl;
		cout << "CEDULA QUE QUIERES BUSCAR: ";
		cin >> ced;
		buscarsecuencialmente(cedula,ced,np,cedulaf);
textcolor(7);
		if (cedulaf!=-1) {
				cout << " | APELLIDO NOMBRE |  CEDULA  |  SALARIO |  DEDUCCION | NETO  A PAGAR| " << endl;
			cout << "EMPLEADO: " << persona[cedulaf] << endl;
		} else {
			cout << ced << " NO ENCONTRADO" << endl;
		}
	} while (cedulaf!=-1);
	getch();
	return 0;
}


string convertiratexto(float f) {
	stringstream ss;
	ss << f;
	return ss.str();
}

