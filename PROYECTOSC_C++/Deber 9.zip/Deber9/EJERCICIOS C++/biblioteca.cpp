#include<iostream>
#include<cstdlib>
#include<sstream>
#include<conio2.h>
using namespace std;
string convertiratexto(float f);
#define ARREGLO_MAX 100
#define SIN_TIPO string
void buscarsecuencialmente(string buscatitulo[], string titulo, float nl, int libro[], int &i);

void buscarsecuencialmente(string buscatitulo[], string titulo, float nl, int libro[], int &i) {
	int cont, cont1, cont2, j, k, w, x;
	string letra1[50];
	string letra2[50];
	for (j=0;j<=titulo.size()-1;j++) {
		letra1[j] = titulo.substr(j,j-j+1);
	}
	cont1 = j;
	i = 0;
	libro[0] = -1;
	for (k=0;k<=nl-1;k++) {
		cont2 = 0;
		for (x=0;x<=buscatitulo[k].size()-1;x++) {
			letra2[x] = buscatitulo[k].substr(x,x-x+1);
		}
		cont2 = x;
		if (cont2==cont1) {
			cont = 0;
			for (w=0;w<=cont1-1;w++) {
				if (letra1[w]==letra2[w]) {
					cont = cont+1;
				}
			}
			if (cont2==cont) {
				libro[i] = k;
				i = i+1;
			}
		}
	}
}

int main() {
	textbackground(3);
	clrscr();
	textcolor(15);
	string anios[50];
	string apellido[50];
	string autor[ARREGLO_MAX];
	string buscatitulo[50];
	string editorial[50];
	int i,j, k, m,n,nl, x, libro[50], num[10];
	string letra;
	string nombre[50];
	SIN_TIPO personan[50];
	string sig[ARREGLO_MAX];
	string signatura[50];
	string titu;
	string titulo[50];
	nombre[0] = "RYAN";
	nombre[1] = "LOUIS";
	nombre[2] = "MINHO";
	nombre[3] = "JHON";
	nombre[4] = "HARU";
	nombre[5] = "KOUSUKE";
	nombre[6] = "DIANA";
	nombre[7] = "MARIE";
	nombre[8] = "SIMON";
	nombre[9] = "LUCAS";
	apellido[0] = "STEWART";
	apellido[1] = "LOPEZ";
	apellido[2] = "RAMIREZ";
	apellido[3] = "WEISBACH";
	apellido[4] = "KRAIGER";
	apellido[5] = "KIM";
	apellido[6] = "KIRISHIMA";
	apellido[7] = "RODRIGUEZ";
	apellido[8] = "ESTRADA";
	apellido[9] = "RUIZ";
	titulo[0] = "COMPUTACION-CUANTICA-EL-FUTURO-DE-LA-TECNOLOGIA";
	titulo[1] = "FISICA-VECTORIAL";
	titulo[2] = "INTELIGENCIA-ARTIFICIAL";
	titulo[3] = "PROGRAMACION-I";
	titulo[4] = "LA-TEORIA-DE-LA-SELECCION-NATURAL";
	titulo[5] = "DINAMICA-AVANZADA";
	titulo[6] = "CALCULO-I";
	titulo[7] = "LOS EFECTOS-DE-LA-RADIACION";
	titulo[8] = "SER-O-NO-SER";
	titulo[9] = "LEJOS-DE-LAS-PREOCUPACIONES";
	anios[0] = "2010";
	anios[1] = "2015";
	anios[2] = "2018";
	anios[3] = "1967";
	anios[4] = "2021";
	anios[5] = "1986";
	editorial[0] = "TOKIO.CR";
	editorial[1] = "TEBAR";
	editorial[2] = "BROOKS";
	editorial[3] = "REVERTE";
	editorial[4] = "PHILADELPHIA";
	editorial[5] = "RICH.N";
	signatura[0] = "5LOS";
	signatura[1] = "4RMU";
	signatura[2] = "6WEIY";
	signatura[3] = "2KRAN";
	signatura[4] = "9AMUI";
	signatura[5] = "I0SR";
	signatura[6] = "G5ER";
	signatura[7] = "A6IT";
	signatura[8] = "K2NL";
	signatura[9] = "I4GV";
	// autor=Singaña Josune
	// fecha=19-Agosto-2022
	 gotoxy (25,2);	cout << "APLICACION MUESTRA BUSQUEDA SECUENCIAL EN BIBLIOTECA " << endl;
	textcolor(11);
	   gotoxy (15,4);cout << "CUANTOS LIBROS QUIERE GENERAR: ";
	cin >> nl;
	for (x=0;x<=nl-1;x++) {
		for (i=0;i<=4;i++) {
			num[i] = (rand()%9)+1;
			letra = convertiratexto(num[i]);
			sig[x] = sig[x]+letra;
		}
		j = (rand()%100)%10;
		k = (rand()%9)+1;
		m = (rand()%5)+1;
		n = (rand()%5)+1;
		buscatitulo[x] = titulo[j];
		autor[x] = " "+apellido[k]+" "+nombre[k]+"| "+buscatitulo[x]+"| "+editorial[n]+"| "+anios[m]+"| "+signatura[m]+sig[x];
	}
		textcolor(15);
			cout << "  <<<<<<<<<<<<<<<<<<<    BIBLIOTECA    >>>>>>>>>>>>>>>>>>" << endl;
		cout << "  AUTOR         | TITULO  | EDITORIAL  | ANIO    | SIGNATURA" << endl;
		textcolor(1);
	for (i=0;i<=nl-1;i++) {
		cout << " " << i+1 << " " << autor[i] << endl;
	}
	do {
			textcolor(15);
			cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++ BUSQUEDA SECUENCIAL DE UN LIBRO ++++++++++++++ " << endl;
	textcolor(11);
		cout << "TITULO QUE QUIERES BUSCAR USE LETRAS MAYUSCULA: ";
		cin >> titu;
		buscarsecuencialmente(buscatitulo,titu,nl,libro,m);
		textcolor(0);
		if (libro[0]!=-1) {
			cout << "ENCONTRADO: " << endl;
			for (i=0;i<=m-1;i++) {
				cout << "LIBRO [ " << i+1 << " ]: " << autor[libro[i]] << endl;
			}
		} else {
			cout << " " << titu << " NO ENCONTRADO" << endl;
		}
	} while (libro[0]!=-1);
	getch();
	return 0;
}


string convertiratexto(float f) {
	stringstream ss;
	ss << f;
	return ss.str();
}

