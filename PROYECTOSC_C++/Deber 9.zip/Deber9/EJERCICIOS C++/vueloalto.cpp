#include<iostream>
#include<cstdlib>
#include<sstream>
#include<conio2.h>
using namespace std;
string convertiratexto(float f);
#define ARREGLO_MAX 100
void buscarsecuencialmente(string origen[], string destino[], string ap, string nl, int np, int &vuelof);

void buscarsecuencialmente(string origen[], string destino[], string ap, string nl, int np, int &vuelof) {
	int cont1a, cont1n, cont2a, cont2n, conta, contn, j, k, w, x;
	string letra1a[50];
	string letra1n[50];
	string letra2a[50];
	string letra2n[50];
	for (j=0;j<=ap.size()-1;j++) {
		letra1a[j] = ap.substr(j,j-j+1);
	}
	for (x=0;x<=nl.size()-1;x++) {
		letra1n[x] = nl.substr(x,x-x+1);
	}
	cont1a = j;
	cont1n = x;
	vuelof = -1;
	k = 0;
	do {
		cont2a = 0;
		cont2n = 0;
		for (x=0;x<=origen[k].size()-1;x++) {
			letra2a[x] = origen[k].substr(x,x-x+1);
		}
		cont2a = x;
		for (j=0;j<=destino[k].size()-1;j++) {
			letra2n[j] = destino[k].substr(j,j-j+1);
		}
		cont2n = j;
		if (cont1a==cont2a) {
			conta = 0;
			for (w=0;w<=cont1a-1;w++) {
				if (letra1a[w]==letra2a[w]) {
					conta = conta+1;
				}
			}
		}
		if (cont2n==cont1n) {
			contn = 0;
			for (w=0;w<=cont1n-1;w++) {
				if (letra1n[w]==letra2n[w]) {
					contn = contn+1;
				}
			}
		}
		if (contn==cont1n && cont2a==conta) {
			vuelof = k;
		}
		k = k+1;
	} while (!(vuelof!=-1 || k==np));
}

int main() {
		textbackground(14);
	clrscr();
	textcolor(1);
	string des;
	string destino[50];
	string hora[ARREGLO_MAX];
	int i, j, k, m, np, x, v, vuelof,num[10];
	string l;
	string ori;
	string origen[50];
	string total[ARREGLO_MAX];
	string valorv[ARREGLO_MAX];
	string vuelo[ARREGLO_MAX];
	string vueloa[50];
	string vuelod[50];
	destino[0] = "BERLIN-ALEMANIA";
	destino[1] = "LUANDA-ANGOLA";
	destino[2] = "BUENOS-AIRES-ARGENTINA";
	destino[3] = "CANBERRA-AUSTRALIA";
	destino[4] = "VIENA-AUSTRIA";
	destino[5] = "BRUSELAS-BELGICA";
	destino[6] = "LA-PAZ-BOLIVIA";
	destino[7] = "BRASILIA-BRAZIL";
	destino[8] = "TOKIO-JAPON";
	destino[9] = "LA-HABANA-CUBA";
	origen[0] = "QUITO-ECUADOR";
	origen[1] = "CUENCA-ECUADOR";
	origen[2] = "GUAYAQUIL-ECUADOR";
	origen[3] = "ATLANTA-ESTADOS-UNIDOS";
	origen[4] = "WASHINGTON D.C.-ESTADOS-UNIDOS";
	origen[5] = "SEUL-COREA-DEL-SUR";
	origen[6] = "ATENAS-GRECIA";
	origen[7] = "ROMA-ITALIA";
	origen[8] = "LIMA-PERU";
	origen[9] = "LISBOA-PORTUGAL";
	// autor=Singaña Josune
	// fecha=19-Agosto-2022
 gotoxy (25,2);	cout << "APLICACION MUESTRA BUSQUEDA SECUENCIAL EN VUELOS " << endl;
	textcolor(4);
	   gotoxy (15,4);cout << "CUANTOS VUELOS QUIERE GENERAR: ";
	cin >> np;
	for (x=0;x<=np-1;x++) {
		j = (rand()%100)%10;
		k = (rand()%9)+1;
		v = (rand()%24)+1;
		m = 3000+(rand()%1000)+1;
		valorv[x] = convertiratexto(m);
		hora[x] = convertiratexto(v);
		vueloa[x] = origen[j];
		vuelod[x] = destino[k];
		vuelo[x] = " | "+vueloa[x]+" | "+vuelod[x]+" "+" | "+hora[x]+":00"+" | "+valorv[x];
	}
		textcolor(6);
	cout << "  <<<<<<<<<<<<<<<<<<<<<<<<<<<<< VUELO ALTO >>>>>>>>>>>>>>>>>>>>>>>>>>>>>" << endl;
	cout << "    |     ORIGEN       |     DESTINO     |      HORARIO     |   VALOR   |" << endl;
		textcolor(3);
	for (i=0;i<=np-1;i++) {
		cout << " " << i+1 << " " << vuelo[i] << endl;
	}
	textcolor(6);
	cout << "  -----------------------------------------------------------------------" << endl;
	do {
		textcolor(4);
		cout << "+++++++++++++++ BUSQUEDA SECUENCIAL DE VUELOS ++++++++++++++++++++++++++++ " << endl;
		textcolor(8);cout << "LUGAR ORIGEN QUE QUIERES BUSCAR USE LETRAS MAYUSCULA: ";
		textcolor(9);cin >> ori;
		textcolor(8);cout << "LUGAR DESTINO QUE QUIERES BUSCAR USE LETRAS MAYUSCULA: ";
		textcolor(9);cin >> des;
		buscarsecuencialmente(vueloa,vuelod,ori,des,np,vuelof);
		textcolor(0);
		if (vuelof!=-1) {
			cout << "LA INFORMACION DEL VUELO ES: " << endl;
			cout << "    |     ORIGEN       |     DESTINO     |      HORARIO     |   VALOR   |" << endl;
			cout << vuelo[vuelof] << endl;
		} else {
			cout << "VUELO DE: " << ori << " CON DESTINO A: " << des << " NO ENCONTRADO" << endl;
		}
	} while (vuelof!=-1);
	getch();
	return 0;
}


string convertiratexto(float f) {
	stringstream ss;
	ss << f;
	return ss.str();
}

