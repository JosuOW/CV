#include<iostream>
#include<cstdlib>
#include<sstream>
#include<conio2.h>
using namespace std;
string convertiratexto(float f);
#define ARREGLO_MAX 100
void buscarsecuencialmente(string telefono[], string tele, float nl, int &telefonof);

void buscarsecuencialmente(string telefono[], string tele, float nl, int &telefonof) {
	int cont, cont1, cont2, j, k, w, x;
	string letra1[50];
	string letra2[50];
	for (j=0;j<=tele.size()-1;j++) {
		letra1[j] = tele.substr(j,j-j+1);
	}
	cont1 = j;
	telefonof = -1;
	for (k=0;k<=nl-1;k++) {
		cont2 = 0;
		for (x=0;x<=telefono[k].size()-1;x++) {
			letra2[x] = telefono[k].substr(x,x-x+1);
		}
		cont2 = x;
		if (cont2==cont1) {
			cont = 0;
			for (w=0;w<=cont1-1;w++) {
				if (letra1[w]==letra2[w]) {
					cont = cont+1;
				}
			}
			if (cont2==cont) {
				telefonof = k;
			}
		}
	}
}

int main() {
	textbackground(15);
	clrscr();
	textcolor(5);
	string duracion[ARREGLO_MAX];
	string fecha[ARREGLO_MAX];
	string hora[ARREGLO_MAX];
		int i, np, v, x, telefonof,num[10] ;
	string info[ARREGLO_MAX];
	string l;
	string llamada[ARREGLO_MAX];
	string tele;
	string telefono[ARREGLO_MAX];
	string telefono2[ARREGLO_MAX];

	// autor=Singaña Josune
	// fecha=19-Agosto-2022
	 gotoxy (25,2); cout << "APLICACION MUESTRA BUSQUEDA SECUENCIAL EN LISTADO DE LLAMADAS" << endl;
textcolor(8);
	   gotoxy (15,4);	cout << "CUANTAS LLAMADAS QUIERE GENERAR: ";
	cin >> np;
	for (x=0;x<=np-1;x++) {
		telefono[x] = "09";
		for (i=0;i<=7;i++) {
			num[i] = (rand()%9)+1;
			l = convertiratexto(num[i]);
			telefono[x] = telefono[x]+l;
		}
		telefono2[x] = "09";
		for (i=0;i<=7;i++) {
			num[i] = (rand()%9)+1;
			l = convertiratexto(num[i]);
			telefono2[x] = telefono2[x]+l;
		}
		v = (rand()%31)+1;
		fecha[x] = convertiratexto(v);
		v = (rand()%1000)+1;
		duracion[x] = convertiratexto(v);
		v = (rand()%24)+1;
		hora[x] = convertiratexto(v);
		llamada[x] = " "+telefono[x]+" | "+telefono2[x]+" "+" | "+fecha[x]+"-"+convertiratexto((rand()%12)+1)+"-2022"+" | "+hora[x]+" | "+duracion[x];
		info[x] = fecha[x]+"-"+convertiratexto((rand()%12)+1)+"-2022"+" | "+hora[x]+" | "+duracion[x];
	}
		textcolor(2);
	cout << " <<<<<<<<<<<<<<<<<<<<<<<< REGISTRO LLAMADAS >>>>>>>>>>>>>>>>>>>>>>>>" << endl;
	cout << "       ORIGEN  |   DESTINO   |  FECHA    |  HORA |  DURACION (minutos)  |" << endl;
textcolor(6);
	for (i=0;i<=np-1;i++) {
		cout << " " << i+1 << " " << llamada[i] << endl;
	}
	do {
		textcolor(2);
			cout << "-----------------------------------------------------------------" << endl;
		cout << "++++++++++++++++++++++ BUSQUEDA SECUENCIAL DE LLAMADA ++++++++++++++++++ " << endl;
			textcolor(3);
		cout << "TELEFONO ORIGEN QUE QUIERES BUSCAR: ";
		cin >> tele;
		buscarsecuencialmente(telefono,tele,np,telefonof);
	textcolor(13);
		if (telefonof!=-1) {
			cout << "                           |  FECHA    |  HORA |  DURACION  |" << endl;
			cout << "LLAMADA ORIGEN: " << tele << " | " << info[telefonof] << endl;
		} else {
			cout << tele << " TELEFONO NO REGISTRA LLAMADAS " << endl;
		}
	} while (telefonof!=-1);
	getch();
	return 0;
}


string convertiratexto(float f) {
	stringstream ss;
	ss << f;
	return ss.str();
}

