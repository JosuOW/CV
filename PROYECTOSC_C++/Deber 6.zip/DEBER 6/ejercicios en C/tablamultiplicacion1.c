
#include<stdio.h>
#include<conio2.h>
int producto(int n, int m);

/* autor: Josune Singaña */
/* fecha:24-07-2022 */

int producto(int n, int m) {
	if (m>0) {
        producto(n,m-1);
		printf ("\t\t %d x %d =%d\n",n,m,(n*m));                
	}
}

int main() {
	textbackground(YELLOW);
	clrscr();
	textcolor(LIGHTRED);
	int num;
	gotoxy (10,2);printf("APLICACION CALCULA LA TABLA DE MULTIPLICAR DE UN NUMERO ENTERO \n");
		textcolor(LIGHTBLUE);
	gotoxy (15,4);printf("INGRESE EL NUMERO A CALCULAR LA TABLA: ");
	scanf("%d",&num);
producto(num,12);
getch();
	return 0;
}
