#include<stdio.h>
#include<conio2.h>
// Declaraciones adelantadas de las funciones
int maxcodivi(int n, int m);
int recursum(int n, int m);

/* autor: Josune Singaña */
/* fecha:24-07-2022 */
int maxcodivi(int n, int m) {
	int mcd;
	if (m!=n) {
		if (n%m==0) {
			mcd = m;
		} else {
			mcd = maxcodivi(m,n%m);
		}
	}
	return mcd;
}

int recursum(int n, int m) {
	int d;
	int h;
	h = maxcodivi(n,m);
	d = (n*m)/h;
	return d;
}

int main() {
	int n, n2, s;
		textbackground(BLUE);
	clrscr();
	textcolor(LIGHTCYAN);
		gotoxy (25,2);printf("APLICACION DETERMINA EL MINIMO COMUN MULTPLO \n");
			textcolor(WHITE);
	printf("\n\tINGRESE EL PRIMER NUMERO: ");
	scanf("%i",&n);
	printf("\n\tINGRESE EL SEGUNDO NUMERO: ");
	scanf("%i",&n2);
	s = recursum(n,n2);
	printf("\n\tEL MINIMO COMUN MULTPLO ES:%i\n",s);
	getch();
	return 0;
}

