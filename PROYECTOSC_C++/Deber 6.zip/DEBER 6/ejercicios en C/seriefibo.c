#include<stdio.h>
#include<conio2.h>
int serie(float l, float i, float n, float fibo, float j);
int recursum(float l);
/* autor: Josune Singaña */
/* fecha:24-07-2022 */
int serie(float l, float i, float n, float fibo, float j) {
	int fibonum;
	if (i<=l) {
		printf(" %.0f",n);
		fibo = n+j;
		j = n;
		n = fibo;
		fibonum = serie(l,i+1,n,fibo,j);
	}
	return fibonum;
}
int recursum(float l) {
	int d;
	d = serie(l,1,1,0,0);
	return d;
}
int main() {
	textbackground(LIGHTGRAY);
	clrscr();
	textcolor(RED);
	int l, s;
	s = 0;
	gotoxy (40,2);printf(" APLICACION GENERA SERIE DE NUMEROS DE FIBONACCI \n");
	textcolor(LIGHTMAGENTA);
			gotoxy (30,4);	printf("INGRESE EL LIMITE DE LA SERIE: ");
	scanf("%i",&l);
	textcolor(GREEN);
			gotoxy (30,6);printf("LA SERIE ES:");
	if (l==0 || l==1) {
		printf(" %.0f",1);
	}
	s = recursum(l);
	printf(" \n");
	getch();
	return 0;
}

