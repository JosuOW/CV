#include<stdio.h>
#include<conio2.h>
long divisor(int n, int m, long sd);
long recursum(int n);
/* autor: Josune Singaña */
/* fecha:24-07-2022 */
long divisor(int n, int m,long sd) {
	if (m>0) {
		sd = divisor(n,m-1,sd);
		if (n!=m && n%m ==0) {
			sd = sd+m;
		}
	}
	return sd;
}
long recursum(int n) {
int d;
	d = divisor(n,n,0);
	return d;
}
int main() {
	textbackground(BLACK);
	clrscr();
	textcolor(LIGHTCYAN);
	int num; 
	long s;
		gotoxy (40,2);printf("APLICACION DETERMINA SI UN NUMERO ES PERFECTO \n");
		textcolor(LIGHTGREEN);
	gotoxy (30,4);printf("INGRESE EL NUMERO ENTERO: ");
	scanf("%i",&num);
	s = recursum(num);
		textcolor(LIGHTRED);
	gotoxy (35,6);printf("EL NUMERO %i",num);
	if (s==num) {
		printf(" ES PERFECTO \n");
	} else {
		printf(" NO ES PERFECTO \n");
	}
	getch();
	return 0;
}

