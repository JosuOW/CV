
#include<stdio.h>
#include<conio2.h>

int nuprimo(int n,int j);

/* autor: Josune Singaña */
/* fecha:24-07-2022 */
int nuprimo(int n, int j) {
	int p;
	if (n/2<=j) {
		p = 1;
	} else {
		if (n%j==0) {
			p = 0;
		} else {
			p = nuprimo(n,j+1);
		}
	}
	return p;
}

int main() {
		textbackground(7);
	clrscr();
	textcolor(3);
	int num, s;
	char opc;
			gotoxy (40,2);printf("APLICACION DETERMINA SI UN NUMERO ES PRIMO \n");
	opc ='s';
	while(opc=='S'||opc=='s')
{
		textcolor(8);
	printf("\n\tINGRESE EL NUMERO: ");
	scanf("%i",&num);
		textcolor(LIGHTMAGENTA);
	printf("\n\tEL NUMERO: %i", num, " ");
	if (num==1 || num==4|| num==0 ){
	printf(" NO ES PRIMO \n");
	}else{
	s = nuprimo(num,2);
	if (s==1) {
		printf(" ES PRIMO \n");
	} else {
		printf(" NO ES PRIMO \n");
	}
		}
			textcolor(2);
		printf(" \n\t DESEA REPETIR EL PROCESO: S O N");
	opc=getch();
	}
	return 0;
}
	

