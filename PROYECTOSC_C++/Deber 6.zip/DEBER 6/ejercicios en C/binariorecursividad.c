#include<stdio.h>
#include<conio2.h>
/*autor: Josune Singaña
fecha: 24 de Julio de 2022*/
long binario(int n) {
long r=0;
	if (n>0) 
	{
		r=binario (n/2);
			r=r*10+(n%2);
	}
	return r;
		}
	

int main() {
	textbackground(LIGHTGRAY);
	clrscr();
	textcolor(MAGENTA);
	int num;
    	gotoxy (30,2);printf("APLICACION CONVIERTE NUMERO DECIMAL EN BINARIO\n");
    		textcolor(CYAN);
    	gotoxy (25,4);printf("INGRESE EL NUMERO QUE DESEA CONVERTIR: ");
	scanf("%i",&num); //Pedir variable num
		textcolor(BLUE);
gotoxy (40,5 );	printf("%ld\n",binario(num));
getch();
	return 0;
}



