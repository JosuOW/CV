/*autor: Josune Singaña
fecha: 24 de Julio de 2022*/
#include<stdio.h>
#include<conio2.h>
void binario(int n)
{
    if (n!=0)
    {
        binario(n/2);
        printf("%i",n%2);
    }
}
int main()
{
    int num=0;
    textbackground(MAGENTA);
	clrscr();
	textcolor(LIGHTGRAY);
    	gotoxy (30,2);printf("APLICACION CONVIERTE NUMERO DECIMAL EN BINARIO\n");
    		textcolor(WHITE);
    	gotoxy (25,4);printf("INGRESE EL NUMERO QUE DESEA CONVERTIR: ");
	scanf("%i",&num); 
		textcolor(YELLOW);
gotoxy (40,6); binario(num);
getch();
    return 0;
}
